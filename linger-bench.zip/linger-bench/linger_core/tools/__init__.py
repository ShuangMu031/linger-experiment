from linger_core.tools.tool_types import ToolParameter, ToolRequest, ToolResult, ToolSpec
from linger_core.tools.base_tool import BaseTool
from linger_core.tools.tool_registry import ToolRegistry
from linger_core.tools.tool_executor import ToolExecutor
from linger_core.tools.time_tool import TimeTool
from linger_core.tools.memory_search_tool import MemorySearchTool
from linger_core.tools.world_state_tool import WorldStateTool


def create_default_registry(state=None) -> ToolRegistry:
    registry = ToolRegistry()
    registry.register(TimeTool(state=state))
    registry.register(MemorySearchTool(state=state))
    registry.register(WorldStateTool(state=state))
    return registry
