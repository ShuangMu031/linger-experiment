from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ToolParameter:
    name: str
    type: str = "string"
    required: bool = False
    description: str = ""
    default: Any = None


@dataclass
class ToolSpec:
    name: str
    description: str
    parameters: List[ToolParameter] = field(default_factory=list)
    risk_level: str = "low"
    category: str = "query"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "parameters": [
                {"name": p.name, "type": p.type, "required": p.required, "description": p.description}
                for p in self.parameters
            ],
            "risk_level": self.risk_level,
            "category": self.category,
        }


@dataclass
class ToolRequest:
    tool_name: str
    arguments: Dict[str, Any] = field(default_factory=dict)
    requester: str = ""
    reason: str = ""
    request_id: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tool_name": self.tool_name,
            "arguments": self.arguments,
            "requester": self.requester,
            "reason": self.reason,
            "request_id": self.request_id,
        }


@dataclass
class ToolResult:
    tool_name: str
    success: bool
    result: Any = None
    error: str = ""
    execution_time_ms: float = 0.0
    approved_by: str = ""
    request_id: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tool_name": self.tool_name,
            "success": self.success,
            "result": self.result,
            "error": self.error,
            "execution_time_ms": self.execution_time_ms,
            "approved_by": self.approved_by,
            "request_id": self.request_id,
        }
