from typing import Any, Dict, Optional

from linger_core.tools.base_tool import BaseTool
from linger_core.tools.tool_types import ToolParameter, ToolResult, ToolSpec


class TimeTool(BaseTool):
    def __init__(self, state: Any = None) -> None:
        self._state = state

    def spec(self) -> ToolSpec:
        return ToolSpec(
            name="time_tool",
            description="查询当前世界时间和会话时间信息",
            parameters=[
                ToolParameter(name="format", type="string", required=False, description="时间格式: iso / readable / raw"),
            ],
            risk_level="low",
            category="query",
        )

    def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        if self._state is None:
            return ToolResult(tool_name="time_tool", success=False, error="state not available")

        fmt = arguments.get("format", "readable")
        clock = self._state.clock
        session = self._state.session

        world_now = clock.world_now_time()
        real_now = clock.real_now_time()
        idle = session.idle_seconds(real_now=real_now)

        if fmt == "iso":
            result = {
                "world_time": world_now.isoformat(),
                "real_time": real_now.isoformat(),
                "idle_seconds": idle,
            }
        elif fmt == "raw":
            result = {
                "world_time": str(world_now),
                "real_time": str(real_now),
                "idle_seconds": idle,
                "session_id": session.session_id,
                "consecutive_assistant_turns": session.consecutive_assistant_turns,
            }
        else:
            result = {
                "world_time": world_now.strftime("%Y-%m-%d %H:%M"),
                "real_time": real_now.strftime("%Y-%m-%d %H:%M"),
                "idle_seconds": round(idle, 1),
                "session_status": session.status.value,
            }

        return ToolResult(tool_name="time_tool", success=True, result=result)
