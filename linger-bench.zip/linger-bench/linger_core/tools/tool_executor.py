import time
from typing import List, Optional

from linger_core.tools.tool_registry import ToolRegistry
from linger_core.tools.tool_types import ToolRequest, ToolResult


class ToolExecutor:
    ALLOWED_RISK_LEVELS = ("low",)

    def __init__(self, registry: ToolRegistry, approver: str = "supervisor") -> None:
        self._registry = registry
        self._approver = approver
        self._execution_log: List[ToolResult] = []

    def approve_and_execute(self, request: ToolRequest) -> ToolResult:
        tool = self._registry.get(request.tool_name)
        if tool is None:
            return ToolResult(
                tool_name=request.tool_name,
                success=False,
                error=f"tool not found: {request.tool_name}",
                approved_by="",
                request_id=request.request_id,
            )

        spec = tool.spec()
        if spec.risk_level not in self.ALLOWED_RISK_LEVELS:
            return ToolResult(
                tool_name=request.tool_name,
                success=False,
                error=f"tool risk_level={spec.risk_level} not allowed (only {self.ALLOWED_RISK_LEVELS})",
                approved_by="",
                request_id=request.request_id,
            )

        missing = self._check_required_params(spec, request.arguments)
        if missing:
            return ToolResult(
                tool_name=request.tool_name,
                success=False,
                error=f"missing required parameters: {missing}",
                approved_by="",
                request_id=request.request_id,
            )

        start = time.monotonic()
        try:
            result = tool.execute(request.arguments)
            elapsed = (time.monotonic() - start) * 1000
            result.execution_time_ms = elapsed
            result.approved_by = self._approver
            result.request_id = request.request_id
        except Exception as e:
            elapsed = (time.monotonic() - start) * 1000
            result = ToolResult(
                tool_name=request.tool_name,
                success=False,
                error=f"execution error: {e}",
                execution_time_ms=elapsed,
                approved_by=self._approver,
                request_id=request.request_id,
            )

        self._execution_log.append(result)
        return result

    @property
    def execution_log(self) -> List[ToolResult]:
        return list(self._execution_log)

    @staticmethod
    def _check_required_params(spec, arguments) -> List[str]:
        missing = []
        for p in spec.parameters:
            if p.required and p.name not in arguments:
                missing.append(p.name)
        return missing
