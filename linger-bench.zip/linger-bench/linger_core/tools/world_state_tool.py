from typing import Any, Dict

from linger_core.tools.base_tool import BaseTool
from linger_core.tools.tool_types import ToolParameter, ToolResult, ToolSpec


class WorldStateTool(BaseTool):
    def __init__(self, state: Any = None) -> None:
        self._state = state

    def spec(self) -> ToolSpec:
        return ToolSpec(
            name="world_state_tool",
            description="查询当前世界状态：场景、天气、NPC、地点，只读不写",
            parameters=[
                ToolParameter(name="include_npcs", type="boolean", required=False, description="是否包含NPC列表"),
                ToolParameter(name="include_places", type="boolean", required=False, description="是否包含地点列表"),
            ],
            risk_level="low",
            category="query",
        )

    def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        if self._state is None:
            return ToolResult(tool_name="world_state_tool", success=False, error="state not available")

        include_npcs = arguments.get("include_npcs", True)
        include_places = arguments.get("include_places", True)

        wr = self._state.world_runtime
        result: Dict[str, Any] = {
            "scene_id": getattr(wr, "current_scene_id", ""),
            "place_id": getattr(wr, "current_place_id", ""),
            "time_of_day": getattr(wr, "time_of_day", ""),
            "day_index": getattr(wr, "day_index", 0),
            "weather": getattr(wr, "weather", ""),
            "ambient_mood": getattr(wr, "ambient_mood", ""),
        }

        if hasattr(wr, "time_of_day") and hasattr(wr.time_of_day, "value"):
            result["time_of_day"] = wr.time_of_day.value

        if include_npcs:
            npc_reg = self._state.npc_registry
            npc_ids = npc_reg.active_npc_ids if hasattr(npc_reg, "active_npc_ids") else []
            result["npcs"] = {"total": len(npc_ids), "ids": list(npc_ids)}

        if include_places:
            places = self._state.place_registry
            result["places"] = {
                "total": len(places),
                "ids": list(places.keys()),
            }

        return ToolResult(tool_name="world_state_tool", success=True, result=result)
