from typing import Any, Dict, List

from linger_core.tools.base_tool import BaseTool
from linger_core.tools.tool_types import ToolParameter, ToolResult, ToolSpec


class MemorySearchTool(BaseTool):
    def __init__(self, state: Any = None) -> None:
        self._state = state

    def spec(self) -> ToolSpec:
        return ToolSpec(
            name="memory_search_tool",
            description="搜索短期记忆和事件记忆，只读不写",
            parameters=[
                ToolParameter(name="query", type="string", required=False, description="搜索关键词"),
                ToolParameter(name="source", type="string", required=False, description="来源: short_term / events / all"),
                ToolParameter(name="limit", type="integer", required=False, description="返回条数上限"),
            ],
            risk_level="low",
            category="query",
        )

    def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        if self._state is None:
            return ToolResult(tool_name="memory_search_tool", success=False, error="state not available")

        query = arguments.get("query", "").lower()
        source = arguments.get("source", "all")
        limit = arguments.get("limit", 5)

        results: List[Dict[str, Any]] = []

        if source in ("short_term", "all"):
            results.extend(self._search_short_term(query, limit))

        if source in ("events", "all") and len(results) < limit:
            remaining = limit - len(results)
            results.extend(self._search_events(query, remaining))

        return ToolResult(
            tool_name="memory_search_tool",
            success=True,
            result={"query": query, "source": source, "count": len(results), "items": results[:limit]},
        )

    def _search_short_term(self, query: str, limit: int) -> List[Dict[str, Any]]:
        items: List[Dict[str, Any]] = []
        stm = self._state.short_term_memory
        turns = stm.recent_turns() if hasattr(stm, "recent_turns") else []

        for turn in turns:
            text = ""
            if hasattr(turn, "user_text"):
                text = turn.user_text or ""
            elif hasattr(turn, "text"):
                text = turn.text or ""
            elif isinstance(turn, dict):
                text = turn.get("user_text", turn.get("text", ""))

            if not query or query in text.lower():
                items.append({"source": "short_term", "text": text[:200]})
                if len(items) >= limit:
                    break

        return items

    def _search_events(self, query: str, limit: int) -> List[Dict[str, Any]]:
        items: List[Dict[str, Any]] = []
        em = self._state.event_memory
        active = em.get_active() if hasattr(em, "get_active") else []

        for event in active:
            title = getattr(event, "title", "") or ""
            display = getattr(event, "display_title", "") or ""
            text = f"{title} {display}".lower()

            if not query or query in text:
                items.append({
                    "source": "event",
                    "event_id": getattr(event, "event_id", ""),
                    "title": title[:100],
                    "status": getattr(event, "status", ""),
                })
                if len(items) >= limit:
                    break

        return items
