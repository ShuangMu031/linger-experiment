from abc import ABC, abstractmethod
from typing import Any, Dict

from linger_core.tools.tool_types import ToolSpec, ToolResult


class BaseTool(ABC):
    @abstractmethod
    def spec(self) -> ToolSpec:
        ...

    @abstractmethod
    def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        ...
