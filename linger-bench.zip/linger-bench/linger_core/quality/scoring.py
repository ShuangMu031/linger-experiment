"""C11 输出质量基线评分器。

四个独立指标，分别独立计分，避免一个指标的问题掩盖其他问题：
1. JSON 格式合规率（仅对强 JSON 任务）
2. 必填字段完整率（仅对强 JSON 任务）
3. 长度合理率（落在 [min, max] 区间内）
4. 红线扫描通过率（不含禁止表达）

用法：见 linger_core/tests/test_quality_baseline.py
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from linger_core.llm.json_utils import parse_json_object_safely


@dataclass
class ScoreResult:
    scenario_id: str
    json_format_ok: Optional[bool] = None
    required_fields_ok: Optional[bool] = None
    length_ok: Optional[bool] = None
    red_lines_clean: bool = True
    extra_notes: List[str] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        checks = [self.length_ok, self.red_lines_clean]
        if self.json_format_ok is not None:
            checks.append(self.json_format_ok)
        if self.required_fields_ok is not None:
            checks.append(self.required_fields_ok)
        return all(c is not False for c in checks)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "scenario_id": self.scenario_id,
            "json_format_ok": self.json_format_ok,
            "required_fields_ok": self.required_fields_ok,
            "length_ok": self.length_ok,
            "red_lines_clean": self.red_lines_clean,
            "passed": self.passed,
            "notes": list(self.extra_notes),
        }


def score_response(
    scenario: Dict[str, Any],
    response_content: str,
    global_red_lines: Optional[List[str]] = None,
) -> ScoreResult:
    """对单条响应做四维度评分。

    scenario 期待字段（详见 baseline/scenarios.json）：
        - id (必)
        - expected_min_chars / expected_max_chars (可选)
        - expected_response_format == "json" → 启用 JSON 检查
        - required_json_fields (强 JSON 任务必填字段列表)
        - must_not_contain (场景级红线词列表)

    global_red_lines: 全局红线词（PERSONA_CONTRACT 8 项）
    """
    result = ScoreResult(scenario_id=scenario.get("id", "unknown"))

    if scenario.get("expected_response_format") == "json":
        parsed, mode = parse_json_object_safely(response_content)
        result.json_format_ok = mode != "failed"

        required = scenario.get("required_json_fields", [])
        if required:
            if not result.json_format_ok:
                result.required_fields_ok = False
                result.extra_notes.append("json_parse_failed -> cannot check fields")
            else:
                missing = [f for f in required if f not in parsed]
                result.required_fields_ok = len(missing) == 0
                if missing:
                    result.extra_notes.append(f"missing_fields={missing}")

    min_chars = scenario.get("expected_min_chars")
    max_chars = scenario.get("expected_max_chars")
    if min_chars is not None or max_chars is not None:
        n = len(response_content.strip())
        ok = True
        if min_chars is not None and n < min_chars:
            ok = False
            result.extra_notes.append(f"too_short:{n}<{min_chars}")
        if max_chars is not None and n > max_chars:
            ok = False
            result.extra_notes.append(f"too_long:{n}>{max_chars}")
        result.length_ok = ok

    red_lines: List[str] = []
    red_lines.extend(global_red_lines or [])
    red_lines.extend(scenario.get("must_not_contain", []))
    hit = [w for w in red_lines if w and w in response_content]
    if hit:
        result.red_lines_clean = False
        result.extra_notes.append(f"red_line_hit={hit}")

    max_questions = scenario.get("max_questions")
    if max_questions is not None:
        q_count = response_content.count("？") + response_content.count("?")
        if q_count > max_questions:
            result.extra_notes.append(f"question_count_exceeded:{q_count}>{max_questions}")
            result.length_ok = False if result.length_ok else result.length_ok

    return result


def aggregate_scores(scores: List[ScoreResult]) -> Dict[str, Any]:
    n = len(scores)
    if n == 0:
        return {"total": 0}

    json_eligible = [s for s in scores if s.json_format_ok is not None]
    field_eligible = [s for s in scores if s.required_fields_ok is not None]
    length_eligible = [s for s in scores if s.length_ok is not None]

    def _rate(items, predicate):
        if not items:
            return None
        ok = sum(1 for s in items if predicate(s))
        return round(ok / len(items), 4)

    return {
        "total": n,
        "passed": sum(1 for s in scores if s.passed),
        "pass_rate": round(sum(1 for s in scores if s.passed) / n, 4),
        "json_format_rate": _rate(json_eligible, lambda s: s.json_format_ok is True),
        "required_fields_rate": _rate(field_eligible, lambda s: s.required_fields_ok is True),
        "length_ok_rate": _rate(length_eligible, lambda s: s.length_ok is True),
        "red_lines_clean_rate": round(sum(1 for s in scores if s.red_lines_clean) / n, 4),
    }
