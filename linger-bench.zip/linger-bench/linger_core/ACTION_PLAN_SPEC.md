# ACTION_PLAN_SPEC — the_new_world v0.4.0a14

> **性质**：ActionPlan 的字段与行为冻结文档。  
> **适用范围**：所有产出 ActionPlan 的模块（SupervisorKernel、ProactivePlanner、DecisionMerger）。

---

## 1. ActionPlan 冻结字段

`FROZEN_FIELDS` 元组定义了 19 个冻结合同字段。这 19 个字段的语义不得在周期之间变更。

| 字段 | 类型 | 含义 |
|------|------|------|
| `primary_goal` | `str` | 本轮主要目标 |
| `secondary_goals` | `List[str]` | 次要目标列表 |
| `response_strategy` | `str` | 回复策略：respond/inform/inquire/comfort/proactive 等 |
| `should_ask_question` | `bool` | 是否应该向用户提问 |
| `should_comfort` | `bool` | 是否应该安慰用户 |
| `should_avoid` | `List[str]` | 本轮应该避免的话题/行为 |
| `state_writes` | `List[Dict]` | 本轮要写入的状态变更 |
| `allow_drift` | `bool` | 是否允许话题自然漂移 |
| `expression_style` | `str` | 表达风格：neutral/warm/gentle/casual |
| `confidence` | `float` | 0.0-1.0 系统对本轮决策的置信度 |
| `reasoning_summary` | `str` | 人类可读的推理摘要 |
| `can_speak` | `bool` | 系统是否允许发出本轮回复 |
| `should_pause` | `bool` | 是否应该暂停等待用户 |
| `speak_mode` | `str` | 说话模式：normal/warm_respond/gentle_presence/welcome_back 等 |
| `allow_followup` | `bool` | 是否允许后续跟进 |
| `pause_required` | `bool` | 是否必须暂停（如结束信号） |
| `max_sentences` | `int` | 本轮回复最大句子数 |
| `followup_hook` | `str` | 跟进钩子类型 |
| `emotion_priority` | `str` | 情绪优先级：low/medium/high |

---

## 2. 非冻结内部字段

| 字段 | 类型 | 含义 | 是否进入 `to_dict()` |
|------|------|------|---------------------|
| `module_outputs` | `Dict[str, Any]` | 各 Supervisor 模块的原始输出 | ❌ 仅 `to_full_dict()` |
| `planned_steps` | `List[ActionStep]` | 本轮执行的行动步骤（可观察层） | ❌ 仅 `to_full_dict()` |

---

## 3. ActionStep（可观察行动步骤）

| 字段 | 类型 | 含义 |
|------|------|------|
| `step_id` | `str` | 唯一标识 (as_xxxxxxxx) |
| `action_type` | `str` | 动作类型（见 §4） |
| `target` | `str` | 动作目标 |
| `reason` | `str` | 执行原因简述 |
| `status` | `str` | planned / executing / completed / failed |
| `result_summary` | `str` | 执行结果摘要 |

---

## 4. action_type 合法枚举（周期八）

| action_type | 含义 | 谁记录 |
|-------------|------|--------|
| `assemble_context` | 上下文组装完成 | RuntimeOrchestrator |
| `route_task` | 任务路由完成 | RuntimeOrchestrator |
| `build_response` | 回复生成完成 | RuntimeOrchestrator |
| `register_followup` | 跟进钩子注册完成 | RuntimeOrchestrator |
| `writeback_memory` | 记忆写回完成 | RuntimeOrchestrator |

---

## 5. to_dict() vs to_full_dict()

| 方法 | 包含内容 | 使用场景 |
|------|---------|---------|
| `to_dict()` | 仅 19 个冻结字段 | 通用 API 返回、序列化 |
| `to_full_dict()` | 冻结字段 + module_outputs + planned_steps | CLI debug、白盒输出 |

---

## 6. 不可破坏规则

- `module_outputs` 仅供内部调试，不得被 LLM 直接消费
- `planned_steps` 仅记录执行事实，不得驱动流程分支
- 新增 ActionPlan 字段必须先讨论是否进入 FROZEN_FIELDS
- 冻结字段的语义变更需要周期级别的架构评审
