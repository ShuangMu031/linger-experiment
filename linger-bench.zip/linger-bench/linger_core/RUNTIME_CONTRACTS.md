# RUNTIME CONTRACTS — the_new_world v0.4.0a14

> **性质**：工程合同文档，冻结周期。  
> **约束**：以下入口是系统唯一合法入口，新增代码不得绕过。

---

## 1. 唯一入口

| 入口 | 职责 | 实现位置 |
|------|------|----------|
| **唯一前台入口** | `ForegroundLoop.handle_user_input(user_message)` | `runtime/foreground/foreground_loop.py` |
| **唯一后台入口** | `BackgroundLoop.tick_once()` | `runtime/background/background_loop.py` |
| **唯一主链入口** | `RuntimeOrchestrator.handle_envelope(envelope, state)` | `runtime/orchestrator/runtime_orchestrator.py` |
| **唯一出站调度** | `OutboundDispatcher.drain_and_dispatch(state)` | `runtime/orchestrator/outbound_dispatcher.py` |
| **唯一写回入口** | `WritebackManager.commit(state, envelope, plan, response_message)` | `runtime/orchestrator/writeback_manager.py` |
| **唯一上下文组装** | `ContextAssembler.build(state, envelope) → ContextBundle` | `runtime/orchestrator/context_assembler.py` |
| **唯一主动守卫** | `ProactiveGuard.evaluate(candidate, state) → GuardDecision` | `supervisor/proactive_guard.py` |

---

## 2. 数据流向

### 2.1 用户输入全链路

```
用户输入
  → ForegroundLoop.handle_user_input
  → create_user_envelope
  → RuntimeOrchestrator.handle_envelope
  → _prepare_user_input (更新 session 状态)
  → ContextAssembler.build → ContextBundle
  → SupervisorKernel.process(context_bundle=context_bundle)
  → DecisionMerger.merge
  → ActionPlan
  → ResponseBuilder.build
  → should_emit 判断 → mark_assistant_event / 更新 session
  → WritebackManager.commit
  → OrchestratorResult
```

### 2.2 主动触发全链路

```
BackgroundLoop.tick_once
  → TimelineEngine.tick + TriggerRegistry.collect_all
  → plan_state.add_outbound_candidate(TriggerCandidate)
  → OutboundDispatcher.drain_and_dispatch
    → ProactiveGuard.evaluate(candidate, state)
    → allowed: _envelope_from_trigger_candidate → RuntimeEnvelope
    → RuntimeOrchestrator.handle_envelope
      → _prepare_proactive_input (debug 记录)
      → ContextAssembler.build → ContextBundle
      → ProactivePlanner.process_candidate
      → ProactiveResponseBuilder.build
      → should_emit 判断 → mark_assistant_proactive_sent / mark_assistant_event
      → WritebackManager.commit
  → OrchestratorResult
```

---

## 3. 硬性约束

| 约束 | 说明 |
|------|------|
| 用户输入必须通过 `create_user_envelope` | 不得直接构造 RuntimeEnvelope 注入用户消息 |
| 主动候选必须 `TriggerCandidate → RuntimeEnvelope` | 候选对象化，不经 dict 中转 |
| 主动 envelope 只能由 `OutboundDispatcher` 创建 | 生产代码中不得调用已删除的 `create_followup_envelope` / `create_world_event_envelope` |
| 所有可见回复由 `OrchestratorResult` 返回 | 无此类型即不可见 |
| 所有状态写入通过 `WritebackManager` | 不得在 ResponseBuilder 内写记忆/状态 |
| 所有上下文由 `ContextAssembler` 提供 | `SupervisorKernel` 不再自己召回上下文，强制依赖 `ContextBundle` |
| 前台和后台共享 `RuntimeOrchestrator` | 不创建第二套编排链路 |

---

## 4. 角色职责边界

| 角色 | 职责 | 不得 |
|------|------|------|
| ProactiveGuard | 判断候选能否发出 | 不得决定发什么内容 |
| ProactivePlanner | 决定主动消息的目标和风格 | 不得判断能不能发（不再持有 Guard） |
| ProactiveResponseBuilder | 生成主动消息文本 | 不得写状态 |
| WritebackManager | 统一写入记忆/事件/画像/关系 | 唯一的写回入口 |
| ContextAssembler | 统一组装上下文 | 唯一的上下文来源 |
| SupervisorKernel | 裁决和路由 | 只消费 ContextBundle，不做召回 |

---

## 5. 主动消息计数时机

```
should_emit = action_plan.can_speak and bool(response_message)

只有 should_emit 为 True 时，才更新 session 状态：
  - USER_INPUT: mark_assistant_event + 更新 last_speaker/consecutive_assistant_turns/...
  - PROACTIVE: mark_assistant_proactive_sent + mark_assistant_event

不在 _prepare_proactive_input 内提前计数。
```

---

## 6. turn_id 语义（冻结）

`clock.logical.turn_id` 表示**系统内的消息事件序号**：
- 用户输入时通过 `mark_user_event()` 递增一次
- 助手输出成功时通过 `mark_assistant_event()` 递增一次
- 一次用户-助手交换包含 2 个 turn_id 事件

所有记忆写入、事件提取、writeback 统一使用 `state.clock.logical.turn_id`。
已删除 `session.current_turn_id`。

---

## 7. Trace 生命周期

```
每个 tick_once 必须保证:
  self._trace_store.start_trace("BACKGROUND_TICK")
  try:
    ...
  finally:
    self._trace_store.end_trace(...)

每个 handle_envelope 必须保证:
  self._trace_store.start_trace("ORCHESTRATOR_...")
  try:
    ...
  finally:
    self._trace_store.end_whitebox_trace(trace_id=trace_id)
    self._trace_store.end_trace(result="orchestrated_or_error")

不允许残留 active trace (trace_depth 最终必须为 0)。

WhiteboxTrace 按 trace_id 隔离，whitebox 写入方法全部绑定 trace_id：
  set_input_understanding(trace_id, ...)
  add_module_judgment(trace_id, ...)
  set_supervisor_decision(trace_id, ...)
  set_action_result(trace_id, ...)
```

---

## 8. 异常可追踪原则

- `_bridge_world_events()` 异常必须写入 trace 和 debug_state，不得静默 `pass`
- `_on_proactive()` 回调异常必须写入 trace 和 debug_state，记录 `envelope_id`
- `_run_loop()` 异常写入 `debug_state.record_event`（tick 内异常由 tick_once 自己的 finally 处理）

---

## 9. 版本对齐

- `__init__.py:__version__` = `"0.4.0a14"`
- `default_config.py:SystemConfig.version` = `"0.4.0a14"`
- 两者必须一致，任何版本变更必须同时更新。
