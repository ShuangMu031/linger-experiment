from typing import Any, Dict, List, Optional

from linger_core.memory.long_term_memory_entry import LongTermMemoryEntry
from linger_core.memory.long_term_memory_store import LongTermMemoryStore
from linger_core.memory.profile_snapshot import ProfileSnapshot
from linger_core.shared.enums import LongTermMemoryCategory


class ProfileRecall:
    def __init__(self, ltm_store: LongTermMemoryStore, profile: Optional[ProfileSnapshot] = None):
        self._store = ltm_store
        self._profile = profile

    def recall_by_category(self, category: LongTermMemoryCategory, n: int = 5) -> List[LongTermMemoryEntry]:
        entries = self._store.get_by_category(category)
        entries.sort(key=lambda e: e.effective_score(), reverse=True)
        return entries[:n]

    def recall_preferences(self, n: int = 5) -> List[LongTermMemoryEntry]:
        return self.recall_by_category(LongTermMemoryCategory.PREFERENCE, n)

    def recall_style(self, n: int = 3) -> List[LongTermMemoryEntry]:
        return self.recall_by_category(LongTermMemoryCategory.STYLE, n)

    def recall_concerns(self, n: int = 5) -> List[LongTermMemoryEntry]:
        return self.recall_by_category(LongTermMemoryCategory.CONCERN, n)

    def recall_identity(self, n: int = 5) -> List[LongTermMemoryEntry]:
        return self.recall_by_category(LongTermMemoryCategory.IDENTITY_HINT, n)

    def recall_habits(self, n: int = 5) -> List[LongTermMemoryEntry]:
        return self.recall_by_category(LongTermMemoryCategory.HABIT, n)

    def recall_for_context(self, topic: str = "", n: int = 10) -> List[LongTermMemoryEntry]:
        results: List[LongTermMemoryEntry] = []
        if topic:
            keyword_matches = self._store.find_by_keyword(topic)
            results.extend(keyword_matches)
        high_conf = self._store.get_high_confidence(min_confidence=0.7)
        for e in high_conf:
            if e not in results:
                results.append(e)
        top = self._store.get_top_scored(n)
        for e in top:
            if e not in results:
                results.append(e)
        return results[:n]

    def recall_user_facts(self, n: int = 40) -> str:
        """按 tag 取 top-N 用户陈述事实，拼成 prompt 用字符串。

        # n 取大值确保一段对话内的用户事实基本全注入（实验每段约 20-30 条）
        刻意不按 query 检索：find_by_keyword 传整句问题基本不命中（子串语义），
        改为全量注入 top-N 高分事实（按 effective_score 排序），由模型自行挑选。
        """
        facts = self._store.get_by_tag("user_fact")
        if not facts:
            return ""
        facts.sort(key=lambda e: e.effective_score(), reverse=True)
        lines = [e.summary or e.value for e in facts[:n]]
        return "对方以前亲口告诉过你这些关于他自己的事（你都记得）：\n" + "\n".join(lines)

    def build_context_summary(self, topic: str = "", n: int = 10) -> str:
        entries = self.recall_for_context(topic, n)
        if not entries:
            return ""
        parts = []
        for e in entries:
            parts.append(f"[{e.category.value}] {e.key}: {e.value} (置信度:{e.confidence:.1f})")
        return "\n".join(parts)

    def get_profile_hint(self) -> Dict[str, Any]:
        if not self._profile:
            return {}
        return {
            "style": self._profile.preferred_style(),
            "dominant_emotion": self._profile.dominant_emotion(),
            "top_topics": self._profile.top_topics(3),
            "risk_flags": self._profile.recent_risk_flags,
        }
