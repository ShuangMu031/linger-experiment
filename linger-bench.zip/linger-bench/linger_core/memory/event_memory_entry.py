from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.shared.enums import EventStatus, EventType


@dataclass
class EventMemoryEntry:
    event_id: str
    event_type: EventType
    title: str
    summary: str
    status: EventStatus = EventStatus.OPEN
    participants: List[str] = field(default_factory=lambda: ["user", "assistant"])
    source_entry_ids: List[str] = field(default_factory=list)
    source_turn_ids: List[int] = field(default_factory=list)
    first_seen_real: Optional[datetime] = None
    first_seen_world: Optional[datetime] = None
    last_seen_real: Optional[datetime] = None
    last_seen_world: Optional[datetime] = None
    emotion_label: str = ""
    emotion_peak: float = 0.0
    importance: float = 0.5
    unresolved_score: float = 0.0
    mention_count: int = 1
    followup_hook_ids: List[str] = field(default_factory=list)
    related_tags: List[str] = field(default_factory=list)
    last_user_message: str = ""
    last_assistant_message: str = ""
    resolution_hint: str = ""
    is_user_core_event: bool = False
    continuity_score: float = 0.5
    recall_priority: float = 0.5
    topic_key: str = ""
    topic_summary: str = ""
    parent_event_id: str = ""
    display_title: str = ""
    merge_count: int = 0
    resolved_at_real: Optional[datetime] = None
    resolved_at_world: Optional[datetime] = None
    archived_at_real: Optional[datetime] = None
    # T3: §5.1.2 anchor_date 变量 TTL + expire_at 字段化
    anchor_date: Optional[datetime] = None
    expire_at: Optional[datetime] = None

    def touch(self, real_now: Optional[datetime] = None, world_now: Optional[datetime] = None) -> None:
        if real_now:
            self.last_seen_real = real_now
        if world_now:
            self.last_seen_world = world_now

    def add_mention(
        self,
        entry_id: str,
        turn_id: int,
        real_now: Optional[datetime] = None,
        world_now: Optional[datetime] = None,
    ) -> None:
        if entry_id not in self.source_entry_ids:
            self.source_entry_ids.append(entry_id)
        if turn_id not in self.source_turn_ids:
            self.source_turn_ids.append(turn_id)
        self.mention_count += 1
        self.touch(real_now, world_now)

    def update_emotion(self, emotion: str, intensity: float) -> None:
        self.emotion_label = emotion
        if intensity > self.emotion_peak:
            self.emotion_peak = intensity

    def resolve(self, hint: str = "", real_now: Optional[datetime] = None, world_now: Optional[datetime] = None) -> None:
        self.status = EventStatus.RESOLVED
        self.unresolved_score = 0.0
        self.recall_priority = max(0.15, self.recall_priority - 0.3)
        if hint:
            self.resolution_hint = hint
        if real_now:
            self.resolved_at_real = real_now
        if world_now:
            self.resolved_at_world = world_now

    def cool_down(self, delta: float = 0.1) -> None:
        if self.status == EventStatus.OPEN:
            self.unresolved_score = max(0.0, self.unresolved_score - delta)
            if self.unresolved_score <= 0.0:
                self.status = EventStatus.COOLED

    def archive(self, real_now: Optional[datetime] = None) -> None:
        self.status = EventStatus.ARCHIVED
        self.recall_priority = 0.0
        if real_now:
            self.archived_at_real = real_now

    def boost_priority(self, delta: float) -> None:
        self.recall_priority = min(1.0, self.recall_priority + delta)

    def decay_priority(self, delta: float) -> None:
        self.recall_priority = max(0.0, self.recall_priority - delta)

    def is_active(self) -> bool:
        return self.status in (EventStatus.OPEN, EventStatus.COOLED)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "event_type": self.event_type.value,
            "title": self.title,
            "summary": self.summary,
            "status": self.status.value,
            "participants": self.participants,
            "source_entry_ids": self.source_entry_ids,
            "source_turn_ids": self.source_turn_ids,
            "first_seen_real": self.first_seen_real.isoformat() if self.first_seen_real else None,
            "first_seen_world": self.first_seen_world.isoformat() if self.first_seen_world else None,
            "last_seen_real": self.last_seen_real.isoformat() if self.last_seen_real else None,
            "last_seen_world": self.last_seen_world.isoformat() if self.last_seen_world else None,
            "emotion_label": self.emotion_label,
            "emotion_peak": self.emotion_peak,
            "importance": self.importance,
            "unresolved_score": self.unresolved_score,
            "mention_count": self.mention_count,
            "followup_hook_ids": self.followup_hook_ids,
            "related_tags": self.related_tags,
            "last_user_message": self.last_user_message,
            "last_assistant_message": self.last_assistant_message,
            "resolution_hint": self.resolution_hint,
            "is_user_core_event": self.is_user_core_event,
            "continuity_score": self.continuity_score,
            "recall_priority": self.recall_priority,
            "topic_key": self.topic_key,
            "topic_summary": self.topic_summary,
            "parent_event_id": self.parent_event_id,
            "display_title": self.display_title,
            "merge_count": self.merge_count,
            "resolved_at_real": self.resolved_at_real.isoformat() if self.resolved_at_real else None,
            "resolved_at_world": self.resolved_at_world.isoformat() if self.resolved_at_world else None,
            "archived_at_real": self.archived_at_real.isoformat() if self.archived_at_real else None,
            "anchor_date": self.anchor_date.isoformat() if self.anchor_date else None,
            "expire_at": self.expire_at.isoformat() if self.expire_at else None,
        }
