from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from linger_core.memory.event_memory_entry import EventMemoryEntry
from linger_core.memory.event_memory_store import EventMemoryStore
from linger_core.shared.enums import EventStatus, EventType


BACKREFERENCE_KEYWORDS = [
    "还是", "那件事", "那个", "这件事", "后来", "这个",
    "上次", "之前说的", "刚才", "之前", "又",
]


@dataclass
class EventContextBundle:
    active_events: List[Dict[str, Any]] = field(default_factory=list)
    unresolved_events: List[Dict[str, Any]] = field(default_factory=list)
    high_emotion_events: List[Dict[str, Any]] = field(default_factory=list)
    recent_events: List[Dict[str, Any]] = field(default_factory=list)
    has_unresolved: bool = False
    has_high_emotion: bool = False
    max_unresolved_score: float = 0.0
    max_emotion_peak: float = 0.0
    top_event_summary: str = ""
    top_event_title: str = ""
    event_count: int = 0
    active_event_count: int = 0
    should_follow_up: bool = False
    follow_up_hints: List[str] = field(default_factory=list)
    matched_event_id: str = ""
    matched_topic_key: str = ""
    continuation_likely: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "active_events": self.active_events,
            "unresolved_events": self.unresolved_events,
            "high_emotion_events": self.high_emotion_events,
            "recent_events": self.recent_events,
            "has_unresolved": self.has_unresolved,
            "has_high_emotion": self.has_high_emotion,
            "max_unresolved_score": self.max_unresolved_score,
            "max_emotion_peak": self.max_emotion_peak,
            "top_event_summary": self.top_event_summary,
            "top_event_title": self.top_event_title,
            "event_count": self.event_count,
            "active_event_count": self.active_event_count,
            "should_follow_up": self.should_follow_up,
            "follow_up_hints": self.follow_up_hints,
            "matched_event_id": self.matched_event_id,
            "matched_topic_key": self.matched_topic_key,
            "continuation_likely": self.continuation_likely,
        }


class EventRecall:
    def __init__(
        self,
        max_active_events: int = 5,
        max_unresolved: int = 3,
        max_high_emotion: int = 3,
        max_recent: int = 5,
        followup_unresolved_threshold: float = 0.4,
        followup_emotion_threshold: float = 0.6,
        memory_ttl=None,  # T5: §5.1.2 anchor_date 分段加权参数源
    ):
        from linger_core.config.memory_ttl_config import MemoryTTLConfig
        self._max_active = max_active_events
        self._max_unresolved = max_unresolved
        self._max_high_emotion = max_high_emotion
        self._max_recent = max_recent
        self._followup_unresolved_threshold = followup_unresolved_threshold
        self._followup_emotion_threshold = followup_emotion_threshold
        self._memory_ttl = memory_ttl or MemoryTTLConfig()

    def _anchor_bias(self, entry, real_now: datetime) -> float:
        """T5: spec §4.6 — 临近 anchor_date 召回加权。

        phase A (anchor 前 0..pre_window 天)         → +0.4
        phase B (anchor 后 0..post_window 天)        → +0.2
        phase C (post_window..fadeout 天，淡出)       → +0.05
        其余                                         → 0.0
        """
        if entry.anchor_date is None:
            return 0.0
        cfg = self._memory_ttl
        days_until = (entry.anchor_date - real_now).total_seconds() / 86400.0
        days_since = -days_until

        if 0 <= days_until <= cfg.anchor_recall_window_pre_days:
            return 0.4
        if 0 < days_since <= cfg.anchor_recall_window_post_days:
            return 0.2
        if (cfg.anchor_recall_window_post_days < days_since
                <= cfg.anchor_recall_fadeout_days):
            return 0.05
        return 0.0

    def recall(
        self,
        store: EventMemoryStore,
        current_message: str = "",
        real_now: Optional[datetime] = None,
    ) -> EventContextBundle:
        real_now = real_now or datetime.now()
        active = store.get_active()
        unresolved = store.get_unresolved(min_score=self._followup_unresolved_threshold)
        high_emotion = store.get_by_type(EventType.HIGH_EMOTION)
        recent = store.get_recent(n=self._max_recent)

        # T5: 排序综合 recall_priority + anchor_bias
        def _score(e):
            return e.recall_priority + self._anchor_bias(e, real_now)
        active.sort(key=_score, reverse=True)
        high_emotion.sort(key=lambda e: e.emotion_peak, reverse=True)

        if current_message:
            active = self._apply_backreference_bonus(active, current_message)
            active.sort(key=_score, reverse=True)

        active_dicts = [self._event_to_context(e) for e in active[:self._max_active]]
        unresolved_dicts = [self._event_to_context(e) for e in unresolved[:self._max_unresolved]]
        high_emotion_dicts = [self._event_to_context(e) for e in high_emotion[:self._max_high_emotion]]
        recent_dicts = [self._event_to_context(e) for e in recent[:self._max_recent]]

        has_unresolved = len(unresolved) > 0
        has_high_emotion = len(high_emotion) > 0
        max_unresolved_score = max((e.unresolved_score for e in unresolved), default=0.0)
        max_emotion_peak = max((e.emotion_peak for e in high_emotion), default=0.0)

        top_event = active[0] if active else None
        top_event_summary = top_event.summary if top_event else ""
        top_event_title = top_event.title if top_event else ""

        should_follow_up = False
        follow_up_hints: List[str] = []

        for e in unresolved:
            if e.unresolved_score >= self._followup_unresolved_threshold:
                should_follow_up = True
                follow_up_hints.append(f"未决事件: {e.title}")

        for e in high_emotion:
            if e.emotion_peak >= self._followup_emotion_threshold and e.is_active():
                should_follow_up = True
                follow_up_hints.append(f"情绪事件: {e.title}")

        matched_event_id = ""
        matched_topic_key = ""
        continuation_likely = False

        if current_message and active:
            has_backref = any(kw in current_message for kw in BACKREFERENCE_KEYWORDS)
            if has_backref and active:
                matched_event_id = active[0].event_id
                matched_topic_key = active[0].topic_key
                continuation_likely = True
            elif active and active[0].continuity_score >= 0.6:
                matched_event_id = active[0].event_id
                matched_topic_key = active[0].topic_key
                continuation_likely = True

        return EventContextBundle(
            active_events=active_dicts,
            unresolved_events=unresolved_dicts,
            high_emotion_events=high_emotion_dicts,
            recent_events=recent_dicts,
            has_unresolved=has_unresolved,
            has_high_emotion=has_high_emotion,
            max_unresolved_score=max_unresolved_score,
            max_emotion_peak=max_emotion_peak,
            top_event_summary=top_event_summary,
            top_event_title=top_event_title,
            event_count=store.count,
            active_event_count=store.active_count,
            should_follow_up=should_follow_up,
            follow_up_hints=follow_up_hints,
            matched_event_id=matched_event_id,
            matched_topic_key=matched_topic_key,
            continuation_likely=continuation_likely,
        )

    def recall_for_response(
        self,
        store: EventMemoryStore,
        user_message: str = "",
    ) -> EventContextBundle:
        bundle = self.recall(store, current_message=user_message)

        if user_message:
            keyword_events = store.find_by_keyword(user_message[:10])
            if keyword_events:
                for e in keyword_events[:2]:
                    ctx = self._event_to_context(e)
                    if ctx not in bundle.recent_events:
                        bundle.recent_events.append(ctx)

        return bundle

    def _apply_backreference_bonus(
        self,
        active: List[EventMemoryEntry],
        current_message: str,
    ) -> List[EventMemoryEntry]:
        has_backref = any(kw in current_message for kw in BACKREFERENCE_KEYWORDS)
        if not has_backref:
            return active

        for e in active:
            e.boost_priority(0.2)

        return active

    def _event_to_context(self, event: EventMemoryEntry) -> Dict[str, Any]:
        return {
            "event_id": event.event_id,
            "event_type": event.event_type.value,
            "title": event.title,
            "display_title": event.display_title,
            "summary": event.summary,
            "status": event.status.value,
            "emotion_label": event.emotion_label,
            "emotion_peak": event.emotion_peak,
            "importance": event.importance,
            "unresolved_score": event.unresolved_score,
            "mention_count": event.mention_count,
            "recall_priority": event.recall_priority,
            "is_user_core_event": event.is_user_core_event,
            "last_user_message": event.last_user_message,
            "resolution_hint": event.resolution_hint,
            "topic_key": event.topic_key,
            "topic_summary": event.topic_summary,
        }
