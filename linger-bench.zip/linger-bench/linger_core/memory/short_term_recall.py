from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from linger_core.memory.short_term_memory import ShortTermMemory


@dataclass
class RecentContextBundle:
    recent_user_messages: List[str] = field(default_factory=list)
    recent_assistant_messages: List[str] = field(default_factory=list)
    recent_emotion_trend: List[Dict[str, Any]] = field(default_factory=list)
    recent_unfinished_threads: List[Dict[str, Any]] = field(default_factory=list)
    latest_followup_hook_id: str = ""
    latest_speak_mode: str = ""
    latest_pause_signal: bool = False
    turn_count: int = 0
    last_assistant_speak_mode: str = ""
    last_assistant_had_followup: bool = False
    recent_comfort_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "recent_user_messages": self.recent_user_messages,
            "recent_assistant_messages": self.recent_assistant_messages,
            "recent_emotion_trend": self.recent_emotion_trend,
            "recent_unfinished_threads": self.recent_unfinished_threads,
            "latest_followup_hook_id": self.latest_followup_hook_id,
            "latest_speak_mode": self.latest_speak_mode,
            "latest_pause_signal": self.latest_pause_signal,
            "turn_count": self.turn_count,
            "last_assistant_speak_mode": self.last_assistant_speak_mode,
            "last_assistant_had_followup": self.last_assistant_had_followup,
            "recent_comfort_count": self.recent_comfort_count,
        }


class ShortTermRecall:
    def recall(self, memory: ShortTermMemory) -> RecentContextBundle:
        recent_user = memory.get_latest_user(n=3)
        recent_assistant = memory.get_latest_assistant(n=3)
        recent_all = memory.get_recent(n=6)

        emotion_trend = []
        for entry in recent_all:
            if entry.emotion_snapshot:
                emotion_trend.append({
                    "turn_id": entry.turn_id,
                    "speaker": entry.speaker,
                    "emotion": entry.emotion_snapshot.get("emotion", "unknown"),
                    "intensity": entry.emotion_snapshot.get("intensity", 0.0),
                })

        unfinished = []
        entries_with_followup = memory.get_entries_with_followup()
        for entry in entries_with_followup:
            unfinished.append({
                "turn_id": entry.turn_id,
                "speaker": entry.speaker,
                "message": entry.message[:50],
                "followup_hook_id": entry.followup_hook_id,
                "speak_mode": entry.speak_mode,
            })

        latest_followup_id = ""
        latest_speak_mode = ""
        latest_pause = False
        last_speak_mode = ""
        last_had_followup = False
        comfort_count = 0

        if recent_assistant:
            last = recent_assistant[-1]
            latest_speak_mode = last.speak_mode
            last_speak_mode = last.speak_mode
            last_had_followup = bool(last.followup_hook_id)
            latest_followup_id = last.followup_hook_id
            if last.action_plan_snapshot:
                latest_pause = last.action_plan_snapshot.get("should_pause", False) or last.action_plan_snapshot.get("pause_required", False)

        for entry in recent_assistant:
            if "comfort" in entry.tags:
                comfort_count += 1

        turn_ids = set(e.turn_id for e in recent_all)

        return RecentContextBundle(
            recent_user_messages=[e.message for e in recent_user],
            recent_assistant_messages=[e.message for e in recent_assistant],
            recent_emotion_trend=emotion_trend,
            recent_unfinished_threads=unfinished,
            latest_followup_hook_id=latest_followup_id,
            latest_speak_mode=latest_speak_mode,
            latest_pause_signal=latest_pause,
            turn_count=len(turn_ids),
            last_assistant_speak_mode=last_speak_mode,
            last_assistant_had_followup=last_had_followup,
            recent_comfort_count=comfort_count,
        )
