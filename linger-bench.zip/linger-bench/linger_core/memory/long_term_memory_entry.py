from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.shared.enums import LongTermMemoryCategory, LongTermMemoryStatus


@dataclass
class LongTermMemoryEntry:
    memory_id: str
    category: LongTermMemoryCategory
    key: str
    value: str
    summary: str = ""
    confidence: float = 0.5
    stability: float = 0.5
    importance: float = 0.5
    visibility: str = "system"
    source_event_ids: List[str] = field(default_factory=list)
    source_digest_ids: List[str] = field(default_factory=list)
    first_seen_real: Optional[datetime] = None
    last_seen_real: Optional[datetime] = None
    last_confirmed_real: Optional[datetime] = None
    last_used_real: Optional[datetime] = None
    confirm_count: int = 0
    contradict_count: int = 0
    status: LongTermMemoryStatus = LongTermMemoryStatus.TENTATIVE
    decay_policy: str = "normal"
    tags: List[str] = field(default_factory=list)

    def confirm(self, real_now: Optional[datetime] = None) -> None:
        self.confirm_count += 1
        self.confidence = min(1.0, self.confidence + 0.1)
        self.stability = min(1.0, self.stability + 0.05)
        if real_now:
            self.last_confirmed_real = real_now
            self.last_seen_real = real_now
        if self.confirm_count >= 3 and self.status == LongTermMemoryStatus.TENTATIVE:
            self.status = LongTermMemoryStatus.ACTIVE

    def contradict(self, real_now: Optional[datetime] = None) -> None:
        self.contradict_count += 1
        self.confidence = max(0.0, self.confidence - 0.2)
        self.stability = max(0.0, self.stability - 0.1)
        if real_now:
            self.last_seen_real = real_now
        if self.contradict_count >= 2 and self.confidence < 0.3:
            self.status = LongTermMemoryStatus.ARCHIVED

    def touch_used(self, real_now: Optional[datetime] = None) -> None:
        if real_now:
            self.last_used_real = real_now
            self.last_seen_real = real_now

    def cool_down(self, delta: float = 0.05) -> None:
        if self.status == LongTermMemoryStatus.ACTIVE:
            self.confidence = max(0.0, self.confidence - delta)
            if self.confidence < 0.3:
                self.status = LongTermMemoryStatus.COOLED

    def archive(self) -> None:
        self.status = LongTermMemoryStatus.ARCHIVED
        self.confidence = 0.0

    def refresh(self, delta: float = 0.1) -> None:
        if self.status in (LongTermMemoryStatus.COOLED, LongTermMemoryStatus.TENTATIVE):
            self.confidence = min(1.0, self.confidence + delta)
            if self.confidence >= 0.5:
                self.status = LongTermMemoryStatus.ACTIVE

    def is_active(self) -> bool:
        return self.status in (LongTermMemoryStatus.ACTIVE, LongTermMemoryStatus.TENTATIVE)

    def effective_score(self) -> float:
        return (self.confidence * 0.4 + self.stability * 0.3 + self.importance * 0.3)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "memory_id": self.memory_id,
            "category": self.category.value,
            "key": self.key,
            "value": self.value,
            "summary": self.summary,
            "confidence": self.confidence,
            "stability": self.stability,
            "importance": self.importance,
            "visibility": self.visibility,
            "source_event_ids": self.source_event_ids,
            "source_digest_ids": self.source_digest_ids,
            "first_seen_real": self.first_seen_real.isoformat() if self.first_seen_real else None,
            "last_seen_real": self.last_seen_real.isoformat() if self.last_seen_real else None,
            "last_confirmed_real": self.last_confirmed_real.isoformat() if self.last_confirmed_real else None,
            "last_used_real": self.last_used_real.isoformat() if self.last_used_real else None,
            "confirm_count": self.confirm_count,
            "contradict_count": self.contradict_count,
            "status": self.status.value,
            "decay_policy": self.decay_policy,
            "tags": self.tags,
        }
