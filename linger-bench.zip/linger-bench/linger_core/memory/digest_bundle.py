from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.shared.enums import DigestWindowType


@dataclass
class DigestBundle:
    digest_id: str
    window_type: DigestWindowType
    start_time: datetime
    end_time: datetime
    main_topics: List[str] = field(default_factory=list)
    emotion_trend: Dict[str, Any] = field(default_factory=dict)
    high_importance_events: List[str] = field(default_factory=list)
    unresolved_events: List[str] = field(default_factory=list)
    resolved_events: List[str] = field(default_factory=list)
    interaction_density: float = 0.0
    relationship_trend: str = ""
    recommended_style: str = ""
    recommended_openers: List[str] = field(default_factory=list)
    summary_short: str = ""
    summary_full: str = ""
    source_event_ids: List[str] = field(default_factory=list)
    generated_at: Optional[datetime] = None
    version: int = 1

    def is_expired(self, now: Optional[datetime] = None) -> bool:
        if self.window_type == DigestWindowType.THREE_DAY:
            threshold_hours = 72
        elif self.window_type == DigestWindowType.SEVEN_DAY:
            threshold_hours = 168
        else:
            threshold_hours = 336
        check_time = now or datetime.now()
        if self.generated_at:
            elapsed = (check_time - self.generated_at).total_seconds() / 3600
            return elapsed > threshold_hours
        return False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "digest_id": self.digest_id,
            "window_type": self.window_type.value,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat(),
            "main_topics": self.main_topics,
            "emotion_trend": self.emotion_trend,
            "high_importance_events": self.high_importance_events,
            "unresolved_events": self.unresolved_events,
            "resolved_events": self.resolved_events,
            "interaction_density": self.interaction_density,
            "relationship_trend": self.relationship_trend,
            "recommended_style": self.recommended_style,
            "recommended_openers": self.recommended_openers,
            "summary_short": self.summary_short,
            "summary_full": self.summary_full,
            "source_event_ids": self.source_event_ids,
            "generated_at": self.generated_at.isoformat() if self.generated_at else None,
            "version": self.version,
        }
