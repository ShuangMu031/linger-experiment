from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.memory.event_memory_entry import EventMemoryEntry
from linger_core.memory.event_memory_store import EventMemoryStore
from linger_core.memory.relationship_snapshot import RelationshipSnapshot


POSITIVE_EMOTIONS = {"happy", "calm", "surprised"}
NEGATIVE_EMOTIONS = {"sad", "angry", "anxious"}


class RelationshipTracker:
    def __init__(self, snapshot: Optional[RelationshipSnapshot] = None):
        self._snapshot = snapshot or RelationshipSnapshot()

    @property
    def snapshot(self) -> RelationshipSnapshot:
        return self._snapshot

    def update_from_interaction(
        self,
        user_message: str,
        emotion_label: str,
        intensity: float,
        real_now: Optional[datetime] = None,
    ) -> None:
        now = real_now or datetime.now()
        is_positive = emotion_label in POSITIVE_EMOTIONS
        self._snapshot.record_interaction(is_positive, now)

        if is_positive:
            self._snapshot.familiarity = min(1.0, self._snapshot.familiarity + 0.01)
            self._snapshot.initiative_affinity = min(1.0, self._snapshot.initiative_affinity + 0.005)
        elif emotion_label in NEGATIVE_EMOTIONS:
            self._snapshot.volatility = min(1.0, self._snapshot.volatility + 0.02)
            if intensity > 0.7:
                self._snapshot.trust_level = max(0.0, self._snapshot.trust_level - 0.01)

        self._snapshot.touch(now)

    def update_from_events(
        self,
        event_store: EventMemoryStore,
        real_now: Optional[datetime] = None,
    ) -> None:
        now = real_now or datetime.now()
        active = event_store.get_active()
        resolved = event_store.get_by_status(
            __import__("linger_core.shared.enums", fromlist=["EventStatus"]).EventStatus.RESOLVED
        )

        positive_resolved = sum(1 for e in resolved if e.emotion_label in POSITIVE_EMOTIONS)
        negative_resolved = sum(1 for e in resolved if e.emotion_label in NEGATIVE_EMOTIONS)

        if positive_resolved > negative_resolved:
            self._snapshot.trust_level = min(1.0, self._snapshot.trust_level + 0.01)
        elif negative_resolved > positive_resolved:
            self._snapshot.trust_level = max(0.0, self._snapshot.trust_level - 0.01)

        unresolved = event_store.get_unresolved()
        if len(unresolved) > 3:
            self._snapshot.volatility = min(1.0, self._snapshot.volatility + 0.02)

        self._snapshot.familiarity = min(1.0, self._snapshot.familiarity + len(active) * 0.005)
        self._snapshot.touch(now)

    def update_from_digest(self, digest_data: Dict[str, Any]) -> None:
        self._snapshot.update_from_digest(digest_data)

    def assess_distance(self) -> str:
        warmth = self._snapshot.effective_warmth()
        trust = self._snapshot.trust_level
        volatility = self._snapshot.volatility

        if warmth >= 0.7 and trust >= 0.7 and volatility < 0.3:
            self._snapshot.preferred_distance = "close"
        elif warmth >= 0.4 and trust >= 0.4:
            self._snapshot.preferred_distance = "moderate"
        elif volatility > 0.5:
            self._snapshot.preferred_distance = "cautious"
        else:
            self._snapshot.preferred_distance = "moderate"

        return self._snapshot.preferred_distance

    def should_initiate(self) -> bool:
        if self._snapshot.preferred_distance == "close":
            return self._snapshot.initiative_affinity > 0.4
        elif self._snapshot.preferred_distance == "moderate":
            return self._snapshot.initiative_affinity > 0.6
        return False

    def get_risk_flags(self) -> List[str]:
        flags = list(self._snapshot.risk_flags)
        if self._snapshot.volatility > 0.7:
            flags.append("high_volatility")
        if self._snapshot.trust_level < 0.2:
            flags.append("low_trust")
        if self._snapshot.total_interactions > 0:
            neg_ratio = self._snapshot.negative_interactions / self._snapshot.total_interactions
            if neg_ratio > 0.5:
                flags.append("high_negative_ratio")
        return flags
