from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.memory.digest_bundle import DigestBundle
from linger_core.shared.enums import DigestWindowType


class DigestRecall:
    def __init__(self, bundles: Optional[List[DigestBundle]] = None):
        self._bundles: Dict[str, DigestBundle] = {}
        if bundles:
            for b in bundles:
                self._bundles[b.digest_id] = b

    def add_bundle(self, bundle: DigestBundle) -> None:
        self._bundles[bundle.digest_id] = bundle

    def get(self, digest_id: str) -> Optional[DigestBundle]:
        return self._bundles.get(digest_id)

    def get_latest(self, window_type: Optional[DigestWindowType] = None) -> Optional[DigestBundle]:
        candidates = list(self._bundles.values())
        if window_type:
            candidates = [b for b in candidates if b.window_type == window_type]
        if not candidates:
            return None
        candidates.sort(key=lambda b: b.generated_at or datetime.min, reverse=True)
        return candidates[0]

    def get_recent(self, n: int = 3) -> List[DigestBundle]:
        bundles = list(self._bundles.values())
        bundles.sort(key=lambda b: b.generated_at or datetime.min, reverse=True)
        return bundles[:n]

    def recall_unresolved_topics(self) -> List[str]:
        topics: List[str] = []
        latest_3d = self.get_latest(DigestWindowType.THREE_DAY)
        latest_7d = self.get_latest(DigestWindowType.SEVEN_DAY)
        for bundle in [latest_3d, latest_7d]:
            if bundle and bundle.unresolved_events:
                for topic in bundle.main_topics:
                    if topic not in topics:
                        topics.append(topic)
        return topics

    def recall_emotion_trend(self) -> Dict[str, Any]:
        latest = self.get_latest()
        if latest and latest.emotion_trend:
            return latest.emotion_trend
        return {}

    def recall_relationship_trend(self) -> str:
        latest = self.get_latest()
        if latest:
            return latest.relationship_trend
        return "stable"

    def recall_recommended_style(self) -> str:
        latest = self.get_latest()
        if latest:
            return latest.recommended_style
        return "balanced"

    def recall_openers(self) -> List[str]:
        latest = self.get_latest()
        if latest:
            return latest.recommended_openers
        return []

    def build_context_summary(self) -> str:
        latest = self.get_latest()
        if not latest:
            return ""
        return latest.summary_short

    def build_full_context(self) -> str:
        latest = self.get_latest()
        if not latest:
            return ""
        return latest.summary_full
