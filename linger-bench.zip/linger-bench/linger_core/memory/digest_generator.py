from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from linger_core.memory.digest_bundle import DigestBundle
from linger_core.memory.event_memory_entry import EventMemoryEntry
from linger_core.memory.event_memory_store import EventMemoryStore
from linger_core.memory.relationship_snapshot import RelationshipSnapshot
from linger_core.shared.enums import DigestWindowType, EventStatus
from linger_core.shared.ids import generate_id


class DigestGenerator:
    def __init__(self):
        self._bundles: Dict[str, DigestBundle] = {}

    def generate(
        self,
        event_store: EventMemoryStore,
        window_type: DigestWindowType,
        relationship: Optional[RelationshipSnapshot] = None,
        real_now: Optional[datetime] = None,
    ) -> DigestBundle:
        now = real_now or datetime.now()
        start_time = self._compute_start(now, window_type)

        events_in_window = self._filter_events_by_time(event_store, start_time, now)

        main_topics = self._extract_main_topics(events_in_window)
        emotion_trend = self._compute_emotion_trend(events_in_window)
        high_importance = [
            e.event_id for e in events_in_window if e.importance >= 0.7
        ]
        unresolved = [
            e.event_id for e in events_in_window
            if e.is_active() and e.unresolved_score >= 0.3
        ]
        resolved = [
            e.event_id for e in events_in_window
            if e.status == EventStatus.RESOLVED
        ]
        interaction_density = self._compute_density(events_in_window, start_time, now)
        relationship_trend = self._infer_relationship_trend(events_in_window, relationship)
        recommended_style = self._recommend_style(emotion_trend, relationship_trend)
        recommended_openers = self._recommend_openers(main_topics, relationship_trend)
        summary_short = self._generate_short_summary(main_topics, emotion_trend, interaction_density)
        summary_full = self._generate_full_summary(
            main_topics, emotion_trend, high_importance, unresolved, resolved,
            interaction_density, relationship_trend,
        )

        bundle = DigestBundle(
            digest_id=f"dig_{generate_id()[:10]}",
            window_type=window_type,
            start_time=start_time,
            end_time=now,
            main_topics=main_topics,
            emotion_trend=emotion_trend,
            high_importance_events=high_importance,
            unresolved_events=unresolved,
            resolved_events=resolved,
            interaction_density=interaction_density,
            relationship_trend=relationship_trend,
            recommended_style=recommended_style,
            recommended_openers=recommended_openers,
            summary_short=summary_short,
            summary_full=summary_full,
            source_event_ids=[e.event_id for e in events_in_window],
            generated_at=now,
        )

        self._bundles[bundle.digest_id] = bundle
        return bundle

    def get(self, digest_id: str) -> Optional[DigestBundle]:
        return self._bundles.get(digest_id)

    def get_latest(self, window_type: Optional[DigestWindowType] = None) -> Optional[DigestBundle]:
        candidates = list(self._bundles.values())
        if window_type:
            candidates = [b for b in candidates if b.window_type == window_type]
        if not candidates:
            return None
        candidates.sort(key=lambda b: b.generated_at or datetime.min, reverse=True)
        return candidates[0]

    def get_all(self) -> List[DigestBundle]:
        return list(self._bundles.values())

    def add_bundle(self, bundle: DigestBundle) -> None:
        self._bundles[bundle.digest_id] = bundle

    def _compute_start(self, now: datetime, window_type: DigestWindowType) -> datetime:
        if window_type == DigestWindowType.THREE_DAY:
            return now - timedelta(days=3)
        elif window_type == DigestWindowType.SEVEN_DAY:
            return now - timedelta(days=7)
        else:
            return now - timedelta(days=14)

    def _filter_events_by_time(
        self, event_store: EventMemoryStore, start: datetime, end: datetime
    ) -> List[EventMemoryEntry]:
        results = []
        for event in event_store.all_events:
            if event.first_seen_real and start <= event.first_seen_real <= end:
                results.append(event)
            elif event.last_seen_real and start <= event.last_seen_real <= end:
                results.append(event)
        return results

    def _extract_main_topics(self, events: List[EventMemoryEntry]) -> List[str]:
        topic_counts: Dict[str, int] = {}
        for e in events:
            topic = e.topic_key or e.topic_summary or e.title[:15]
            if topic:
                topic_counts[topic] = topic_counts.get(topic, 0) + e.mention_count
        sorted_topics = sorted(topic_counts.items(), key=lambda x: x[1], reverse=True)
        return [t[0] for t in sorted_topics[:5]]

    def _compute_emotion_trend(self, events: List[EventMemoryEntry]) -> Dict[str, Any]:
        emotion_counts: Dict[str, int] = {}
        for e in events:
            if e.emotion_label:
                emotion_counts[e.emotion_label] = emotion_counts.get(e.emotion_label, 0) + 1
        total = sum(emotion_counts.values()) or 1
        distribution = {k: round(v / total, 2) for k, v in emotion_counts.items()}
        dominant = max(emotion_counts.items(), key=lambda x: x[1])[0] if emotion_counts else "neutral"
        avg_peak = 0.0
        if events:
            avg_peak = sum(e.emotion_peak for e in events) / len(events)
        return {
            "dominant": dominant,
            "distribution": distribution,
            "avg_peak": round(avg_peak, 2),
        }

    def _compute_density(
        self, events: List[EventMemoryEntry], start: datetime, end: datetime
    ) -> float:
        span_hours = max((end - start).total_seconds() / 3600, 1.0)
        return round(len(events) / span_hours, 4)

    def _infer_relationship_trend(
        self, events: List[EventMemoryEntry], relationship: Optional[RelationshipSnapshot]
    ) -> str:
        positive_count = sum(1 for e in events if e.emotion_label in ("happy", "calm"))
        negative_count = sum(1 for e in events if e.emotion_label in ("sad", "angry", "anxious"))
        if positive_count > negative_count * 2:
            return "warming"
        elif negative_count > positive_count * 2:
            return "cooling"
        elif negative_count > 0 and positive_count > 0:
            return "volatile"
        return "stable"

    def _recommend_style(self, emotion_trend: Dict[str, Any], relationship_trend: str) -> str:
        dominant = emotion_trend.get("dominant", "neutral")
        if dominant in ("sad", "anxious"):
            return "gentle_supportive"
        elif dominant == "angry":
            return "calm_patient"
        elif relationship_trend == "warming":
            return "warm_friendly"
        elif relationship_trend == "cooling":
            return "respectful_cautious"
        return "balanced"

    def _recommend_openers(self, topics: List[str], relationship_trend: str) -> List[str]:
        openers = []
        if topics:
            openers.append(f"关于{topics[0]}，最近怎么样？")
        if relationship_trend == "warming":
            openers.append("最近感觉聊得挺开心的~")
        elif relationship_trend == "cooling":
            openers.append("好久没聊了，最近还好吗？")
        return openers[:3]

    def _generate_short_summary(
        self, topics: List[str], emotion_trend: Dict[str, Any], density: float
    ) -> str:
        topic_str = "、".join(topics[:3]) if topics else "无明确主题"
        dominant = emotion_trend.get("dominant", "neutral")
        return f"近期主要话题: {topic_str}，情绪基调: {dominant}，互动密度: {density:.2f}/h"

    def _generate_full_summary(
        self,
        topics: List[str],
        emotion_trend: Dict[str, Any],
        high_importance: List[str],
        unresolved: List[str],
        resolved: List[str],
        density: float,
        relationship_trend: str,
    ) -> str:
        parts = []
        topic_str = "、".join(topics[:5]) if topics else "无"
        parts.append(f"主要话题: {topic_str}")
        dominant = emotion_trend.get("dominant", "neutral")
        parts.append(f"情绪基调: {dominant}")
        parts.append(f"高重要性事件: {len(high_importance)}件")
        parts.append(f"未解决事件: {len(unresolved)}件")
        parts.append(f"已解决事件: {len(resolved)}件")
        parts.append(f"互动密度: {density:.2f}/h")
        parts.append(f"关系趋势: {relationship_trend}")
        return "；".join(parts)
