import re
from datetime import datetime
from typing import Any, Dict, List, Optional, Set

from linger_core.memory.event_memory_entry import EventMemoryEntry
from linger_core.memory.event_memory_store import EventMemoryStore
from linger_core.memory.long_term_memory_entry import LongTermMemoryEntry
from linger_core.memory.long_term_memory_store import LongTermMemoryStore
from linger_core.shared.enums import (
    EventStatus,
    EventType,
    LongTermMemoryCategory,
    LongTermMemoryStatus,
)


PREFERENCE_KEYWORDS = {
    "喜欢", "偏好", "最爱", "讨厌", "不喜欢", "最爱", "习惯",
    "prefer", "like", "hate", "love", "always", "never",
}
STYLE_KEYWORDS = {
    "简洁", "详细", "正式", "随意", "幽默", "严肃", "温柔", "直接",
    "formal", "casual", "humor", "serious", "gentle", "direct",
}
CONCERN_KEYWORDS = {
    "担心", "焦虑", "害怕", "忧虑", "在意", "关注",
    "worry", "anxious", "fear", "concern", "care",
}
IDENTITY_KEYWORDS = {
    # 自我陈述
    "我是", "我叫", "我的名字", "我是做", "我的职业", "我学的是",
    # 家庭/亲属（T6 §5.1.3 用户主动声明扩展）
    "我妈", "我爸", "我家", "我老婆", "我老公", "我儿子",
    "我女儿", "我弟弟", "我哥", "我姐", "我妹", "我外婆",
    "我外公", "我奶奶", "我爷爷",
    "I am", "my name", "I work", "I study",
}
HABIT_KEYWORDS = {
    "每天", "经常", "总是", "通常", "一般",
    "every day", "always", "usually", "often", "normally",
}

# 通用第一人称自述模式（结构性，与任何具体领域/实验内容无关）
_FACT_ATTR_STOP = {"不", "没", "也", "就", "还", "真", "其实", "觉得", "以为", "想", "认为", "知道", "可能", "应该"}
_FACT_VAL_STOP = {"谁", "啥", "什么", "哪", "哪儿", "怎么", "这样", "那样"}
_FACT_PAT_X_IS_Y = re.compile(
    r"我的?([一-龥]{1,6}?)(?:是|叫|姓)([一-龥A-Za-z0-9]{1,12})"
)
_FACT_PAT_SELF_ROLE = re.compile(r"我是([一-龥]{1,8})")


class LongTermExtractor:
    def __init__(self, store: LongTermMemoryStore):
        self._store = store

    # ─── T6: §5.1.3 三条强抽规则 ─────────────────────────────

    def extract_from_user_declaration(
        self,
        user_text: str,
        real_now: Optional[datetime] = None,
        source_event_id: str = "",
    ) -> List[LongTermMemoryEntry]:
        """规则 1：用户主动声明（"我是X""我妈叫Y"）→ 强抽身份线索。"""
        if not user_text:
            return []
        now = real_now or datetime.now()
        out: List[LongTermMemoryEntry] = []
        seen_keys: Set[str] = set()

        identity = self._detect_identity(user_text)
        if identity:
            key = f"identity:{identity['key']}"
            if key not in seen_keys and self._store.get_by_key(key) is None:
                entry = self._store.create(
                    category=LongTermMemoryCategory.IDENTITY_HINT,
                    key=key,
                    value=identity["value"],
                    real_now=now,
                    summary=identity["value"][:40],
                    confidence=0.75,
                    importance=0.6,
                    source_event_ids=[source_event_id] if source_event_id else [],
                    tags=["identity", "user_declaration"],
                )
                out.append(entry)
                seen_keys.add(key)

        preference = self._detect_preference(user_text)
        if preference:
            key = f"pref:{preference['key']}"
            if key not in seen_keys and self._store.get_by_key(key) is None:
                entry = self._store.create(
                    category=LongTermMemoryCategory.PREFERENCE,
                    key=key,
                    value=preference["value"],
                    real_now=now,
                    summary=preference["value"][:40],
                    confidence=0.65,
                    importance=0.55,
                    source_event_ids=[source_event_id] if source_event_id else [],
                    tags=["preference", "user_declaration"],
                )
                out.append(entry)
                seen_keys.add(key)

        return out

    def extract_from_recurring_events(
        self,
        event_store: EventMemoryStore,
        min_recurrence: int = 3,
        real_now: Optional[datetime] = None,
    ) -> List[LongTermMemoryEntry]:
        """规则 2：mention_count ≥ min_recurrence → 抽 HABIT 长期记忆。"""
        now = real_now or datetime.now()
        out: List[LongTermMemoryEntry] = []
        for event in event_store.get_active():
            if event.mention_count < min_recurrence:
                continue
            key = f"habit:{event.topic_key or event.event_id}"
            if self._store.get_by_key(key) is not None:
                continue
            entry = self._store.create(
                category=LongTermMemoryCategory.HABIT,
                key=key,
                value=f"用户反复提及: {event.summary[:60]}",
                real_now=now,
                summary=f"反复提及({event.mention_count}次)",
                confidence=min(0.9, 0.4 + event.mention_count * 0.1),
                importance=event.importance,
                source_event_ids=[event.event_id],
                tags=["repeated", "recurring",
                      event.topic_key or event.event_type.value],
            )
            out.append(entry)
        return out

    def extract_from_high_emotion(
        self,
        event_store: EventMemoryStore,
        threshold: int = 80,
        real_now: Optional[datetime] = None,
    ) -> List[LongTermMemoryEntry]:
        """规则 3：event.emotion_peak * 100 ≥ threshold → 抽 CONCERN 长期记忆。

        threshold 单位与 EmotionInsight8d.dimensions 一致（0-100）；
        event.emotion_peak 是 0-1 浮点（旧 EmotionInsight 输出兼容）。
        """
        now = real_now or datetime.now()
        out: List[LongTermMemoryEntry] = []
        cutoff = threshold / 100.0
        for event in event_store.get_active():
            if event.emotion_peak < cutoff:
                continue
            key = f"high_emotion:{event.event_id}"
            if self._store.get_by_key(key) is not None:
                continue
            entry = self._store.create(
                category=LongTermMemoryCategory.CONCERN,
                key=key,
                value=event.summary[:80],
                real_now=now,
                summary=f"高强度情绪事件 ({event.emotion_peak:.2f})",
                confidence=min(0.95, 0.5 + event.emotion_peak * 0.4),
                importance=min(1.0, 0.7 + event.emotion_peak * 0.2),
                source_event_ids=[event.event_id],
                tags=["high_emotion", event.emotion_label or "unknown"],
            )
            out.append(entry)
        return out

    # ─── 既有：周期抽取 ─────────────────────────────────────────

    def extract_from_events(
        self,
        event_store: EventMemoryStore,
        real_now: Optional[datetime] = None,
    ) -> List[LongTermMemoryEntry]:
        now = real_now or datetime.now()
        new_entries: List[LongTermMemoryEntry] = []

        for event in event_store.get_active():
            candidates = self._extract_from_single_event(event, now)
            for candidate in candidates:
                existing = self._store.get_by_key(candidate["key"])
                if existing:
                    if existing.category == candidate["category"]:
                        existing.confirm(now)
                        if event.event_id not in existing.source_event_ids:
                            existing.source_event_ids.append(event.event_id)
                    else:
                        entry = self._store.create(
                            category=candidate["category"],
                            key=candidate["key"],
                            value=candidate["value"],
                            real_now=now,
                            summary=candidate.get("summary", ""),
                            confidence=candidate.get("confidence", 0.5),
                            importance=event.importance,
                            source_event_ids=[event.event_id],
                            tags=candidate.get("tags", []),
                        )
                        new_entries.append(entry)
                else:
                    entry = self._store.create(
                        category=candidate["category"],
                        key=candidate["key"],
                        value=candidate["value"],
                        real_now=now,
                        summary=candidate.get("summary", ""),
                        confidence=candidate.get("confidence", 0.5),
                        importance=event.importance,
                        source_event_ids=[event.event_id],
                        tags=candidate.get("tags", []),
                    )
                    new_entries.append(entry)

        return new_entries

    def _extract_from_single_event(
        self, event: EventMemoryEntry, now: datetime
    ) -> List[Dict[str, Any]]:
        candidates: List[Dict[str, Any]] = []
        text = f"{event.last_user_message} {event.summary}"

        if event.mention_count >= 3:
            candidates.append({
                "category": LongTermMemoryCategory.HABIT,
                "key": f"habit:{event.topic_key or event.title[:20]}",
                "value": f"用户反复提及: {event.summary[:60]}",
                "summary": f"反复提及({event.mention_count}次)",
                "confidence": min(0.9, 0.4 + event.mention_count * 0.1),
                "tags": ["repeated", event.topic_key] if event.topic_key else ["repeated"],
            })

        if event.is_user_core_event:
            candidates.append({
                "category": LongTermMemoryCategory.IDENTITY_HINT,
                "key": f"identity:{event.topic_key or event.title[:20]}",
                "value": event.summary[:80],
                "summary": f"核心身份线索: {event.summary[:40]}",
                "confidence": 0.7,
                "tags": ["core_identity", event.event_type.value],
            })

        preference = self._detect_preference(text)
        if preference:
            candidates.append({
                "category": LongTermMemoryCategory.PREFERENCE,
                "key": f"pref:{preference['key']}",
                "value": preference["value"],
                "summary": preference["value"][:40],
                "confidence": 0.6,
                "tags": ["preference", event.emotion_label],
            })

        style = self._detect_style(text)
        if style:
            candidates.append({
                "category": LongTermMemoryCategory.STYLE,
                "key": f"style:{style['key']}",
                "value": style["value"],
                "summary": style["value"][:40],
                "confidence": 0.5,
                "tags": ["style"],
            })

        concern = self._detect_concern(text)
        if concern:
            candidates.append({
                "category": LongTermMemoryCategory.CONCERN,
                "key": f"concern:{concern['key']}",
                "value": concern["value"],
                "summary": concern["value"][:40],
                "confidence": 0.6,
                "tags": ["concern", event.emotion_label],
            })

        identity = self._detect_identity(text)
        if identity:
            candidates.append({
                "category": LongTermMemoryCategory.IDENTITY_HINT,
                "key": f"identity:{identity['key']}",
                "value": identity["value"],
                "summary": identity["value"][:40],
                "confidence": 0.7,
                "tags": ["identity"],
            })

        return candidates

    def _detect_preference(self, text: str) -> Optional[Dict[str, str]]:
        for kw in PREFERENCE_KEYWORDS:
            if kw in text:
                idx = text.index(kw)
                snippet = text[max(0, idx - 5):idx + 20].strip()
                return {
                    "key": snippet[:15],
                    "value": f"偏好表达: {snippet}",
                }
        return None

    def _detect_style(self, text: str) -> Optional[Dict[str, str]]:
        for kw in STYLE_KEYWORDS:
            if kw in text:
                return {
                    "key": kw,
                    "value": f"风格倾向: {kw}",
                }
        return None

    def _detect_concern(self, text: str) -> Optional[Dict[str, str]]:
        for kw in CONCERN_KEYWORDS:
            if kw in text:
                idx = text.index(kw)
                snippet = text[max(0, idx - 5):idx + 20].strip()
                return {
                    "key": snippet[:15],
                    "value": f"关注点: {snippet}",
                }
        return None

    def _detect_identity(self, text: str) -> Optional[Dict[str, str]]:
        for kw in IDENTITY_KEYWORDS:
            if kw in text:
                idx = text.index(kw)
                snippet = text[max(0, idx):idx + 30].strip()
                return {
                    "key": snippet[:15],
                    "value": f"身份线索: {snippet}",
                }
        return None

    # ─── Task 2: 规则层用户事实抽取 ──────────────────────────────

    def extract_user_facts_rule(self, user_text: str) -> List[Dict[str, str]]:
        """规则快路径：从用户自述句抽 {attribute, value}。覆盖不到的交给 LLM 兜底。"""
        facts: List[Dict[str, str]] = []
        if not user_text:
            return facts
        seen = set()

        def add(attr: str, val: str) -> None:
            attr, val = attr.strip(), val.strip()
            if attr in _FACT_ATTR_STOP or val in _FACT_VAL_STOP:
                return
            if val and val[-1] in "吗呢吧啊嘛":  # 语气词结尾，多半不是事实
                return
            if attr and val and attr != val and (attr, val) not in seen:
                seen.add((attr, val))
                facts.append({"attribute": attr, "value": val})

        for m in _FACT_PAT_X_IS_Y.finditer(user_text):
            add(m.group(1), m.group(2))
        for m in _FACT_PAT_SELF_ROLE.finditer(user_text):
            add("身份", m.group(1))
        return facts

    def persist_user_facts(
        self, facts: List[Dict[str, str]], real_now: datetime
    ) -> List[LongTermMemoryEntry]:
        """把抽到的事实写入 LTM。confidence=0.8 抬高 effective_score 用于召回排序；tag=user_fact 是召回筛选键。"""
        out: List[LongTermMemoryEntry] = []
        for f in facts:
            attr = (f.get("attribute") or "").strip()
            val = (f.get("value") or "").strip()
            if not attr or not val:
                continue
            entry = self._store.find_or_create(
                category=LongTermMemoryCategory.IDENTITY_HINT,
                key=f"{attr}:{val}",
                value=val,
                real_now=real_now,
                summary=f"{attr}：{val}",
                confidence=0.8,
                importance=0.6,
                tags=["user_fact"],
            )
            out.append(entry)
        return out
