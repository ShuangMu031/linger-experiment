from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from linger_core.config.memory_ttl_config import MemoryTTLConfig
from linger_core.memory.event_memory_entry import EventMemoryEntry
from linger_core.memory.event_memory_store import EventMemoryStore
from linger_core.memory.future_time_detector import has_future_time_hint
from linger_core.memory.memory_entry import MemoryEntry
from linger_core.shared.enums import EmotionType, EventStatus, EventType


EMOTION_KEYWORDS = {
    "sad": ["难过", "伤心", "不开心", "哭", "痛", "悲伤", "失落", "崩溃", "受不了", "心碎", "绝望", "抑郁"],
    "angry": ["生气", "愤怒", "烦", "讨厌", "恨", "气死", "受不了", "恶心", "火大"],
    "anxious": ["焦虑", "担心", "害怕", "紧张", "不安", "恐惧", "慌", "压力", "焦虑症"],
    "happy": ["开心", "高兴", "幸福", "快乐", "喜欢", "爱", "棒", "太好了", "哈哈"],
    "surprised": ["没想到", "意外", "震惊", "天哪", "居然", "竟然"],
}

EXPERIENCE_KEYWORDS = [
    "经历", "遇到", "发生", "事情", "事件", "故事", "体验", "感受",
    "第一次", "终于", "突然", "原来", "后来", "之前", "那天",
]

UNRESOLVED_KEYWORDS = [
    "还没", "不知道", "怎么办", "纠结", "犹豫", "迷茫", "困惑",
    "还没想好", "不确定", "到底", "该不该", "是不是",
]

RESOLUTION_KEYWORDS = [
    "没事了", "好了", "解决了", "想通了", "决定了", "已经处理了",
    "不纠结了", "过去了", "不用管了", "放下了", "没事", "不用担心了",
]

BACKREFERENCE_KEYWORDS = [
    "还是", "那件事", "那个", "这件事", "后来", "这个",
    "上次", "之前说的", "刚才", "之前", "又",
]

NEGATIVE_EMOTIONS = {EmotionType.SAD, EmotionType.ANGRY, EmotionType.ANXIOUS}

TOPIC_KEY_MAP = {
    "sad": "emotional_distress",
    "angry": "emotional_distress",
    "anxious": "emotional_distress",
    "happy": "positive_experience",
    "surprised": "unexpected_event",
}


@dataclass
class ExtractionResult:
    new_events: List[EventMemoryEntry] = field(default_factory=list)
    updated_events: List[EventMemoryEntry] = field(default_factory=list)
    resolved_events: List[EventMemoryEntry] = field(default_factory=list)
    skipped: bool = True
    reason: str = ""
    primary_signal: str = ""


class EventExtractor:
    def __init__(
        self,
        high_emotion_threshold: float = 0.7,
        unresolved_threshold: float = 0.4,
        mention_boost_threshold: int = 2,
        # T4: §5.1.2 anchor_date 抽取（可选；None → 不抽 anchor，仍写默认 expire_at）
        llm_router=None,
        llm_provider=None,
        prompt_registry=None,
        memory_ttl: Optional[MemoryTTLConfig] = None,
    ):
        self._high_emotion_threshold = high_emotion_threshold
        self._unresolved_threshold = unresolved_threshold
        self._mention_boost_threshold = mention_boost_threshold
        self._llm_router = llm_router
        self._llm_provider = llm_provider
        self._prompt_registry = prompt_registry
        self._memory_ttl = memory_ttl or MemoryTTLConfig()

    def extract(
        self,
        user_entry: MemoryEntry,
        assistant_entry: Optional[MemoryEntry],
        store: EventMemoryStore,
        real_now: datetime,
        world_now: datetime,
        turn_id: int = 0,
    ) -> ExtractionResult:
        if user_entry.speaker != "user":
            return ExtractionResult(reason="not_user_entry")

        result = ExtractionResult(skipped=False, reason="extracted")

        primary_signal = self._select_primary_signal(user_entry, store, turn_id)
        result.primary_signal = primary_signal

        if primary_signal == "resolution":
            resolved = self._handle_resolution(user_entry, store, real_now, world_now)
            if resolved:
                result.resolved_events.append(resolved)
                result.updated_events.append(resolved)

        elif primary_signal == "backreference":
            backref_event = self._handle_backreference(user_entry, assistant_entry, store, real_now, world_now)
            if backref_event:
                result.updated_events.append(backref_event)
            self._enrich_existing_event_from_signals(
                user_entry, assistant_entry, backref_event, store, real_now, world_now
            )

        elif primary_signal in ("emotion", "unresolved", "experience"):
            candidate = store.find_primary_candidate(
                topic_key=TOPIC_KEY_MAP.get(
                    self._detect_emotion_label(user_entry), ""
                ),
                emotion_label=self._detect_emotion_label(user_entry),
                message=user_entry.message,
                current_turn_id=turn_id,
                has_backreference=False,
            )

            if candidate:
                self._enrich_existing_event_from_signals(
                    user_entry, assistant_entry, candidate, store, real_now, world_now
                )
                result.updated_events.append(candidate)
            else:
                new_event = self._create_primary_event(
                    primary_signal, user_entry, assistant_entry, store, real_now, world_now
                )
                if new_event:
                    result.new_events.append(new_event)

            self._enrich_existing_event_from_signals(
                user_entry, assistant_entry,
                result.new_events[0] if result.new_events else None,
                store, real_now, world_now
            )

        self._check_repeated_mention(user_entry, store, real_now, world_now, result)

        # T4: 给所有新事件填 expire_at（含 anchor_date 优先）
        if result.new_events:
            self._apply_expiry_and_anchor(result.new_events, user_entry, real_now)

        if not result.new_events and not result.updated_events and not result.resolved_events:
            result.skipped = True
            result.reason = "no_event_triggered"

        return result

    # ─── T4: anchor_date + expire_at ─────────────────────────────

    def _apply_expiry_and_anchor(
        self,
        new_events: List[EventMemoryEntry],
        user_entry: MemoryEntry,
        real_now: datetime,
    ) -> None:
        ttl = self._memory_ttl
        default_expire = real_now + timedelta(seconds=ttl.event_default_ttl_seconds)
        anchor: Optional[datetime] = None

        if has_future_time_hint(user_entry.message):
            anchor = self._extract_anchor_date_via_llm(user_entry.message, real_now)

        for ev in new_events:
            ev.expire_at = default_expire
            if anchor is None:
                continue
            ev.anchor_date = anchor
            if anchor > real_now:
                anchor_expire = anchor + timedelta(
                    seconds=ttl.anchor_buffer_seconds
                )
                if anchor_expire > default_expire:
                    ev.expire_at = anchor_expire

    def _extract_anchor_date_via_llm(
        self,
        user_text: str,
        real_now: datetime,
    ) -> Optional[datetime]:
        if not self._prompt_registry or not (self._llm_router or self._llm_provider):
            return None
        try:
            from linger_core.llm.base import LLMMessage, LLMRequest
            from linger_core.llm.json_utils import parse_json_object_safely
            from linger_core.llm.task_type import LLMTaskType

            template = self._prompt_registry.get("anchor_date_extract")
            request = LLMRequest(
                messages=[
                    LLMMessage(role="system", content=template.system),
                    LLMMessage(role="user", content=template.user.format(
                        reference_date=real_now.date().isoformat(),
                        user_text=user_text,
                    )),
                ],
                response_format="json",
                metadata=dict(template.metadata_dict()),
            )
            if self._llm_router is not None:
                response = self._llm_router.generate(
                    LLMTaskType.ANCHOR_DATE_EXTRACT, request
                )
            else:
                response = self._llm_provider.generate(request)
            if not response.success:
                return None
            parsed, mode = parse_json_object_safely(response.content)
            if mode == "failed":
                return None
            raw = parsed.get("anchor_date")
            if not raw:
                return None
            try:
                return datetime.fromisoformat(raw)
            except (ValueError, TypeError):
                return None
        except Exception:
            return None

    def _select_primary_signal(
        self,
        user_entry: MemoryEntry,
        store: EventMemoryStore,
        turn_id: int,
    ) -> str:
        if self._has_resolution_keyword(user_entry.message):
            open_events = [e for e in store.get_active() if e.status in (EventStatus.OPEN, EventStatus.COOLED)]
            if open_events:
                return "resolution"

        if self._has_backreference_keyword(user_entry.message):
            active = store.get_active()
            if active:
                return "backreference"

        emotion_label = ""
        intensity = 0.0
        if user_entry.emotion_snapshot:
            emotion_label = user_entry.emotion_snapshot.get("emotion", "")
            intensity = user_entry.emotion_snapshot.get("intensity", 0.0)
        if intensity < self._high_emotion_threshold:
            detected = self._detect_emotion_from_text(user_entry.message)
            if detected:
                emotion_label = detected["emotion"]
                intensity = detected["intensity"]

        if intensity >= self._high_emotion_threshold:
            return "emotion"

        unresolved_score = self._compute_unresolved_score(user_entry.message)
        if unresolved_score >= self._unresolved_threshold:
            return "unresolved"

        if self._has_experience_keyword(user_entry.message):
            return "experience"

        return "none"

    def _enrich_existing_event_from_signals(
        self,
        user_entry: MemoryEntry,
        assistant_entry: Optional[MemoryEntry],
        target: Optional[EventMemoryEntry],
        store: EventMemoryStore,
        real_now: datetime,
        world_now: datetime,
    ) -> None:
        if target is None:
            return

        if user_entry.emotion_snapshot:
            emotion = user_entry.emotion_snapshot.get("emotion", "")
            intensity = user_entry.emotion_snapshot.get("intensity", 0.0)
            if emotion:
                target.update_emotion(emotion, intensity)

        unresolved_score = self._compute_unresolved_score(user_entry.message)
        if unresolved_score > target.unresolved_score:
            target.unresolved_score = unresolved_score

        for kw in EXPERIENCE_KEYWORDS:
            if kw in user_entry.message and kw not in target.related_tags:
                target.related_tags.append(kw)

        target.last_user_message = user_entry.message[:100]
        if assistant_entry:
            target.last_assistant_message = assistant_entry.message[:100]

        target.merge_count += 1
        target.continuity_score = min(1.0, target.continuity_score + 0.05)
        target.touch(real_now, world_now)

    def _handle_resolution(
        self,
        user_entry: MemoryEntry,
        store: EventMemoryStore,
        real_now: datetime,
        world_now: datetime,
    ) -> Optional[EventMemoryEntry]:
        open_events = [e for e in store.get_active() if e.status in (EventStatus.OPEN, EventStatus.COOLED)]
        if not open_events:
            return None

        open_events.sort(key=lambda e: e.recall_priority, reverse=True)
        target = open_events[0]

        target.resolve(hint="user_resolution_signal", real_now=real_now, world_now=world_now)
        target.touch(real_now, world_now)
        target.last_user_message = user_entry.message[:100]

        return target

    def _handle_backreference(
        self,
        user_entry: MemoryEntry,
        assistant_entry: Optional[MemoryEntry],
        store: EventMemoryStore,
        real_now: datetime,
        world_now: datetime,
    ) -> Optional[EventMemoryEntry]:
        active = store.get_active()
        if not active:
            return None

        active.sort(key=lambda e: e.recall_priority, reverse=True)

        emotion_label = ""
        if user_entry.emotion_snapshot:
            emotion_label = user_entry.emotion_snapshot.get("emotion", "")

        for event in active:
            if emotion_label and event.emotion_label == emotion_label:
                event.add_mention(user_entry.entry_id, user_entry.turn_id, real_now, world_now)
                event.update_emotion(emotion_label, user_entry.emotion_snapshot.get("intensity", 0.5) if user_entry.emotion_snapshot else 0.5)
                event.last_user_message = user_entry.message[:100]
                event.boost_priority(0.15)
                event.continuity_score = min(1.0, event.continuity_score + 0.1)
                if assistant_entry:
                    event.last_assistant_message = assistant_entry.message[:100]
                if self._has_unresolved_signal(user_entry):
                    event.unresolved_score = min(1.0, event.unresolved_score + 0.2)
                if event.status == EventStatus.COOLED:
                    event.status = EventStatus.OPEN
                    event.unresolved_score = 0.3
                return event

        top = active[0]
        top.add_mention(user_entry.entry_id, user_entry.turn_id, real_now, world_now)
        top.last_user_message = user_entry.message[:100]
        top.boost_priority(0.1)
        top.continuity_score = min(1.0, top.continuity_score + 0.1)
        if assistant_entry:
            top.last_assistant_message = assistant_entry.message[:100]
        return top

    def _create_primary_event(
        self,
        signal: str,
        user_entry: MemoryEntry,
        assistant_entry: Optional[MemoryEntry],
        store: EventMemoryStore,
        real_now: datetime,
        world_now: datetime,
    ) -> Optional[EventMemoryEntry]:
        if signal == "emotion":
            return self._create_emotion_event(user_entry, assistant_entry, store, real_now, world_now)
        elif signal == "unresolved":
            return self._create_unresolved_event(user_entry, assistant_entry, store, real_now, world_now)
        elif signal == "experience":
            return self._create_experience_event(user_entry, assistant_entry, store, real_now, world_now)
        return None

    def _create_emotion_event(
        self,
        user_entry: MemoryEntry,
        assistant_entry: Optional[MemoryEntry],
        store: EventMemoryStore,
        real_now: datetime,
        world_now: datetime,
    ) -> Optional[EventMemoryEntry]:
        emotion_label = ""
        intensity = 0.0
        if user_entry.emotion_snapshot:
            emotion_label = user_entry.emotion_snapshot.get("emotion", "")
            intensity = user_entry.emotion_snapshot.get("intensity", 0.0)
        if intensity < self._high_emotion_threshold:
            detected = self._detect_emotion_from_text(user_entry.message)
            if detected:
                emotion_label = detected["emotion"]
                intensity = detected["intensity"]
        if intensity < self._high_emotion_threshold:
            return None

        topic_key = TOPIC_KEY_MAP.get(emotion_label, "emotional_distress")
        title = self._build_emotion_title(emotion_label, user_entry.message)
        summary = self._build_emotion_summary(emotion_label, intensity, user_entry.message)
        display_title = self._build_emotion_display_title(emotion_label, user_entry.message)
        topic_summary = self._build_topic_summary(emotion_label, user_entry.message)

        return store.create(
            event_type=EventType.HIGH_EMOTION,
            title=title,
            summary=summary,
            real_now=real_now,
            world_now=world_now,
            source_entry_id=user_entry.entry_id,
            source_turn_id=user_entry.turn_id,
            emotion_label=emotion_label,
            emotion_peak=intensity,
            importance=min(1.0, 0.5 + intensity * 0.3),
            unresolved_score=0.3 if emotion_label in ("sad", "angry", "anxious") else 0.0,
            related_tags=[emotion_label, "high_emotion"],
            last_user_message=user_entry.message[:100],
            last_assistant_message=assistant_entry.message[:100] if assistant_entry else "",
            is_user_core_event=True,
            topic_key=topic_key,
            topic_summary=topic_summary,
            display_title=display_title,
        )

    def _create_unresolved_event(
        self,
        user_entry: MemoryEntry,
        assistant_entry: Optional[MemoryEntry],
        store: EventMemoryStore,
        real_now: datetime,
        world_now: datetime,
    ) -> Optional[EventMemoryEntry]:
        unresolved_score = self._compute_unresolved_score(user_entry.message)
        if unresolved_score < self._unresolved_threshold:
            return None

        title = self._build_unresolved_title(user_entry.message)
        summary = self._build_unresolved_summary(user_entry.message, unresolved_score)
        display_title = self._build_unresolved_display_title(user_entry.message)
        topic_summary = self._build_topic_summary(
            user_entry.emotion_snapshot.get("emotion", "") if user_entry.emotion_snapshot else "",
            user_entry.message,
        )

        return store.create(
            event_type=EventType.UNRESOLVED,
            title=title,
            summary=summary,
            real_now=real_now,
            world_now=world_now,
            source_entry_id=user_entry.entry_id,
            source_turn_id=user_entry.turn_id,
            emotion_label=user_entry.emotion_snapshot.get("emotion", "") if user_entry.emotion_snapshot else "",
            importance=0.6,
            unresolved_score=unresolved_score,
            related_tags=["unresolved"],
            last_user_message=user_entry.message[:100],
            last_assistant_message=assistant_entry.message[:100] if assistant_entry else "",
            is_user_core_event=True,
            topic_key="unresolved_issue",
            topic_summary=topic_summary,
            display_title=display_title,
        )

    def _create_experience_event(
        self,
        user_entry: MemoryEntry,
        assistant_entry: Optional[MemoryEntry],
        store: EventMemoryStore,
        real_now: datetime,
        world_now: datetime,
    ) -> Optional[EventMemoryEntry]:
        if not self._has_experience_keyword(user_entry.message):
            return None

        title = self._build_experience_title(user_entry.message)
        summary = user_entry.message[:200]
        display_title = self._build_experience_display_title(user_entry.message)
        topic_summary = self._build_topic_summary(
            user_entry.emotion_snapshot.get("emotion", "") if user_entry.emotion_snapshot else "",
            user_entry.message,
        )

        return store.create(
            event_type=EventType.EXPLICIT_EXPERIENCE,
            title=title,
            summary=summary,
            real_now=real_now,
            world_now=world_now,
            source_entry_id=user_entry.entry_id,
            source_turn_id=user_entry.turn_id,
            emotion_label=user_entry.emotion_snapshot.get("emotion", "") if user_entry.emotion_snapshot else "",
            importance=0.55,
            related_tags=["experience"],
            last_user_message=user_entry.message[:100],
            last_assistant_message=assistant_entry.message[:100] if assistant_entry else "",
            is_user_core_event=True,
            topic_key="personal_experience",
            topic_summary=topic_summary,
            display_title=display_title,
        )

    def _check_repeated_mention(
        self,
        user_entry: MemoryEntry,
        store: EventMemoryStore,
        real_now: datetime,
        world_now: datetime,
        result: ExtractionResult,
    ) -> None:
        for event in store.get_active():
            if event.event_type == EventType.REPEATED_MENTION:
                continue
            if user_entry.entry_id in event.source_entry_ids:
                if event.mention_count >= self._mention_boost_threshold:
                    new_event = self._try_create_repeated_mention(event, user_entry, store, real_now, world_now)
                    if new_event and new_event not in result.new_events:
                        result.new_events.append(new_event)
                break

    def _try_create_repeated_mention(
        self,
        source_event: EventMemoryEntry,
        user_entry: MemoryEntry,
        store: EventMemoryStore,
        real_now: datetime,
        world_now: datetime,
    ) -> Optional[EventMemoryEntry]:
        existing = store.find_similar_open(
            title=f"repeated:{source_event.title[:20]}",
            tags=["repeated_mention", source_event.event_type.value],
        )
        if existing:
            existing.add_mention(user_entry.entry_id, user_entry.turn_id, real_now, world_now)
            existing.boost_priority(0.1)
            return None

        display = source_event.display_title or source_event.title[:20]

        return store.create(
            event_type=EventType.REPEATED_MENTION,
            title=f"反复提及: {source_event.title[:20]}",
            summary=f"用户多次提及「{source_event.title[:30]}」，共{source_event.mention_count}次",
            real_now=real_now,
            world_now=world_now,
            source_entry_id=user_entry.entry_id,
            source_turn_id=user_entry.turn_id,
            emotion_label=source_event.emotion_label,
            importance=min(1.0, source_event.importance + 0.2),
            related_tags=["repeated_mention", source_event.event_type.value],
            last_user_message=user_entry.message[:100],
            is_user_core_event=True,
            parent_event_id=source_event.event_id,
            topic_key=source_event.topic_key,
            display_title=f"你反复提到的{display}",
        )

    def _detect_emotion_label(self, user_entry: MemoryEntry) -> str:
        if user_entry.emotion_snapshot:
            return user_entry.emotion_snapshot.get("emotion", "")
        detected = self._detect_emotion_from_text(user_entry.message)
        if detected:
            return detected["emotion"]
        return ""

    def _has_resolution_keyword(self, message: str) -> bool:
        return any(kw in message for kw in RESOLUTION_KEYWORDS)

    def _has_backreference_keyword(self, message: str) -> bool:
        return any(kw in message for kw in BACKREFERENCE_KEYWORDS)

    def _has_unresolved_signal(self, user_entry: MemoryEntry) -> bool:
        return self._compute_unresolved_score(user_entry.message) >= self._unresolved_threshold

    def _detect_emotion_from_text(self, message: str) -> Optional[Dict[str, Any]]:
        for emotion, keywords in EMOTION_KEYWORDS.items():
            for kw in keywords:
                if kw in message:
                    return {"emotion": emotion, "intensity": 0.7}
        return None

    def _compute_unresolved_score(self, message: str) -> float:
        score = 0.0
        for kw in UNRESOLVED_KEYWORDS:
            if kw in message:
                score += 0.2
        return min(score, 1.0)

    def _has_experience_keyword(self, message: str) -> bool:
        return any(kw in message for kw in EXPERIENCE_KEYWORDS)

    def _build_emotion_title(self, emotion: str, message: str) -> str:
        short = message[:15]
        emotion_map = {
            "sad": "低落", "angry": "愤怒", "anxious": "焦虑",
            "happy": "开心", "surprised": "惊讶",
        }
        label = emotion_map.get(emotion, emotion)
        return f"情绪事件({label}): {short}"

    def _build_emotion_display_title(self, emotion: str, message: str) -> str:
        emotion_display = {
            "sad": "那件让你难受的事",
            "angry": "那件让你生气的事",
            "anxious": "那个让你焦虑的问题",
            "happy": "那件让你开心的事",
            "surprised": "那件意外的事",
        }
        return emotion_display.get(emotion, "那件事")

    def _build_unresolved_display_title(self, message: str) -> str:
        return "你前面一直在纠结的那个问题"

    def _build_experience_display_title(self, message: str) -> str:
        return "你经历的那件事"

    def _build_topic_summary(self, emotion: str, message: str) -> str:
        emotion_map = {
            "sad": "低落情绪", "angry": "愤怒情绪", "anxious": "焦虑情绪",
            "happy": "积极情绪", "surprised": "意外事件",
        }
        label = emotion_map.get(emotion, "")
        if label:
            return f"{emotion_map.get(emotion, '')}相关: {message[:40]}"
        return message[:50]

    def _build_emotion_summary(self, emotion: str, intensity: float, message: str) -> str:
        return f"用户情绪{emotion}(强度{intensity:.1f}): {message[:80]}"

    def _build_unresolved_title(self, message: str) -> str:
        return f"未决: {message[:20]}"

    def _build_unresolved_summary(self, message: str, score: float) -> str:
        return f"用户表达未决状态(得分{score:.1f}): {message[:80]}"

    def _build_experience_title(self, message: str) -> str:
        return f"经历: {message[:20]}"
