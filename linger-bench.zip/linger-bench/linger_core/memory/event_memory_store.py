from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.memory.event_memory_entry import EventMemoryEntry
from linger_core.shared.enums import EventStatus, EventType
from linger_core.shared.ids import generate_id


class EventMemoryStore:
    def __init__(self, max_events: int = 100):
        self._events: Dict[str, EventMemoryEntry] = {}
        self._max_events = max_events

    def add(self, event: EventMemoryEntry) -> EventMemoryEntry:
        self._events[event.event_id] = event
        self._enforce_limit()
        return event

    def create(
        self,
        event_type: EventType,
        title: str,
        summary: str,
        real_now: datetime,
        world_now: datetime,
        source_entry_id: str = "",
        source_turn_id: int = 0,
        emotion_label: str = "",
        emotion_peak: float = 0.0,
        importance: float = 0.5,
        unresolved_score: float = 0.0,
        participants: Optional[List[str]] = None,
        related_tags: Optional[List[str]] = None,
        last_user_message: str = "",
        last_assistant_message: str = "",
        is_user_core_event: bool = False,
        recall_priority: float = 0.5,
        topic_key: str = "",
        topic_summary: str = "",
        parent_event_id: str = "",
        display_title: str = "",
    ) -> EventMemoryEntry:
        event = EventMemoryEntry(
            event_id=f"evt_{generate_id()[:10]}",
            event_type=event_type,
            title=title,
            summary=summary,
            first_seen_real=real_now,
            first_seen_world=world_now,
            last_seen_real=real_now,
            last_seen_world=world_now,
            emotion_label=emotion_label,
            emotion_peak=emotion_peak,
            importance=importance,
            unresolved_score=unresolved_score,
            participants=participants or ["user", "assistant"],
            source_entry_ids=[source_entry_id] if source_entry_id else [],
            source_turn_ids=[source_turn_id] if source_turn_id else [],
            related_tags=related_tags or [],
            last_user_message=last_user_message,
            last_assistant_message=last_assistant_message,
            is_user_core_event=is_user_core_event,
            recall_priority=recall_priority,
            topic_key=topic_key,
            topic_summary=topic_summary,
            parent_event_id=parent_event_id,
            display_title=display_title,
        )
        return self.add(event)

    def get(self, event_id: str) -> Optional[EventMemoryEntry]:
        return self._events.get(event_id)

    def get_active(self) -> List[EventMemoryEntry]:
        return [e for e in self._events.values() if e.is_active()]

    def get_by_type(self, event_type: EventType) -> List[EventMemoryEntry]:
        return [e for e in self._events.values() if e.event_type == event_type and e.is_active()]

    def get_by_status(self, status: EventStatus) -> List[EventMemoryEntry]:
        return [e for e in self._events.values() if e.status == status]

    def get_by_tag(self, tag: str) -> List[EventMemoryEntry]:
        return [e for e in self._events.values() if tag in e.related_tags and e.is_active()]

    def get_recent(self, n: int = 5) -> List[EventMemoryEntry]:
        active = self.get_active()
        active.sort(key=lambda e: e.last_seen_world or datetime.min, reverse=True)
        return active[:n]

    def get_high_priority(self, n: int = 5) -> List[EventMemoryEntry]:
        active = self.get_active()
        active.sort(key=lambda e: e.recall_priority, reverse=True)
        return active[:n]

    def get_unresolved(self, min_score: float = 0.3) -> List[EventMemoryEntry]:
        return [
            e for e in self._events.values()
            if e.is_active() and e.unresolved_score >= min_score
        ]

    def find_by_keyword(self, keyword: str) -> List[EventMemoryEntry]:
        results = []
        for e in self._events.values():
            if not e.is_active():
                continue
            if keyword in e.title or keyword in e.summary:
                results.append(e)
            elif keyword in e.last_user_message or keyword in e.last_assistant_message:
                results.append(e)
        return results

    def find_by_topic_key(self, topic_key: str) -> Optional[EventMemoryEntry]:
        if not topic_key:
            return None
        for e in self._events.values():
            if e.is_active() and e.topic_key == topic_key:
                return e
        return None

    def find_primary_candidate(
        self,
        topic_key: str = "",
        emotion_label: str = "",
        message: str = "",
        current_turn_id: int = 0,
        has_backreference: bool = False,
    ) -> Optional[EventMemoryEntry]:
        active = self.get_active()
        if not active:
            return None

        scored: List[tuple] = []
        for e in active:
            score = 0.0
            if topic_key and e.topic_key == topic_key:
                score += 0.45
            if has_backreference:
                recent_turns = [t for t in e.source_turn_ids if current_turn_id - t <= 3]
                if recent_turns:
                    score += 0.25
            if message:
                msg_words = set(message[:30])
                title_words = set(e.title[:30])
                overlap = msg_words & title_words
                if overlap and (msg_words or title_words):
                    score += 0.15 * len(overlap) / max(len(msg_words | title_words), 1)
            if emotion_label and e.emotion_label == emotion_label:
                score += 0.10
            recent_turns = [t for t in e.source_turn_ids if current_turn_id - t <= 3]
            if recent_turns:
                score += 0.05
            scored.append((score, e))

        scored.sort(key=lambda x: x[0], reverse=True)
        if scored and scored[0][0] >= 0.55:
            return scored[0][1]
        return None

    def find_similar_open(
        self,
        title: str,
        emotion_label: str = "",
        tags: Optional[List[str]] = None,
    ) -> Optional[EventMemoryEntry]:
        for e in self._events.values():
            if not e.is_active():
                continue
            if e.status != EventStatus.OPEN:
                continue
            if emotion_label and e.emotion_label == emotion_label:
                if any(t in e.related_tags for t in (tags or [])):
                    return e
            if title and e.title and self._title_similarity(title, e.title) > 0.5:
                return e
        return None

    def remove(self, event_id: str) -> bool:
        if event_id in self._events:
            del self._events[event_id]
            return True
        return False

    def archive_resolved(
        self,
        real_now: Optional[datetime] = None,
        max_age_hours: Optional[float] = 24.0,
    ) -> int:
        """T3: 真按时间归档（§5.1.1 / spec §4.5）。

        优先按 expire_at 字段（§5.1.2 / T3）；缺字段时 fallback 到旧
        max_age_hours 路径以兼容历史持久化数据。
        """
        real_now = real_now or datetime.now()
        count = 0
        for e in list(self._events.values()):
            if e.status != EventStatus.RESOLVED:
                continue
            if e.expire_at is not None:
                if real_now < e.expire_at:
                    continue
                e.archive(real_now=real_now)
                count += 1
                continue
            # fallback: 旧 max_age_hours 路径
            if max_age_hours is None:
                continue
            if e.resolved_at_real is None:
                continue
            if (real_now - e.resolved_at_real).total_seconds() < max_age_hours * 3600:
                continue
            e.archive(real_now=real_now)
            count += 1
        return count

    def expire_by_default(self, real_now: datetime) -> int:
        """T3: 按 expire_at 字段过期非 RESOLVED 的活跃事件（spec §4.5）。"""
        count = 0
        for e in list(self._events.values()):
            if not e.is_active():
                continue
            if e.expire_at is None:
                continue
            if real_now > e.expire_at:
                e.archive(real_now=real_now)
                count += 1
        return count

    def cool_all(self, delta: float = 0.05) -> int:
        count = 0
        for e in self._events.values():
            if e.status == EventStatus.OPEN:
                e.cool_down(delta)
                count += 1
        return count

    def decay_all_priorities(self, delta: float = 0.02) -> int:
        count = 0
        for e in self._events.values():
            if e.is_active():
                e.decay_priority(delta)
                count += 1
        return count

    def _enforce_limit(self) -> None:
        if len(self._events) <= self._max_events:
            return
        archived = [e for e in self._events.values() if e.status == EventStatus.ARCHIVED]
        if archived:
            archived.sort(key=lambda e: e.recall_priority)
            for e in archived[:len(self._events) - self._max_events]:
                del self._events[e.event_id]
        if len(self._events) > self._max_events:
            resolved = [e for e in self._events.values() if e.status == EventStatus.RESOLVED]
            resolved.sort(key=lambda e: e.recall_priority)
            for e in resolved[:len(self._events) - self._max_events]:
                del self._events[e.event_id]

    @staticmethod
    def _title_similarity(a: str, b: str) -> float:
        if a == b:
            return 1.0
        set_a = set(a)
        set_b = set(b)
        if not set_a or not set_b:
            return 0.0
        return len(set_a & set_b) / len(set_a | set_b)

    @property
    def all_events(self) -> List[EventMemoryEntry]:
        return list(self._events.values())

    @property
    def count(self) -> int:
        return len(self._events)

    @property
    def active_count(self) -> int:
        return len(self.get_active())
