from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.memory.long_term_memory_entry import LongTermMemoryEntry
from linger_core.shared.enums import LongTermMemoryCategory, LongTermMemoryStatus
from linger_core.shared.ids import generate_id


class LongTermMemoryStore:
    def __init__(self, max_entries: int = 200):
        self._entries: Dict[str, LongTermMemoryEntry] = {}
        self._max_entries = max_entries

    def add(self, entry: LongTermMemoryEntry) -> LongTermMemoryEntry:
        self._entries[entry.memory_id] = entry
        self._enforce_limit()
        return entry

    def create(
        self,
        category: LongTermMemoryCategory,
        key: str,
        value: str,
        real_now: datetime,
        summary: str = "",
        confidence: float = 0.5,
        stability: float = 0.5,
        importance: float = 0.5,
        visibility: str = "system",
        source_event_ids: Optional[List[str]] = None,
        source_digest_ids: Optional[List[str]] = None,
        decay_policy: str = "normal",
        tags: Optional[List[str]] = None,
    ) -> LongTermMemoryEntry:
        entry = LongTermMemoryEntry(
            memory_id=f"ltm_{generate_id()[:10]}",
            category=category,
            key=key,
            value=value,
            summary=summary or value[:40],
            confidence=confidence,
            stability=stability,
            importance=importance,
            visibility=visibility,
            source_event_ids=source_event_ids or [],
            source_digest_ids=source_digest_ids or [],
            first_seen_real=real_now,
            last_seen_real=real_now,
            decay_policy=decay_policy,
            tags=tags or [],
        )
        return self.add(entry)

    def get(self, memory_id: str) -> Optional[LongTermMemoryEntry]:
        return self._entries.get(memory_id)

    def get_active(self) -> List[LongTermMemoryEntry]:
        return [e for e in self._entries.values() if e.is_active()]

    def get_by_category(self, category: LongTermMemoryCategory) -> List[LongTermMemoryEntry]:
        return [e for e in self._entries.values() if e.category == category and e.is_active()]

    def get_by_status(self, status: LongTermMemoryStatus) -> List[LongTermMemoryEntry]:
        return [e for e in self._entries.values() if e.status == status]

    def get_by_key(self, key: str) -> Optional[LongTermMemoryEntry]:
        for e in self._entries.values():
            if e.key == key and e.is_active():
                return e
        return None

    def get_by_tag(self, tag: str) -> List[LongTermMemoryEntry]:
        return [e for e in self._entries.values() if tag in e.tags and e.is_active()]

    def get_high_confidence(self, min_confidence: float = 0.7) -> List[LongTermMemoryEntry]:
        return [e for e in self.get_active() if e.confidence >= min_confidence]

    def get_top_scored(self, n: int = 5) -> List[LongTermMemoryEntry]:
        active = self.get_active()
        active.sort(key=lambda e: e.effective_score(), reverse=True)
        return active[:n]

    def find_by_keyword(self, keyword: str) -> List[LongTermMemoryEntry]:
        results = []
        for e in self._entries.values():
            if not e.is_active():
                continue
            if keyword in e.key or keyword in e.value or keyword in e.summary:
                results.append(e)
        return results

    def find_or_create(
        self,
        category: LongTermMemoryCategory,
        key: str,
        value: str,
        real_now: datetime,
        **kwargs,
    ) -> LongTermMemoryEntry:
        existing = self.get_by_key(key)
        if existing and existing.category == category:
            existing.confirm(real_now)
            return existing
        return self.create(category=category, key=key, value=value, real_now=real_now, **kwargs)

    def remove(self, memory_id: str) -> bool:
        if memory_id in self._entries:
            del self._entries[memory_id]
            return True
        return False

    def archive_low_confidence(self, min_confidence: float = 0.2) -> int:
        count = 0
        for e in list(self._entries.values()):
            if e.is_active() and e.confidence < min_confidence:
                e.archive()
                count += 1
        return count

    def _enforce_limit(self) -> None:
        if len(self._entries) <= self._max_entries:
            return
        archived = [e for e in self._entries.values() if e.status == LongTermMemoryStatus.ARCHIVED]
        if archived:
            archived.sort(key=lambda e: e.effective_score())
            for e in archived[:len(self._entries) - self._max_entries]:
                del self._entries[e.memory_id]

    @property
    def all_entries(self) -> List[LongTermMemoryEntry]:
        return list(self._entries.values())

    @property
    def count(self) -> int:
        return len(self._entries)

    @property
    def active_count(self) -> int:
        return len(self.get_active())
