from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from linger_core.memory.memory_entry import MemoryEntry
from linger_core.shared.ids import generate_id


class ShortTermMemory:
    def __init__(self, default_ttl_seconds: float = 86400.0, max_entries: int = 50):
        self._entries: List[MemoryEntry] = []
        self._default_ttl = default_ttl_seconds
        self._max_entries = max_entries

    def add_entry(self, entry: MemoryEntry) -> None:
        self._entries.append(entry)
        if len(self._entries) > self._max_entries:
            self._entries = self._entries[-self._max_entries:]

    def write(
        self,
        turn_id: int,
        speaker: str,
        message: str,
        real_now: datetime,
        world_now: datetime,
        emotion_snapshot: Optional[Dict[str, Any]] = None,
        action_plan_snapshot: Optional[Dict[str, Any]] = None,
        speak_mode: str = "",
        followup_hook_id: str = "",
        tags: Optional[List[str]] = None,
        importance: float = 0.5,
        ttl_seconds: Optional[float] = None,
    ) -> MemoryEntry:
        ttl = ttl_seconds or self._default_ttl
        entry = MemoryEntry(
            entry_id=f"stm_{generate_id()[:10]}",
            turn_id=turn_id,
            speaker=speaker,
            message=message,
            created_at_real=real_now,
            created_at_world=world_now,
            emotion_snapshot=emotion_snapshot or {},
            action_plan_snapshot=action_plan_snapshot or {},
            speak_mode=speak_mode,
            followup_hook_id=followup_hook_id,
            tags=tags or [],
            importance=importance,
            is_active=True,
            expires_at_world=world_now + timedelta(seconds=ttl),
        )
        self.add_entry(entry)
        return entry

    def get_recent(self, n: int = 6) -> List[MemoryEntry]:
        active = [e for e in self._entries if e.is_active]
        return active[-n:]

    def get_recent_by_speaker(self, speaker: str, n: int = 3) -> List[MemoryEntry]:
        active = [e for e in self._entries if e.is_active and e.speaker == speaker]
        return active[-n:]

    def get_recent_turns(self, n_turns: int = 3) -> List[MemoryEntry]:
        active = [e for e in self._entries if e.is_active]
        if not active:
            return []
        max_turn = active[-1].turn_id
        min_turn = max(max_turn - n_turns + 1, 0)
        return [e for e in active if e.turn_id >= min_turn]

    def get_latest_assistant(self, n: int = 2) -> List[MemoryEntry]:
        return self.get_recent_by_speaker("assistant", n)

    def get_latest_user(self, n: int = 2) -> List[MemoryEntry]:
        return self.get_recent_by_speaker("user", n)

    def get_entries_with_followup(self) -> List[MemoryEntry]:
        return [e for e in self._entries if e.is_active and e.followup_hook_id]

    def expire_entries(self, world_now: datetime) -> List[MemoryEntry]:
        expired = []
        for entry in self._entries:
            if entry.is_active and entry.is_expired(world_now):
                entry.deactivate()
                expired.append(entry)
        return expired

    def deactivate_by_turn(self, turn_id: int) -> None:
        for entry in self._entries:
            if entry.turn_id == turn_id and entry.is_active:
                entry.deactivate()

    def boost_followup_entries(self, delta: float = 0.2) -> None:
        for entry in self._entries:
            if entry.is_active and entry.followup_hook_id:
                entry.boost_importance(delta)

    @property
    def all_entries(self) -> List[MemoryEntry]:
        return list(self._entries)

    @property
    def active_entries(self) -> List[MemoryEntry]:
        return [e for e in self._entries if e.is_active]

    @property
    def count(self) -> int:
        return len(self._entries)

    @property
    def active_count(self) -> int:
        return len([e for e in self._entries if e.is_active])
