from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.core.state.base_state import BaseState


@dataclass
class ProfileSnapshot(BaseState):
    profile_id: str = ""
    communication_preferences: Dict[str, Any] = field(default_factory=dict)
    emotion_baseline: Dict[str, Any] = field(default_factory=dict)
    topic_distribution: Dict[str, float] = field(default_factory=dict)
    relationship_profile: Dict[str, Any] = field(default_factory=dict)
    recent_risk_flags: List[str] = field(default_factory=list)
    source_memory_ids: List[str] = field(default_factory=list)
    source_digest_ids: List[str] = field(default_factory=list)
    version: int = 1

    def update_communication_pref(self, key: str, value: Any) -> None:
        self.communication_preferences[key] = value
        self.touch()

    def update_emotion_baseline(self, emotion: str, frequency: float) -> None:
        self.emotion_baseline[emotion] = frequency
        self.touch()

    def update_topic_distribution(self, topic: str, weight: float) -> None:
        self.topic_distribution[topic] = weight
        self.touch()

    def add_risk_flag(self, flag: str) -> None:
        if flag not in self.recent_risk_flags:
            self.recent_risk_flags.append(flag)
        self.touch()

    def clear_risk_flags(self) -> None:
        self.recent_risk_flags.clear()
        self.touch()

    def top_topics(self, n: int = 3) -> List[str]:
        sorted_topics = sorted(self.topic_distribution.items(), key=lambda x: x[1], reverse=True)
        return [t[0] for t in sorted_topics[:n]]

    def dominant_emotion(self) -> str:
        if not self.emotion_baseline:
            return "neutral"
        return max(self.emotion_baseline.items(), key=lambda x: x[1])[0]

    def preferred_style(self) -> str:
        return self.communication_preferences.get("style", "balanced")

    def to_dict(self) -> Dict[str, Any]:
        base = super().to_dict()
        base.update({
            "profile_id": self.profile_id,
            "communication_preferences": self.communication_preferences,
            "emotion_baseline": self.emotion_baseline,
            "topic_distribution": self.topic_distribution,
            "relationship_profile": self.relationship_profile,
            "recent_risk_flags": self.recent_risk_flags,
            "source_memory_ids": self.source_memory_ids,
            "source_digest_ids": self.source_digest_ids,
            "version": self.version,
        })
        return base
