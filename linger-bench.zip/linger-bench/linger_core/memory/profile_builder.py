from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.memory.long_term_memory_entry import LongTermMemoryEntry
from linger_core.memory.long_term_memory_store import LongTermMemoryStore
from linger_core.memory.profile_snapshot import ProfileSnapshot
from linger_core.memory.digest_bundle import DigestBundle
from linger_core.shared.enums import LongTermMemoryCategory
from linger_core.shared.ids import generate_id


class ProfileBuilder:
    def __init__(self):
        self._snapshot: Optional[ProfileSnapshot] = None

    def build(
        self,
        ltm_store: LongTermMemoryStore,
        digests: Optional[List[DigestBundle]] = None,
        real_now: Optional[datetime] = None,
    ) -> ProfileSnapshot:
        now = real_now or datetime.now()

        if self._snapshot is None:
            self._snapshot = ProfileSnapshot(
                profile_id=f"prof_{generate_id()[:10]}",
                created_at=now,
                updated_at=now,
            )

        self._snapshot.communication_preferences = self._build_comm_prefs(ltm_store)
        self._snapshot.emotion_baseline = self._build_emotion_baseline(ltm_store, digests)
        self._snapshot.topic_distribution = self._build_topic_distribution(ltm_store, digests)
        self._snapshot.relationship_profile = self._build_relationship_profile(digests)
        self._snapshot.recent_risk_flags = self._collect_risk_flags(ltm_store, digests)
        self._snapshot.source_memory_ids = [e.memory_id for e in ltm_store.get_active()]
        self._snapshot.source_digest_ids = [d.digest_id for d in (digests or [])]
        self._snapshot.version += 1
        self._snapshot.touch(now)

        return self._snapshot

    @property
    def current_snapshot(self) -> Optional[ProfileSnapshot]:
        return self._snapshot

    def _build_comm_prefs(self, store: LongTermMemoryStore) -> Dict[str, Any]:
        prefs: Dict[str, Any] = {}
        style_entries = store.get_by_category(LongTermMemoryCategory.STYLE)
        if style_entries:
            best = max(style_entries, key=lambda e: e.confidence)
            prefs["style"] = best.value.replace("风格倾向: ", "")

        pref_entries = store.get_by_category(LongTermMemoryCategory.PREFERENCE)
        pref_list = []
        for e in pref_entries:
            if e.confidence >= 0.5:
                pref_list.append({"key": e.key, "value": e.value, "confidence": e.confidence})
        if pref_list:
            prefs["preferences"] = pref_list

        habit_entries = store.get_by_category(LongTermMemoryCategory.HABIT)
        if habit_entries:
            prefs["habit_count"] = len(habit_entries)

        return prefs

    def _build_emotion_baseline(
        self, store: LongTermMemoryStore, digests: Optional[List[DigestBundle]]
    ) -> Dict[str, Any]:
        baseline: Dict[str, Any] = {}
        if digests:
            latest = max(digests, key=lambda d: d.generated_at or datetime.min)
            if latest.emotion_trend:
                baseline = latest.emotion_trend.get("distribution", {})
                baseline["dominant"] = latest.emotion_trend.get("dominant", "neutral")
        concern_entries = store.get_by_category(LongTermMemoryCategory.CONCERN)
        if concern_entries:
            baseline["concern_count"] = len(concern_entries)
        return baseline

    def _build_topic_distribution(
        self, store: LongTermMemoryStore, digests: Optional[List[DigestBundle]]
    ) -> Dict[str, float]:
        topics: Dict[str, float] = {}
        if digests:
            for d in digests:
                for topic in d.main_topics:
                    topics[topic] = topics.get(topic, 0.0) + 1.0
        for entry in store.get_active():
            for tag in entry.tags:
                if tag not in ("repeated", "preference", "style", "concern", "identity", "core_identity"):
                    topics[tag] = topics.get(tag, 0.0) + entry.importance
        total = sum(topics.values()) or 1.0
        return {k: round(v / total, 3) for k, v in topics.items()}

    def _build_relationship_profile(self, digests: Optional[List[DigestBundle]]) -> Dict[str, Any]:
        profile: Dict[str, Any] = {}
        if digests:
            latest = max(digests, key=lambda d: d.generated_at or datetime.min)
            profile["trend"] = latest.relationship_trend
            profile["recommended_style"] = latest.recommended_style
            profile["interaction_density"] = latest.interaction_density
        return profile

    def _collect_risk_flags(
        self, store: LongTermMemoryStore, digests: Optional[List[DigestBundle]]
    ) -> List[str]:
        flags: List[str] = []
        concern_entries = store.get_by_category(LongTermMemoryCategory.CONCERN)
        high_concern = [e for e in concern_entries if e.confidence >= 0.7]
        if high_concern:
            flags.append("high_concern_count")
        if digests:
            latest = max(digests, key=lambda d: d.generated_at or datetime.min)
            if latest.emotion_trend.get("dominant") in ("sad", "angry", "anxious"):
                flags.append("negative_emotion_dominant")
            if latest.unresolved_events and len(latest.unresolved_events) > 3:
                flags.append("many_unresolved")
        return flags
