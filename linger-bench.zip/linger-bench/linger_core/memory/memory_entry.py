from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.shared.enums import EmotionType


@dataclass
class MemoryEntry:
    entry_id: str
    turn_id: int
    speaker: str
    message: str
    created_at_real: datetime
    created_at_world: datetime
    emotion_snapshot: Dict[str, Any] = field(default_factory=dict)
    action_plan_snapshot: Dict[str, Any] = field(default_factory=dict)
    speak_mode: str = ""
    followup_hook_id: str = ""
    tags: List[str] = field(default_factory=list)
    importance: float = 0.5
    is_active: bool = True
    expires_at_world: Optional[datetime] = None

    def is_expired(self, world_now: datetime) -> bool:
        if self.expires_at_world is None:
            return False
        return world_now > self.expires_at_world

    def deactivate(self) -> None:
        self.is_active = False

    def boost_importance(self, delta: float) -> None:
        self.importance = min(self.importance + delta, 1.0)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "entry_id": self.entry_id,
            "turn_id": self.turn_id,
            "speaker": self.speaker,
            "message": self.message,
            "created_at_real": self.created_at_real.isoformat(),
            "created_at_world": self.created_at_world.isoformat(),
            "emotion_snapshot": self.emotion_snapshot,
            "action_plan_snapshot": self.action_plan_snapshot,
            "speak_mode": self.speak_mode,
            "followup_hook_id": self.followup_hook_id,
            "tags": self.tags,
            "importance": self.importance,
            "is_active": self.is_active,
            "expires_at_world": self.expires_at_world.isoformat() if self.expires_at_world else None,
        }
