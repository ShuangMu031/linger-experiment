from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.core.state.base_state import BaseState


@dataclass
class RelationshipSnapshot(BaseState):
    familiarity: float = 0.3
    trust_level: float = 0.3
    warmth: float = 0.5
    volatility: float = 0.2
    recent_contact_density: float = 0.0
    preferred_distance: str = "moderate"
    initiative_affinity: float = 0.3
    total_interactions: int = 0
    positive_interactions: int = 0
    negative_interactions: int = 0
    last_interaction_real: Optional[datetime] = None
    relationship_stage: str = "stranger"
    risk_flags: List[str] = field(default_factory=list)
    source_digest_ids: List[str] = field(default_factory=list)

    def record_interaction(self, is_positive: bool, real_now: Optional[datetime] = None) -> None:
        self.total_interactions += 1
        if is_positive:
            self.positive_interactions += 1
            self.trust_level = min(1.0, self.trust_level + 0.02)
            self.warmth = min(1.0, self.warmth + 0.01)
        else:
            self.negative_interactions += 1
            self.trust_level = max(0.0, self.trust_level - 0.05)
            self.warmth = max(0.0, self.warmth - 0.03)
            self.volatility = min(1.0, self.volatility + 0.05)
        if real_now:
            self.last_interaction_real = real_now
        self._update_stage()
        self.touch(real_now)

    def update_from_digest(self, digest_data: Dict[str, Any]) -> None:
        trend = digest_data.get("relationship_trend", "")
        if trend == "warming":
            self.warmth = min(1.0, self.warmth + 0.05)
            self.trust_level = min(1.0, self.trust_level + 0.03)
        elif trend == "cooling":
            self.warmth = max(0.0, self.warmth - 0.05)
        elif trend == "volatile":
            self.volatility = min(1.0, self.volatility + 0.1)
        self.recent_contact_density = digest_data.get("interaction_density", self.recent_contact_density)
        self._update_stage()
        self.touch()

    def _update_stage(self) -> None:
        if self.total_interactions < 5:
            self.relationship_stage = "stranger"
        elif self.familiarity < 0.4:
            self.relationship_stage = "acquaintance"
        elif self.familiarity < 0.7:
            self.relationship_stage = "familiar"
        elif self.trust_level >= 0.7 and self.warmth >= 0.6:
            self.relationship_stage = "trusted"
        else:
            self.relationship_stage = "familiar"

    def effective_warmth(self) -> float:
        return max(0.0, self.warmth - self.volatility * 0.3)

    def to_dict(self) -> Dict[str, Any]:
        base = super().to_dict()
        base.update({
            "familiarity": self.familiarity,
            "trust_level": self.trust_level,
            "warmth": self.warmth,
            "volatility": self.volatility,
            "recent_contact_density": self.recent_contact_density,
            "preferred_distance": self.preferred_distance,
            "initiative_affinity": self.initiative_affinity,
            "total_interactions": self.total_interactions,
            "positive_interactions": self.positive_interactions,
            "negative_interactions": self.negative_interactions,
            "last_interaction_real": self.last_interaction_real.isoformat() if self.last_interaction_real else None,
            "relationship_stage": self.relationship_stage,
            "risk_flags": self.risk_flags,
            "source_digest_ids": self.source_digest_ids,
        })
        return base
