from typing import Any, Optional, Sequence


def safe_bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.lower() in ("true", "yes", "1")
    if isinstance(value, (int, float)):
        return value != 0
    return default


def safe_float(
    value: Any,
    default: float = 0.0,
    min_value: Optional[float] = None,
    max_value: Optional[float] = None,
) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    if min_value is not None:
        result = max(min_value, result)
    if max_value is not None:
        result = min(max_value, result)
    return result


def safe_enum(value: Any, allowed: Sequence[str], default: str = "") -> str:
    s = str(value) if value is not None else ""
    if s in allowed:
        return s
    return default


def safe_str(value: Any, max_length: int = 0, default: str = "") -> str:
    if value is None:
        return default
    s = str(value)
    if max_length > 0 and len(s) > max_length:
        s = s[:max_length]
    return s
