class LLMError(Exception):
    pass


class LLMProviderError(LLMError):
    pass


class LLMTimeoutError(LLMError):
    pass


class LLMResponseParseError(LLMError):
    pass
