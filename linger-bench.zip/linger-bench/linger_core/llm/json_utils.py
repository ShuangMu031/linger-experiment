import json
import re
from typing import Tuple


def parse_json_object_safely(text: str) -> Tuple[dict, str]:
    if not text or not text.strip():
        return {}, "failed"

    text = text.strip()

    try:
        result = json.loads(text)
        if isinstance(result, dict):
            return result, "direct"
    except (json.JSONDecodeError, ValueError):
        pass

    fenced = _extract_fenced_json(text)
    if fenced is not None:
        return fenced, "fenced"

    extracted = _extract_first_json_object(text)
    if extracted is not None:
        return extracted, "extracted"

    return {}, "failed"


def _extract_fenced_json(text: str) -> dict | None:
    pattern = r"```(?:json)?\s*\n?(.*?)\n?\s*```"
    match = re.search(pattern, text, re.DOTALL)
    if match:
        try:
            result = json.loads(match.group(1).strip())
            if isinstance(result, dict):
                return result
        except (json.JSONDecodeError, ValueError):
            pass
    return None


def _extract_first_json_object(text: str) -> dict | None:
    start = text.find("{")
    if start == -1:
        return None

    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                candidate = text[start : i + 1]
                try:
                    result = json.loads(candidate)
                    if isinstance(result, dict):
                        return result
                except (json.JSONDecodeError, ValueError):
                    return None
    return None
