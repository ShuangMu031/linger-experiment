import json
import os
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from urllib.error import HTTPError, URLError

from .base import LLMMessage, LLMRequest, LLMResponse


_RETRY_BACKOFF_SCHEDULE_429 = (1.0, 2.0, 4.0)
_RETRY_BACKOFF_SCHEDULE_TRANSIENT = (1.0,)
_RETRYABLE_TRANSIENT_PREFIXES = ("timeout", "connection_error", "http_5")


@dataclass
class RetryConfig:
    max_retries_429: int = 3
    max_retries_transient: int = 1
    backoff_429: tuple = _RETRY_BACKOFF_SCHEDULE_429
    backoff_transient: tuple = _RETRY_BACKOFF_SCHEDULE_TRANSIENT
    enabled: bool = True


@dataclass
class OpenAICompatibleConfig:
    base_url: str = ""
    api_key_env: str = "OPENAI_API_KEY"
    model: str = "gpt-4o-mini"
    timeout_seconds: int = 30
    retry: RetryConfig = field(default_factory=RetryConfig)


class OpenAICompatibleProvider:
    def __init__(
        self,
        config: Optional[OpenAICompatibleConfig] = None,
        sleep_func=None,
    ) -> None:
        self._config = config or OpenAICompatibleConfig()
        self._sleep = sleep_func if sleep_func is not None else time.sleep

    def generate(self, request: LLMRequest) -> LLMResponse:
        if not self._config.base_url:
            return LLMResponse(
                content="",
                provider="openai_compatible",
                model=self._config.model,
                success=False,
                error="base_url_not_configured",
            )

        api_key = os.environ.get(self._config.api_key_env, "")
        if not api_key:
            return LLMResponse(
                content="",
                provider="openai_compatible",
                model=self._config.model,
                success=False,
                error=f"api_key_missing:{self._config.api_key_env}",
            )

        retry_count = 0
        retry_reasons: List[str] = []
        retry_cfg = self._config.retry

        max_attempts = 1
        if retry_cfg.enabled:
            max_attempts = 1 + max(retry_cfg.max_retries_429, retry_cfg.max_retries_transient)

        last_response: Optional[LLMResponse] = None

        for attempt in range(max_attempts):
            response = self._call_once(request, api_key)

            if response.success:
                if retry_count > 0:
                    if response.raw is None:
                        response.raw = {}
                    response.raw["retry_count"] = retry_count
                    response.raw["retry_reasons"] = list(retry_reasons)
                return response

            last_response = response
            error_code = response.error or ""

            if not retry_cfg.enabled:
                break

            backoff = self._select_backoff(error_code, retry_count, retry_cfg)
            if backoff is None:
                break

            retry_reasons.append(error_code)
            retry_count += 1
            self._sleep(backoff)

        if last_response is not None:
            if last_response.raw is None:
                last_response.raw = {}
            last_response.raw["retry_count"] = retry_count
            last_response.raw["retry_reasons"] = list(retry_reasons)
            return last_response

        return LLMResponse(
            content="",
            provider="openai_compatible",
            model=self._config.model,
            success=False,
            error="unknown_failure_after_retries",
            raw={"retry_count": retry_count, "retry_reasons": list(retry_reasons)},
        )

    @staticmethod
    def _select_backoff(error_code: str, retry_count: int, cfg: RetryConfig) -> Optional[float]:
        if error_code == "http_429_rate_limited":
            if retry_count >= cfg.max_retries_429:
                return None
            schedule = cfg.backoff_429
            return schedule[min(retry_count, len(schedule) - 1)]

        if any(error_code.startswith(p) for p in _RETRYABLE_TRANSIENT_PREFIXES):
            if retry_count >= cfg.max_retries_transient:
                return None
            schedule = cfg.backoff_transient
            return schedule[min(retry_count, len(schedule) - 1)]

        return None

    def _call_once(self, request: LLMRequest, api_key: str) -> LLMResponse:
        try:
            import urllib.request

            messages = self._normalize_messages(request.messages)

            body: Dict[str, Any] = {
                "model": self._config.model,
                "messages": messages,
                "temperature": request.temperature,
                "max_tokens": request.max_tokens,
            }

            if request.response_format:
                if request.response_format == "json":
                    body["response_format"] = {"type": "json_object"}
                else:
                    body["response_format"] = {"type": request.response_format}

            data = json.dumps(body).encode("utf-8")

            url = f"{self._config.base_url.rstrip('/')}/chat/completions"
            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {api_key}",
                },
            )

            with urllib.request.urlopen(req, timeout=self._config.timeout_seconds) as resp:
                raw = json.loads(resp.read().decode("utf-8"))

            choices = raw.get("choices", [])
            if not choices:
                return LLMResponse(
                    content="",
                    raw=raw,
                    provider="openai_compatible",
                    model=self._config.model,
                    success=False,
                    error="empty_choices",
                )

            content = choices[0].get("message", {}).get("content", "")

            if not content.strip():
                return LLMResponse(
                    content="",
                    raw=raw,
                    provider="openai_compatible",
                    model=self._config.model,
                    success=False,
                    error="empty_content",
                )

            return LLMResponse(
                content=content,
                raw=raw,
                provider="openai_compatible",
                model=self._config.model,
                success=True,
            )

        except HTTPError as e:
            error_code = self._classify_http_error(e.code)
            return LLMResponse(
                content="",
                provider="openai_compatible",
                model=self._config.model,
                success=False,
                error=error_code,
                raw={"http_status": e.code, "http_body": self._safe_read_http_error(e)},
            )

        except URLError as e:
            if "timed out" in str(e.reason).lower():
                error_code = "timeout"
            else:
                error_code = f"connection_error:{e.reason}"
            return LLMResponse(
                content="",
                provider="openai_compatible",
                model=self._config.model,
                success=False,
                error=error_code,
            )

        except json.JSONDecodeError:
            return LLMResponse(
                content="",
                provider="openai_compatible",
                model=self._config.model,
                success=False,
                error="invalid_json_response",
            )

        except TimeoutError:
            return LLMResponse(
                content="",
                provider="openai_compatible",
                model=self._config.model,
                success=False,
                error="timeout",
            )

        except Exception as e:
            return LLMResponse(
                content="",
                provider="openai_compatible",
                model=self._config.model,
                success=False,
                error=f"unexpected:{type(e).__name__}",
            )

    @staticmethod
    def _normalize_messages(messages: List[LLMMessage]) -> List[Dict[str, str]]:
        """SiliconFlow / 本地 Qwen 等 OpenAI 兼容端只接受 system/user/assistant/tool。
        把 developer role 合并到紧邻其后的 system（若无 system 则升级为 system）。"""
        out: List[Dict[str, str]] = []
        pending_developer: List[str] = []
        for m in messages:
            role = m.role
            content = m.content
            if role == "developer":
                pending_developer.append(content)
                continue
            if pending_developer:
                if role == "system":
                    content = content + "\n\n" + "\n\n".join(pending_developer)
                    pending_developer = []
                else:
                    out.append({"role": "system", "content": "\n\n".join(pending_developer)})
                    pending_developer = []
            out.append({"role": role, "content": content})
        if pending_developer:
            out.append({"role": "system", "content": "\n\n".join(pending_developer)})
        return out

    @staticmethod
    def _classify_http_error(status_code: int) -> str:
        mapping = {
            401: "http_401_invalid_api_key",
            403: "http_403_forbidden",
            429: "http_429_rate_limited",
        }
        if status_code in mapping:
            return mapping[status_code]
        if 500 <= status_code <= 599:
            return f"http_{status_code}_server_error"
        return f"http_{status_code}_error"

    @staticmethod
    def _safe_read_http_error(error: HTTPError) -> str:
        try:
            return error.read().decode("utf-8", errors="replace")[:500]
        except Exception:
            return ""
