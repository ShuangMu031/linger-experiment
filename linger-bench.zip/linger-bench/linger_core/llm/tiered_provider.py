import copy
from dataclasses import replace
from typing import Dict, Optional

from linger_core.llm.base import LLMRequest, LLMResponse
from linger_core.llm.task_type import LLMTaskType
from linger_core.llm.llm_config import LLMConfig, TierModelConfig


_TIER_CONFIG_MAP = {
    "cheap": lambda cfg: cfg.cheap,
    "standard": lambda cfg: cfg.standard,
    "top": lambda cfg: cfg.top,
}


class TieredProvider:
    def __init__(self, config: LLMConfig) -> None:
        self._config = config
        self._providers: Dict[str, Optional[object]] = {
            "cheap": None,
            "standard": None,
            "top": None,
        }
        self._initialized = False

    def initialize(self) -> None:
        if self._initialized:
            return

        from linger_core.llm.openai_compatible_provider import (
            OpenAICompatibleProvider,
            OpenAICompatibleConfig,
            RetryConfig,
        )

        base_url = self._config.base_url
        api_key_env = self._config.api_key_env
        timeout = self._config.timeout_seconds

        retry_cfg = RetryConfig(
            enabled=self._config.retry_enabled,
            max_retries_429=self._config.retry_max_429,
            max_retries_transient=self._config.retry_max_transient,
        )

        for tier_name, tier_cfg in [
            ("cheap", self._config.cheap),
            ("standard", self._config.standard),
            ("top", self._config.top),
        ]:
            if not tier_cfg.model:
                continue

            provider_config = OpenAICompatibleConfig(
                base_url=base_url,
                api_key_env=api_key_env,
                model=tier_cfg.model,
                timeout_seconds=timeout,
                retry=retry_cfg,
            )
            self._providers[tier_name] = OpenAICompatibleProvider(config=provider_config)

        self._initialized = True

    def generate(self, request: LLMRequest) -> LLMResponse:
        if not self._initialized:
            self.initialize()

        tier = request.metadata.get("_tier", "standard")
        provider = self._providers.get(tier)

        if provider is None:
            provider = self._providers.get("standard")

        if provider is None:
            return LLMResponse(
                content="",
                provider="tiered",
                model="none",
                success=False,
                error=f"no provider available for tier={tier}",
            )

        return provider.generate(request)

    def generate_for_task(
        self,
        task_type: LLMTaskType,
        request: LLMRequest,
    ) -> LLMResponse:
        requested_tier = self._config.TASK_TIER_MAP.get(task_type.value, "standard")

        tier_cfg_getter = _TIER_CONFIG_MAP.get(requested_tier)
        tier_cfg = tier_cfg_getter(self._config) if tier_cfg_getter else None

        request = replace(
            request,
            temperature=tier_cfg.temperature if tier_cfg else request.temperature,
            max_tokens=tier_cfg.max_tokens if tier_cfg else request.max_tokens,
            metadata={**request.metadata, "_tier": requested_tier, "_task_type": task_type.value},
        )

        if not self._initialized:
            self.initialize()

        provider = self._providers.get(requested_tier)
        actual_tier = requested_tier

        if provider is None:
            fallback_tier = "standard" if requested_tier != "standard" else "cheap"
            provider = self._providers.get(fallback_tier)
            actual_tier = fallback_tier if provider is not None else actual_tier

        if provider is None:
            for tier_name, p in self._providers.items():
                if p is not None:
                    provider = p
                    actual_tier = tier_name
                    break

        if provider is None:
            return LLMResponse(
                content="",
                provider="tiered",
                model="none",
                success=False,
                error="no provider available in any tier",
            )

        response = provider.generate(request)
        if response.raw is None:
            response.raw = {}
        response.raw["requested_tier"] = requested_tier
        response.raw["actual_tier"] = actual_tier
        response.raw["fallback_tier_used"] = actual_tier != requested_tier
        response.raw["task_type"] = task_type.value
        return response

    @property
    def providers(self) -> Dict[str, Optional[object]]:
        return dict(self._providers)
