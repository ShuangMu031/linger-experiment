from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Protocol

from .safe_parse import safe_bool  # noqa: F401


@dataclass
class LLMMessage:
    role: str
    content: str


@dataclass
class LLMRequest:
    messages: List[LLMMessage]
    temperature: float = 0.4
    max_tokens: int = 800
    response_format: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMResponse:
    content: str
    raw: Dict[str, Any] = field(default_factory=dict)
    provider: str = "unknown"
    model: str = "unknown"
    success: bool = True
    error: Optional[str] = None


class BaseLLMProvider(Protocol):
    def generate(self, request: LLMRequest) -> LLMResponse:
        ...
