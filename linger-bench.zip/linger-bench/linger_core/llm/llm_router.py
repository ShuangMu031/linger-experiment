import sys
import time
from dataclasses import dataclass, replace
from typing import Optional

from linger_core.llm.base import LLMRequest, LLMResponse
from linger_core.llm.task_type import LLMTaskType


@dataclass
class LLMCallTrace:
    task_type: str
    provider: str
    model: str
    success: bool
    fallback_used: bool = False
    error: str = ""
    tier: str = ""
    latency_ms: float = 0.0
    response_format: str = ""
    input_message_count: int = 0
    content_preview: str = ""
    trace_id: str = ""


_CONTENT_PREVIEW_MAX_LEN = 120


class LLMRouter:
    def __init__(
        self,
        provider,
        fallback_provider=None,
        trace_store=None,
        runtime_mode: str = "dev",
    ) -> None:
        self._provider = provider
        self._fallback_provider = fallback_provider
        self._trace_store = trace_store
        self._runtime_mode = runtime_mode

    def generate(
        self,
        task_type: LLMTaskType,
        request: LLMRequest,
        trace_id: str = "",
    ) -> LLMResponse:
        start = time.monotonic()

        response = self._dispatch(task_type, request)

        fallback_used = False
        if not response.success and self._fallback_provider:
            fallback_used = True
            if self._runtime_mode == "prod":
                sys.stderr.write(
                    f"[llm_router][prod_fallback] task={task_type.value} "
                    f"primary_error={response.error} -> falling back to mock\n"
                )
            response = self._dispatch_fallback(task_type, request)

        latency_ms = (time.monotonic() - start) * 1000.0

        if self._trace_store:
            content_preview = response.content[:_CONTENT_PREVIEW_MAX_LEN] if response.content else ""
            error_type = ""
            if response.error:
                error_type = response.error.split(":")[0] if ":" in response.error else response.error
            retry_count = 0
            retry_reasons = []
            if response.raw:
                retry_count = response.raw.get("retry_count", 0)
                retry_reasons = response.raw.get("retry_reasons", [])
            self._trace_store.add_step({
                "step": "llm_call",
                "task_type": task_type.value,
                "provider": response.provider,
                "model": response.model,
                "success": response.success,
                "fallback_used": fallback_used,
                "error": response.error,
                "error_type": error_type,
                "tier": response.raw.get("actual_tier", response.raw.get("tier", "")) if response.raw else "",
                "requested_tier": response.raw.get("requested_tier", "") if response.raw else "",
                "fallback_tier_used": response.raw.get("fallback_tier_used", False) if response.raw else False,
                "latency_ms": round(latency_ms, 2),
                "temperature": request.temperature,
                "max_tokens": request.max_tokens,
                "response_format": request.response_format,
                "input_message_count": len(request.messages),
                "content_preview": content_preview,
                "trace_id": trace_id,
                "prompt_id": request.metadata.get("_prompt_id", ""),
                "prompt_version": request.metadata.get("_prompt_version", ""),
                "prompt_hash": request.metadata.get("_prompt_hash", ""),
                "retry_count": retry_count,
                "retry_reasons": retry_reasons,
            })

        return response

    def _dispatch(
        self,
        task_type: LLMTaskType,
        request: LLMRequest,
    ) -> LLMResponse:
        dispatched = replace(
            request,
            metadata={**request.metadata, "_task_type": task_type.value},
        )

        if hasattr(self._provider, "generate_for_task"):
            return self._provider.generate_for_task(task_type, dispatched)

        return self._provider.generate(dispatched)

    def _dispatch_fallback(
        self,
        task_type: LLMTaskType,
        request: LLMRequest,
    ) -> LLMResponse:
        dispatched = replace(
            request,
            metadata={**request.metadata, "_task_type": task_type.value},
        )

        if hasattr(self._fallback_provider, "generate_for_task"):
            return self._fallback_provider.generate_for_task(task_type, dispatched)

        return self._fallback_provider.generate(dispatched)

    @property
    def provider(self):
        return self._provider

    @property
    def fallback_provider(self):
        return self._fallback_provider

    @property
    def trace_store(self):
        return self._trace_store
