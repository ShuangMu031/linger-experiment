import json

from .base import LLMRequest, LLMResponse


_MOCK_JSON_RESPONSES = {
    "emotion_insight": {
        # 8 维 Plutnik schema (T4)。
        # dominant=trust → 旧 7 维映射为 "neutral"，
        # 让既有 mock 测试 (judgment == "neutral") 继续通过。
        "dimensions": {
            "joy": 20, "sadness": 15, "anger": 5, "fear": 10,
            "trust": 35, "disgust": 0, "surprise": 10, "anticipation": 15,
        },
        "dominant": "trust",
        "needs_support": False,
        "risk_level": "low",
        "short_reason": "mock emotion insight",
    },
    "context_check": {
        "needs_memory_recall": False,
        "needs_event_recall": False,
        "needs_world_context": True,
        "needs_clarification": False,
        "short_reason": "mock context check",
    },
    "event_extraction": {
        "event_type": "neutral",
        "summary": "mock event extraction",
        "importance": 0.3,
    },
    "profile_summary": {
        "summary": "mock profile summary",
        "key_traits": [],
        "confidence": 0.5,
    },
    "anchor_date_extract": {
        # T4: §5.1.2 — mock 默认返 null（无未来时间）
        # 测试可通过 MockLLMProvider(fixed_response=...) 或 _StaticJsonProvider
        # 直接控制具体返回。
        "anchor_date": None,
        "reason": "mock anchor_date_extract",
    },
}

_DEFAULT_TEXT_RESPONSE = "我先帮你把这件事捋清楚。"

_MOCK_PROACTIVE_RESPONSES = {
    "gentle_check_in": "我在。有需要就说。",
    "world_observation": "外面有些变化。",
    "reconnect": "回来了。我在。",
    "supportive_presence": "我在。你不用一个人扛。",
}


class MockLLMProvider:
    def __init__(self, fixed_response: str = _DEFAULT_TEXT_RESPONSE) -> None:
        self.fixed_response = fixed_response

    def generate(self, request: LLMRequest) -> LLMResponse:
        if request.response_format == "json":
            return self._generate_json(request)

        task_type = request.metadata.get("_task_type", "")
        if task_type == "proactive_response":
            return self._generate_proactive(request)

        return LLMResponse(
            content=self.fixed_response,
            provider="mock",
            model="mock-llm",
            success=True,
        )

    def _generate_json(self, request: LLMRequest) -> LLMResponse:
        task_type = request.metadata.get("_task_type", "")

        template = _MOCK_JSON_RESPONSES.get(task_type)
        if template is not None:
            return LLMResponse(
                content=json.dumps(template, ensure_ascii=False),
                provider="mock",
                model="mock-llm",
                success=True,
            )

        fallback = {"result": "mock", "reason": "unknown task type"}
        return LLMResponse(
            content=json.dumps(fallback, ensure_ascii=False),
            provider="mock",
            model="mock-llm",
            success=True,
        )

    def _generate_proactive(self, request: LLMRequest) -> LLMResponse:
        action_goal = request.metadata.get("proactive_goal", "gentle_check_in")
        text = _MOCK_PROACTIVE_RESPONSES.get(action_goal, "我在。")
        return LLMResponse(
            content=text,
            provider="mock",
            model="mock-llm",
            success=True,
        )
