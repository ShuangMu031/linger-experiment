from enum import Enum


class LLMTaskType(str, Enum):
    RESPONSE_GENERATION = "response_generation"
    PROACTIVE_RESPONSE = "proactive_response"
    EMOTION_INSIGHT = "emotion_insight"
    CONTEXT_CHECK = "context_check"
    EVENT_EXTRACTION = "event_extraction"
    PROFILE_SUMMARY = "profile_summary"
    ANCHOR_DATE_EXTRACT = "anchor_date_extract"
