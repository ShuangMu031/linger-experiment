from dataclasses import dataclass, field
from typing import Dict


@dataclass
class TierModelConfig:
    model: str = ""
    temperature: float = 0.4
    max_tokens: int = 800


@dataclass
class LLMConfig:
    # 默认安全：tests/dev 直接得到 mock + 模板兜底；生产由 .env 显式翻成 siliconflow + enabled
    enabled: bool = False
    provider: str = "mock"
    base_url: str = ""
    api_key_env: str = "SILICONFLOW_API_KEY"

    cheap: TierModelConfig = field(default_factory=lambda: TierModelConfig(
        model="Qwen/Qwen2.5-7B-Instruct",
        temperature=0.3,
        max_tokens=400,
    ))
    standard: TierModelConfig = field(default_factory=lambda: TierModelConfig(
        model="Qwen/Qwen2.5-72B-Instruct",
        temperature=0.4,
        max_tokens=800,
    ))
    top: TierModelConfig = field(default_factory=lambda: TierModelConfig(
        model="deepseek-ai/DeepSeek-V4-Flash",
        temperature=0.5,
        max_tokens=1200,
    ))

    timeout_seconds: int = 30
    fallback_to_template: bool = True
    strict_init: bool = False
    runtime_mode: str = "dev"

    retry_enabled: bool = True
    retry_max_429: int = 3
    retry_max_transient: int = 1

    TASK_TIER_MAP: Dict[str, str] = field(default_factory=lambda: {
        "emotion_insight": "cheap",
        "context_check": "cheap",
        "event_extraction": "cheap",
        "profile_summary": "cheap",
        # 2026-06-03: standard(Qwen2.5-72B) 在 should_ask_question=False + prompt 整条禁问下
        # 仍系统性甩"……你那边呢?"反问尾巴(trace fc56adc5)。两次纯 prompt 路线没压住,
        # 升档到 top(DeepSeek-V4-Flash)——指令遵循更强,proactive 一起升保持一致。
        "response_generation": "top",
        "proactive_response": "top",
    })
