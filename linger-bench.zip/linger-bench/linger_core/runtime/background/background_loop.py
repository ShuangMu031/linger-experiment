import threading
import time
from datetime import timedelta
from typing import Callable, List, Optional

from linger_core.core.state.runtime_state import RuntimeState
from linger_core.core.state.runtime_state_view import RuntimeStateView
from linger_core.core.timeline.timeline_engine import TimelineEngine
from linger_core.core.events.system_event import SystemEvent
from linger_core.core.events.event_types import EventType
from linger_core.core.events.dispatcher import EventDispatcher
from linger_core.core.observability.event_logger import EventLogger
from linger_core.core.observability.change_log import ChangeLog
from linger_core.core.observability.trace_store import TraceStore
from linger_core.shared.ids import generate_tick_id
from linger_core.triggers.trigger_registry import TriggerRegistry
from linger_core.triggers.trigger_candidate import TriggerCandidate
from linger_core.runtime.orchestrator.runtime_orchestrator import RuntimeOrchestrator, OrchestratorResult
from linger_core.runtime.orchestrator.outbound_dispatcher import OutboundDispatcher
from linger_core.supervisor.proactive_guard import ProactiveGuard


class BackgroundLoop:
    def __init__(
        self,
        state: RuntimeState,
        timeline_engine: TimelineEngine,
        orchestrator: RuntimeOrchestrator,
        dispatcher: EventDispatcher,
        event_logger: EventLogger,
        change_log: ChangeLog,
        trace_store: TraceStore,
        trigger_registry: Optional[TriggerRegistry] = None,
        guard: Optional[ProactiveGuard] = None,
        tick_interval_seconds: float = 60.0,
    ):
        self._state = state
        self._timeline_engine = timeline_engine
        self._orchestrator = orchestrator
        self._dispatcher = dispatcher
        self._event_logger = event_logger
        self._change_log = change_log
        self._trace_store = trace_store
        self._tick_interval = tick_interval_seconds
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._tick_count = 0
        self._trigger_registry = trigger_registry or TriggerRegistry()
        self._outbound_dispatcher = OutboundDispatcher(
            orchestrator, guard=guard, trace_store=self._trace_store
        )
        self._on_proactive: Optional[Callable[[OrchestratorResult], None]] = None

    def set_proactive_callback(
        self, callback: Callable[[OrchestratorResult], None]
    ) -> None:
        self._on_proactive = callback

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        self._event_logger.log_lifecycle("background_loop_started")

    def stop(self) -> None:
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=5)
        self._event_logger.log_lifecycle("background_loop_stopped")

    def tick_once(self) -> List[OrchestratorResult]:
        self._trace_store.start_trace("BACKGROUND_TICK")
        try:
            delta = self._state.clock.delta_since_last_tick()

            self._state.clock.advance(delta)
            self._state.clock.mark_background_tick()

            event = SystemEvent(
                event_type=EventType.BACKGROUND_TICK,
                payload={
                    "tick_id": generate_tick_id(),
                    "tick_count": self._tick_count,
                    "delta_seconds": delta.total_seconds(),
                },
                source="background",
            )
            self._dispatcher.dispatch(event)
            self._event_logger.log_event(event)

            results = self._timeline_engine.tick(self._state, delta)

            for output in results:
                self._change_log.record_rule_output(output)
                self._trace_store.add_step({
                    "step": "rule_applied",
                    "rule": output.rule_name,
                    "target": output.target,
                    "changes_count": len(output.changes),
                })

            self._bridge_world_events()

            view = RuntimeStateView.from_state(self._state)
            trigger_candidates = self._trigger_registry.collect_all(view)

            self._trace_store.add_step({
                "step": "triggers_collected",
                "count": len(trigger_candidates),
                "sources": [c.source_type.value for c in trigger_candidates],
            })

            for candidate in trigger_candidates:
                self._state.plan_state.add_outbound_candidate(candidate)

            proactive_results = self._outbound_dispatcher.drain_and_dispatch(self._state, view)

            if proactive_results and self._on_proactive:
                for result in proactive_results:
                    try:
                        self._on_proactive(result)
                    except Exception as e:
                        self._trace_store.add_step({
                            "step": "proactive_callback_error",
                            "error": str(e),
                        })
                        self._state.debug_state.record_event({
                            "type": "PROACTIVE_CALLBACK_ERROR",
                            "error": str(e),
                            "envelope_id": result.envelope_id,
                        })

            self._state.debug_state.record_tick({
                "tick_id": self._tick_count,
                "delta_seconds": delta.total_seconds(),
                "rules_applied": len(results),
                "triggers_collected": len(trigger_candidates),
                "proactive_dispatched": len(proactive_results),
            })

            self._orchestrator.writeback_manager.persist_background_state(self._state)

            self._tick_count += 1

            return proactive_results
        except Exception as e:
            self._trace_store.add_step({
                "step": "background_tick_error",
                "error": str(e),
            })
            raise
        finally:
            self._trace_store.end_trace(result=f"tick_{self._tick_count}")

    def _bridge_world_events(self) -> None:
        try:
            if self._state.world_event_bridge:
                self._state.world_event_bridge.sync_bridged()
                self._state.world_event_bridge.bridge(
                    real_now=self._state.clock.real_now_time(),
                    world_now=self._state.clock.world_now_time(),
                )
        except Exception as e:
            self._trace_store.add_step({
                "step": "world_event_bridge_error",
                "error": str(e),
            })
            self._state.debug_state.record_event({
                "type": "WORLD_EVENT_BRIDGE_ERROR",
                "error": str(e),
            })

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def tick_count(self) -> int:
        return self._tick_count

    @property
    def trigger_registry(self) -> TriggerRegistry:
        return self._trigger_registry

    def _run_loop(self) -> None:
        while self._running:
            try:
                self.tick_once()
            except Exception as e:
                self._state.debug_state.record_event({
                    "type": "BACKGROUND_LOOP_ERROR",
                    "error": str(e),
                })
            time.sleep(self._tick_interval)
