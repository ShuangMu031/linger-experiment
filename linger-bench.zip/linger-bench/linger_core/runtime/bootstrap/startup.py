import os
import sys
from typing import Optional

from linger_core.core.state.runtime_state import RuntimeState, create_empty_runtime
from linger_core.core.timeline.timeline_engine import TimelineEngine
from linger_core.core.events.dispatcher import EventDispatcher
from linger_core.core.events.system_event import SystemEvent
from linger_core.core.events.event_types import EventType
from linger_core.core.observability.event_logger import EventLogger
from linger_core.core.observability.change_log import ChangeLog
from linger_core.core.observability.trace_store import TraceStore
from linger_core.core.observability.trace_archive import TraceArchive
from linger_core.core.observability.bad_case_archive import BadCaseArchiver
from linger_core.core.observability.health_snapshotter import HealthSnapshotter
from linger_core.supervisor.supervisor_kernel import SupervisorKernel
from linger_core.supervisor.modules.input_interpreter import InputInterpreter
from linger_core.supervisor.modules.emotion_insight_stub import EmotionInsightStub
from linger_core.supervisor.modules.context_check_stub import ContextCheckStub
from linger_core.supervisor.proactive_guard import ProactiveGuard
from linger_core.runtime.orchestrator.runtime_orchestrator import RuntimeOrchestrator
from linger_core.runtime.foreground.foreground_loop import ForegroundLoop
from linger_core.runtime.background.background_loop import BackgroundLoop
from linger_core.triggers.trigger_registry import TriggerRegistry
from linger_core.triggers.followup_trigger_source import FollowupTriggerSource
from linger_core.triggers.world_trigger_source import WorldTriggerSource
from linger_core.triggers.event_trigger_source import EventTriggerSource
from linger_core.triggers.reconnect_trigger_source import ReconnectTriggerSource
from linger_core.triggers.relationship_trigger_source import RelationshipTriggerSource
from linger_core.config.default_config import DefaultConfig
from linger_core.config.time_config import TimeConfig
from linger_core.persistence.repositories.short_term_memory_repository import ShortTermMemoryRepository
from linger_core.persistence.repositories.event_memory_repository import EventMemoryRepository
from linger_core.persistence.repositories.long_term_memory_repository import LongTermMemoryRepository
from linger_core.persistence.repositories.digest_repository import DigestRepository
from linger_core.persistence.repositories.profile_repository import ProfileRepository
from linger_core.persistence.repositories.world_state_repository import WorldStateRepository
from linger_core.persistence.repositories.npc_repository import NpcRepository
from linger_core.persistence.repositories.world_event_repository import WorldEventRepository
from linger_core.world.world_event_generator import WorldEventGenerator
from linger_core.world.world_event_recall import WorldEventRecall
from linger_core.world.world_snapshot_builder import WorldSnapshotBuilder


class Startup:
    def __init__(
        self,
        config: Optional[DefaultConfig] = None,
        time_config: Optional[TimeConfig] = None,
        load_memory: bool = True,
    ):
        self._config = config or DefaultConfig()
        self._time_config = time_config or TimeConfig()
        self._load_memory = load_memory
        self._state: Optional[RuntimeState] = None
        self._dispatcher: Optional[EventDispatcher] = None
        self._event_logger: Optional[EventLogger] = None
        self._change_log: Optional[ChangeLog] = None
        self._trace_store: Optional[TraceStore] = None
        self._timeline_engine: Optional[TimelineEngine] = None
        self._supervisor: Optional[SupervisorKernel] = None
        self._orchestrator: Optional[RuntimeOrchestrator] = None
        self._foreground: Optional[ForegroundLoop] = None
        self._background: Optional[BackgroundLoop] = None
        self._llm_provider = None
        self._prompt_registry = None
        self._skip_env_load = False

    def _load_env(self):
        try:
            from dotenv import load_dotenv
            from pathlib import Path

            env_path = Path(__file__).resolve().parents[3] / ".env"
            if env_path.exists():
                load_dotenv(env_path)
        except Exception:
            pass

    def _apply_env_to_config(self):
        from linger_core.config.env_binding import (
            LLM_BINDINGS, apply_bindings, apply_special_overrides,
        )
        apply_bindings(self._config, LLM_BINDINGS)
        apply_special_overrides(self._config)

    def _build_llm_provider(self):
        from linger_core.llm.mock_provider import MockLLMProvider

        if self._config.llm.provider == "mock":
            return MockLLMProvider()

        if self._config.llm.provider == "openai_compatible":
            from linger_core.llm.openai_compatible_provider import (
                OpenAICompatibleProvider,
                OpenAICompatibleConfig,
            )
            return OpenAICompatibleProvider(
                OpenAICompatibleConfig(
                    base_url=self._config.llm.base_url,
                    api_key_env=self._config.llm.api_key_env,
                    model=self._config.llm.standard.model,
                    timeout_seconds=self._config.llm.timeout_seconds,
                )
            )

        if self._config.llm.provider == "openai":
            return self._build_siliconflow_provider()

        if self._config.llm.provider == "siliconflow":
            return self._build_siliconflow_provider()

        return MockLLMProvider()

    def _build_siliconflow_provider(self):
        from linger_core.llm.tiered_provider import TieredProvider
        from linger_core.llm.mock_provider import MockLLMProvider
        from linger_core.llm.errors import LLMProviderError

        cfg = self._config.llm

        base_url = cfg.base_url or os.environ.get("SILICONFLOW_BASE_URL", "")
        api_key = os.environ.get(cfg.api_key_env, "")

        if not base_url or not api_key:
            if cfg.strict_init:
                raise LLMProviderError(
                    f"SiliconFlow provider requires both base_url and API key. "
                    f"base_url={'set' if base_url else 'missing'}, "
                    f"api_key_env={cfg.api_key_env}: {'set' if api_key else 'missing'}"
                )
            return MockLLMProvider()

        tiered = TieredProvider(cfg)
        tiered.initialize()
        return tiered

    def _build_llm_router(self, provider):
        from linger_core.llm.llm_router import LLMRouter
        from linger_core.llm.tiered_provider import TieredProvider
        from linger_core.llm.mock_provider import MockLLMProvider

        runtime_mode = self._config.llm.runtime_mode

        if isinstance(provider, TieredProvider):
            fallback = MockLLMProvider()
            return LLMRouter(
                provider=provider,
                fallback_provider=fallback,
                trace_store=self._trace_store,
                runtime_mode=runtime_mode,
            )

        if isinstance(provider, MockLLMProvider):
            return LLMRouter(
                provider=provider,
                trace_store=self._trace_store,
                runtime_mode=runtime_mode,
            )

        fallback = MockLLMProvider()
        return LLMRouter(
            provider=provider,
            fallback_provider=fallback,
            trace_store=self._trace_store,
            runtime_mode=runtime_mode,
        )

    def _print_runtime_banner(self):
        cfg = self._config.llm
        line = (
            f"[startup] runtime_mode={cfg.runtime_mode} "
            f"provider={cfg.provider} "
            f"strict_init={cfg.strict_init} "
            f"retry_enabled={cfg.retry_enabled} "
            f"llm_enabled={cfg.enabled} "
            f"fallback_to_template={cfg.fallback_to_template}"
        )
        sys.stderr.write(line + "\n")

    def _build_prompt_registry(self):
        from linger_core.prompts.default_registry import default_prompt_registry
        return default_prompt_registry()

    def _register_handlers(self) -> None:
        def on_system_start(event: SystemEvent) -> None:
            self._state.debug_state.record_event({
                "type": "SYSTEM_START_HANDLER",
                "system_name": event.payload.get("config", "unknown"),
                "real_now": self._state.clock.real_now_time().isoformat(),
            })

        def on_user_input(event: SystemEvent) -> None:
            self._state.session.mark_active(real_now=self._state.clock.real_now_time())
            self._state.debug_state.record_event({
                "type": "USER_INPUT_HANDLER",
                "message_length": len(event.payload.get("message", "")),
                "turn_id": self._state.clock.logical.turn_id,
            })

        def on_background_tick(event: SystemEvent) -> None:
            self._state.debug_state.record_event({
                "type": "BACKGROUND_TICK_HANDLER",
                "tick_count": event.payload.get("tick_count", 0),
                "delta_seconds": event.payload.get("delta_seconds", 0),
            })

        self._dispatcher.register(EventType.SYSTEM_START, on_system_start)
        self._dispatcher.register(EventType.USER_INPUT, on_user_input)
        self._dispatcher.register(EventType.BACKGROUND_TICK, on_background_tick)

    @staticmethod
    def _assert_e3_baseline() -> None:
        """E3 baseline freeze guard (2026-05-03 ~ 2026-06-01).

        Hard-fails if observability schema diverges from the frozen E3 baseline.
        Soft-warns on package version drift (bumping is OK if structure preserved).
        """
        import dataclasses
        import warnings
        from linger_core import __version__
        from linger_core.core.observability.turn_snapshot import TurnSnapshot

        expected_version = "0.4.0a14"
        if __version__ != expected_version:
            warnings.warn(
                f"E3 baseline version drift: pinned {expected_version}, "
                f"got {__version__}. Confirm in 实验问题清单.md before continuing.",
                RuntimeWarning,
                stacklevel=2,
            )

        fields = {f.name: f.default for f in dataclasses.fields(TurnSnapshot)}
        expected_schema = "v1"
        actual_schema = fields.get("schema_version")
        if actual_schema != expected_schema:
            raise RuntimeError(
                f"E3 baseline schema_version mismatch: expected '{expected_schema}', "
                f"got '{actual_schema}'. Schema changes invalidate E3 trace data. "
                f"See 实验问题清单.md B1/B2/E1."
            )

    def _register_modules(self) -> None:
        self._supervisor.register_module(InputInterpreter())

        if self._config.llm.enabled:
            from linger_core.supervisor.modules.emotion_insight_module import EmotionInsightModule
            from linger_core.supervisor.modules.context_check_module import ContextCheckModule

            self._supervisor.register_module(
                EmotionInsightModule(
                    llm_provider=self._llm_provider,
                    prompt_registry=self._prompt_registry,
                    llm_enabled=True,
                    llm_router=self._llm_router,
                )
            )
            self._supervisor.register_module(
                ContextCheckModule(
                    llm_provider=self._llm_provider,
                    prompt_registry=self._prompt_registry,
                    llm_enabled=True,
                    llm_router=self._llm_router,
                )
            )
        else:
            self._supervisor.register_module(EmotionInsightStub())
            self._supervisor.register_module(ContextCheckStub())

    def initialize(self) -> RuntimeState:
        self._assert_e3_baseline()
        self._state = create_empty_runtime(
            config=self._config,
            time_config=self._time_config,
        )

        self._memory_repo = ShortTermMemoryRepository()
        self._event_repo = EventMemoryRepository()
        self._ltm_repo = LongTermMemoryRepository()
        self._digest_repo = DigestRepository()
        self._profile_repo = ProfileRepository()
        self._world_state_repo = WorldStateRepository()
        self._npc_repo = NpcRepository()
        self._world_event_repo = WorldEventRepository()
        if self._load_memory:
            conversation_id = self._state.session.conversation_id
            if self._memory_repo.exists(conversation_id):
                loaded = self._memory_repo.load(conversation_id)
                self._state.short_term_memory = loaded
            if self._event_repo.exists(conversation_id):
                event_loaded = self._event_repo.load(conversation_id)
                self._state.event_memory = event_loaded
                self._state.memory_state.sync_from_event_store(event_loaded)
            if self._ltm_repo.exists(conversation_id):
                ltm_loaded = self._ltm_repo.load(conversation_id)
                self._state.long_term_memory = ltm_loaded
            if self._digest_repo.exists(conversation_id):
                digests = self._digest_repo.load(conversation_id)
                for d in digests:
                    self._state.digest_generator.add_bundle(d)
            if self._profile_repo.exists(conversation_id):
                profile = self._profile_repo.load(conversation_id)
                if profile:
                    self._state.profile_builder._snapshot = profile
                    self._state.profile_state.update_from_profile_snapshot(profile)
            self._state.profile_state.update_from_ltm_store(self._state.long_term_memory)

            if self._world_state_repo.exists(conversation_id):
                world_data = self._world_state_repo.load(conversation_id)
                if world_data:
                    self._state.world_runtime = self._world_state_repo.restore_runtime(world_data)
                    self._state.ambient_state = self._world_state_repo.restore_ambient(world_data)
            if self._npc_repo.exists(conversation_id):
                npcs = self._npc_repo.load(conversation_id)
                for npc in npcs:
                    self._state.npc_registry.register(npc)
            if self._world_event_repo.exists(conversation_id):
                wev_store = self._world_event_repo.load(conversation_id)
                self._state.world_event_store = wev_store

            self._state.world_event_generator = WorldEventGenerator(
                event_store=self._state.world_event_store,
                npc_registry=self._state.npc_registry,
            )
            self._state.world_event_recall = WorldEventRecall(
                event_store=self._state.world_event_store,
            )
            self._state.world_snapshot_builder = WorldSnapshotBuilder(
                world_runtime=self._state.world_runtime,
                npc_registry=self._state.npc_registry,
                event_recall=self._state.world_event_recall,
            )

        self._dispatcher = EventDispatcher()
        self._event_logger = EventLogger()
        self._change_log = ChangeLog()
        self._trace_store = TraceStore()
        self._trace_archive = TraceArchive()
        self._bad_case_archiver = BadCaseArchiver()
        self._health_snapshotter = HealthSnapshotter(archive=self._trace_archive)
        self._timeline_engine = TimelineEngine()

        if not self._skip_env_load:
            self._load_env()
            self._apply_env_to_config()

        self._print_runtime_banner()

        self._llm_provider = self._build_llm_provider()
        self._prompt_registry = self._build_prompt_registry()
        self._llm_router = self._build_llm_router(self._llm_provider)

        self._supervisor = SupervisorKernel(trace_store=self._trace_store)

        self._register_handlers()
        self._register_modules()

        self._orchestrator = RuntimeOrchestrator(
            supervisor=self._supervisor,
            dispatcher=self._dispatcher,
            event_logger=self._event_logger,
            trace_store=self._trace_store,
            llm_provider=self._llm_provider,
            prompt_registry=self._prompt_registry,
            llm_enabled=self._config.llm.enabled,
            llm_router=self._llm_router,
            trace_archive=self._trace_archive,
            bad_case_archiver=self._bad_case_archiver,
            health_snapshotter=self._health_snapshotter,
            fallback_to_template=self._config.llm.fallback_to_template,
            enable_user_fact_memory=self._config.memory.enable_user_fact_memory,
        )

        self._foreground = ForegroundLoop(
            state=self._state,
            orchestrator=self._orchestrator,
            trace_store=self._trace_store,
        )

        trigger_registry = TriggerRegistry(trace_store=self._trace_store)
        trigger_registry.register(FollowupTriggerSource())
        trigger_registry.register(WorldTriggerSource())
        trigger_registry.register(EventTriggerSource())
        trigger_registry.register(ReconnectTriggerSource())
        trigger_registry.register(RelationshipTriggerSource())

        guard = ProactiveGuard(config=self._config.proactive)

        self._background = BackgroundLoop(
            state=self._state,
            timeline_engine=self._timeline_engine,
            orchestrator=self._orchestrator,
            dispatcher=self._dispatcher,
            event_logger=self._event_logger,
            change_log=self._change_log,
            trace_store=self._trace_store,
            trigger_registry=trigger_registry,
            guard=guard,
            tick_interval_seconds=self._time_config.background_tick_interval_seconds,
        )

        start_event = SystemEvent(
            event_type=EventType.SYSTEM_START,
            payload={"config": self._config.system.system_name},
            source="startup",
        )
        self._dispatcher.dispatch(start_event)
        self._event_logger.log_event(start_event)
        self._state.debug_state.record_event(start_event.to_dict())

        return self._state

    def start_background(self) -> None:
        if self._background:
            self._background.start()

    def stop_background(self) -> None:
        if self._background:
            self._background.stop()

    @property
    def state(self) -> Optional[RuntimeState]:
        return self._state

    @property
    def foreground(self) -> Optional[ForegroundLoop]:
        return self._foreground

    @property
    def background(self) -> Optional[BackgroundLoop]:
        return self._background

    @property
    def supervisor(self) -> Optional[SupervisorKernel]:
        return self._supervisor

    @property
    def orchestrator(self) -> Optional[RuntimeOrchestrator]:
        return self._orchestrator

    @property
    def event_logger(self) -> Optional[EventLogger]:
        return self._event_logger

    @property
    def change_log(self) -> Optional[ChangeLog]:
        return self._change_log

    @property
    def trace_store(self) -> Optional[TraceStore]:
        return self._trace_store

    @property
    def trace_archive(self) -> Optional[TraceArchive]:
        return self._trace_archive

    @property
    def bad_case_archiver(self):
        return self._bad_case_archiver

    @property
    def health_snapshotter(self):
        return self._health_snapshotter

    @property
    def llm_provider(self):
        return self._llm_provider

    @property
    def llm_router(self):
        return self._llm_router

    @property
    def prompt_registry(self):
        return self._prompt_registry
