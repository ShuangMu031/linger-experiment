from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from linger_core.supervisor.action_plan import ActionStep


@dataclass
class ActionResult:
    step_id: str
    success: bool
    result_summary: str = ""
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step_id": self.step_id,
            "success": self.success,
            "result_summary": self.result_summary,
            "details": self.details,
        }


def record_action_step(
    action_type: str,
    target: str,
    reason: str = "",
    planned_steps: Optional[List[ActionStep]] = None,
) -> ActionStep:
    import uuid

    step = ActionStep(
        step_id=f"as_{uuid.uuid4().hex[:8]}",
        action_type=action_type,
        target=target,
        reason=reason,
        status="executing",
    )
    if planned_steps is not None:
        planned_steps.append(step)
    return step


def mark_step_completed(step: ActionStep, summary: str = "") -> None:
    step.status = "completed"
    step.result_summary = summary


def mark_step_failed(step: ActionStep, error: str = "") -> None:
    step.status = "failed"
    step.result_summary = error
