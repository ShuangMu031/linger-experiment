from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.core.state.runtime_state import RuntimeState
from linger_core.memory.digest_recall import DigestRecall
from linger_core.memory.profile_recall import ProfileRecall
from linger_core.shared.enums import DigestWindowType


class StartupContextBuilder:
    def __init__(self):
        self._digest_recall: Optional[DigestRecall] = None
        self._profile_recall: Optional[ProfileRecall] = None

    def build(self, state: RuntimeState) -> Dict[str, Any]:
        now = datetime.now()
        self._digest_recall = DigestRecall(state.digest_generator.get_all())
        self._profile_recall = ProfileRecall(
            state.long_term_memory,
            state.profile_builder.current_snapshot,
        )

        context: Dict[str, Any] = {}

        context["digest_summary"] = self._digest_recall.build_context_summary()
        context["digest_full"] = self._digest_recall.build_full_context()
        context["unresolved_topics"] = self._digest_recall.recall_unresolved_topics()
        context["emotion_trend"] = self._digest_recall.recall_emotion_trend()
        context["relationship_trend"] = self._digest_recall.recall_relationship_trend()
        context["recommended_style"] = self._digest_recall.recall_recommended_style()
        context["recommended_openers"] = self._digest_recall.recall_openers()

        context["profile_hint"] = self._profile_recall.get_profile_hint()
        context["ltm_context"] = self._profile_recall.build_context_summary(n=8)

        context["relationship"] = {
            "stage": state.profile_state.relationship_stage,
            "familiarity": state.profile_state.familiarity,
            "trust_level": state.profile_state.trust_level,
            "warmth": state.profile_state.warmth,
            "preferred_distance": state.profile_state.preferred_distance,
        }

        context["risk_flags"] = state.profile_state.risk_flags
        context["top_topics"] = state.profile_state.top_topics

        return context

    def build_greeting_context(self, state: RuntimeState) -> Dict[str, Any]:
        full = self.build(state)
        greeting: Dict[str, Any] = {}

        relationship_trend = full.get("relationship_trend", "stable")
        recommended_style = full.get("recommended_style", "balanced")
        openers = full.get("recommended_openers", [])
        top_topics = full.get("top_topics", [])
        relationship = full.get("relationship", {})

        greeting["style"] = recommended_style
        greeting["relationship_stage"] = relationship.get("stage", "stranger")
        greeting["warmth"] = relationship.get("warmth", 0.5)
        greeting["trust"] = relationship.get("trust_level", 0.3)

        if openers:
            greeting["suggested_opener"] = openers[0]
        elif top_topics:
            greeting["suggested_opener"] = f"关于{top_topics[0]}，最近怎么样？"
        else:
            greeting["suggested_opener"] = ""

        if relationship_trend == "cooling":
            greeting["tone"] = "gentle_caring"
        elif relationship_trend == "warming":
            greeting["tone"] = "warm_friendly"
        elif relationship_trend == "volatile":
            greeting["tone"] = "calm_stable"
        else:
            greeting["tone"] = "balanced"

        return greeting
