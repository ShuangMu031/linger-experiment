"""TemplateRuleEngine — 单一规则引擎。

按 SelectContext.kind 派发：
- "user_input"：优先级链（tool → event → context → speak_mode → world → fallback）
- "proactive"：按 plan.primary_goal 的 builder map 派发

返回 ResponsePlan（kind="template"），由 caller 调 .render()。
"""
from typing import Optional, Tuple

from linger_core.runtime.foreground.response_plan import ResponsePlan, SelectContext
from linger_core.supervisor.action_plan import ActionPlan
from linger_core.world.world_labels import mood_zh


# ============================================================
# user_input templates（18 个，从 ResponseBuilder 搬来）
# ============================================================
COMFORT_ONLY_TEMPLATES = [
    "我在这里。",
    "嗯，我在。",
    "你不用一个人扛。",
]

COMFORT_FIRST_TEMPLATES = [
    "我理解你的感受。如果想说，我随时听着。",
    "这种感觉很难受吧。我在，慢慢来。",
    "我听到了。你不用急着好起来。",
]

COMFORT_CONTINUE_TEMPLATES = [
    "我还在。你慢慢说。",
    "嗯，我还在听。",
    "不用急，我在这里。",
]

GENTLE_PRESENCE_TEMPLATES = [
    "嗯...",
    "我在。",
    "...",
]

WARM_RESPOND_TEMPLATES = [
    "让我想想...{topic}",
    "好问题。{topic}",
    "嗯，关于{topic}——",
]

WELCOME_BACK_TEMPLATES = [
    "好久不见！{topic}",
    "你回来了！{topic}",
    "嘿，{topic}",
]

NORMAL_TEMPLATES = [
    "收到。{topic}",
    "嗯，{topic}",
    "好的，{topic}",
]

INQUIRE_TEMPLATES = [
    "让我想想...关于「{topic}」",
    "好问题。「{topic}」——",
    "嗯，关于「{topic}」",
]

CONTINUE_THREAD_TEMPLATES = [
    "你刚刚说到{topic}，我还在想。",
    "关于{topic}——我还在。",
    "刚才{topic}，我还在想这件事。",
]

EMOTION_CONTINUE_TEMPLATES = [
    "我能感觉到，你现在还没完全缓下来。",
    "嗯，这种感觉不会马上过去。",
    "我还在，不用急着好起来。",
]

SELF_FOLLOWUP_TEMPLATES = [
    "我刚刚那句不是想催你，只是有点在意。",
    "隔了一会儿，我还是想接着刚才那句说一下。",
    "刚才说的那件事，我还在想。",
]

EVENT_FOLLOWUP_TEMPLATES = [
    "之前{event_title}，你现在还好吗？",
    "关于{event_title}——我还在想。",
    "上次{event_title}，后来怎么样了？",
]

EVENT_UNRESOLVED_TEMPLATES = [
    "之前你说的{event_title}，想得怎么样了？",
    "关于{event_title}，我还在想，你现在有头绪了吗？",
    "上次{event_title}的事，你不用急着决定。",
]

EVENT_EMOTION_RECALL_TEMPLATES = [
    "上次{event_title}的时候，你很难受。我在想你现在怎么样了。",
    "关于{event_title}——我还在，如果你还想说。",
    "之前{event_title}，我一直记着。",
]

WORLD_NIGHT_TEMPLATES = [
    "夜深了。{topic}",
    "这么晚了，{topic}",
    "安静的夜晚。{topic}",
]

WORLD_RAIN_TEMPLATES = [
    "外面在下雨。{topic}",
    "听着雨声，{topic}",
    "雨天总是让人慢下来。{topic}",
]

WORLD_NPC_NEARBY_TEMPLATES = [
    "{npc_name}好像在附近。{topic}",
    "{npc_name}也在呢。{topic}",
]

WORLD_AMBIENT_TEMPLATES = [
    "现在这里很{ambient}。{topic}",
    "周围感觉{ambient}。{topic}",
]


# ============================================================
# proactive templates（6 个（含 WORLD_OBSERVATION_TEMPLATES dict-of-lists），从 ProactiveResponseBuilder 搬来；本 task 暂不用，task 4 用）
# ============================================================
GENTLE_CHECK_IN_TEMPLATES = [
    "我刚刚在想，你这边还需要什么。",
    "在。要不要我把你手上那个没做完的事拆一步？",
    "有一阵了。不用急着回，我就是看你在不在。",
    "你还在就行。那个问题不急着马上解决。",
]

WORLD_OBSERVATION_TEMPLATES = {
    "weather_change": [
        "外面{detail}。不是什么大事，就是提一嘴。",
        "天气变了——{detail}。",
    ],
    "time_change": [
        "{detail}了。你还在忙的话，注意一下时间。",
        "{detail}，你节奏自己拿。",
    ],
    "npc_activity_change": [
        "{npc_name}在{detail}，看起来还行。",
        "{npc_name}那边{detail}。",
    ],
    "place_ambient_change": [
        "这里{detail}。",
        "氛围{detail}，不太像刚才了。",
    ],
    "default": [
        "有个变化：{detail}。先让你知道一下。",
        "注意到的：{detail}。",
    ],
}

RECONNECT_TEMPLATES = [
    "回来了。我在。",
    "嗯，你回来了。刚才没跑远。",
    "回来了就好。有什么要接着说的吗？",
]

UNFINISHED_THREAD_TEMPLATES = [
    "之前说的「{topic}」——你现在有想法了吗？不用急。",
    "上次「{topic}」的事，我帮你记着。",
    "那个「{topic}」，你要是还需要我帮忙拆，说一声。",
]

OPEN_CHAT_TEMPLATES = [
    "在啊。在做什么呢。",
    "嘿，刚好想到你，没什么事，就发一句。",
    "嗯——就是想找你说说话。",
]

SHARE_WITH_FRIEND_TEMPLATES = [
    "诶——我刚才一直在想「{topic}」这事。",
    "想跟你说点东西，关于「{topic}」。",
    "我心里一直有个事在转：「{topic}」。",
]

EXPRESS_CONCERN_TEMPLATES = [
    "「{topic}」——后来怎么样了？我一直惦记着。",
    "想到你之前说的「{topic}」，还好吗？",
    "那件事「{topic}」最近有进展吗？没事就告诉我一声。",
]

SUPPORTIVE_PRESENCE_TEMPLATES = [
    "我在。你不用一个人扛。",
    "嗯，我在。你想说什么就说，不想说也行。",
    "这种感觉不会马上过去，但会过去的。我在。",
    "先不用急着处理，缓一下也可以。",
]

LIGHT_PLAN_REMINDER_TEMPLATES = [
    "之前说的「{topic}」——不用急，但别完全忘了。",
    "那个「{topic}」还在。你要不要找个时间收一下？",
    "想起一件事：「{topic}」。不是催你，就是让你知道我还记着。",
    "你那个「{topic}」，我这边还挂着。",
]


# ============================================================
# Engine
# ============================================================
class TemplateRuleEngine:
    """单一规则引擎；select() 立即按 kind 派发到两个私有方法。"""

    def select(self, plan: ActionPlan, ctx: SelectContext) -> ResponsePlan:
        if ctx.kind == "proactive":
            return self._select_proactive(plan, ctx)
        return self._select_user_input(plan, ctx)

    # =================== user_input 优先级链 ===================
    def _select_user_input(self, plan: ActionPlan, ctx: SelectContext) -> ResponsePlan:
        topic = ctx.user_message[:20] if ctx.user_message else "..."

        # 1. tool aware
        if ctx.tool_results:
            tool_plan = self._try_tool_aware(plan, ctx)
            if tool_plan is not None:
                return tool_plan

        # 2. event aware
        if ctx.event_context:
            event_plan = self._try_event_aware(plan, ctx, topic)
            if event_plan is not None:
                return event_plan

        # 3. context aware
        if ctx.recent_context:
            context_plan = self._try_context_aware(plan, ctx, topic)
            if context_plan is not None:
                return context_plan

        # 4. speak_mode 直选
        speak_plan = self._try_speak_mode(plan, ctx, topic)
        if speak_plan is not None:
            return speak_plan

        # 5. should_comfort / should_ask_question
        if plan.should_comfort:
            text, idx = self._pick(COMFORT_FIRST_TEMPLATES, ctx.turn_id)
            return ResponsePlan(
                kind="template",
                template_id="COMFORT_FIRST",
                template_text=text,
                metadata={"selection_reason": "plan_flag:should_comfort", "pick_idx": idx},
            )
        if plan.should_ask_question:
            text, idx = self._pick(INQUIRE_TEMPLATES, ctx.turn_id)
            return ResponsePlan(
                kind="template",
                template_id="INQUIRE",
                template_text=text,
                format_args={"topic": topic},
                metadata={"selection_reason": "plan_flag:should_ask_question", "pick_idx": idx},
            )

        # 6. digest opener
        if ctx.digest_context and ctx.digest_context.get("recommended_openers"):
            openers = ctx.digest_context["recommended_openers"]
            if openers and plan.speak_mode == "normal":
                return ResponsePlan(
                    kind="template",
                    template_id="DIGEST_OPENER",
                    final_text=openers[0],
                    metadata={"selection_reason": "digest:opener"},
                )

        # 7. world aware
        if ctx.world_context:
            world_plan = self._try_world_aware(plan, ctx, topic)
            if world_plan is not None:
                return world_plan

        # 8. fallback NORMAL
        text, idx = self._pick(NORMAL_TEMPLATES, ctx.turn_id)
        return ResponsePlan(
            kind="template",
            template_id="NORMAL",
            template_text=text,
            format_args={"topic": topic},
            metadata={"selection_reason": "fallback:normal", "pick_idx": idx},
        )

    # ---------- user_input helpers ----------
    def _try_speak_mode(self, plan: ActionPlan, ctx: SelectContext, topic: str) -> Optional[ResponsePlan]:
        speak = plan.speak_mode
        if speak == "comfort_only":
            text, idx = self._pick(COMFORT_ONLY_TEMPLATES, ctx.turn_id)
            return ResponsePlan(
                kind="template", template_id="COMFORT_ONLY", template_text=text,
                metadata={"selection_reason": "speak_mode:comfort_only", "pick_idx": idx},
            )
        if speak == "comfort_first":
            text, idx = self._pick(COMFORT_FIRST_TEMPLATES, ctx.turn_id)
            return ResponsePlan(
                kind="template", template_id="COMFORT_FIRST", template_text=text,
                metadata={"selection_reason": "speak_mode:comfort_first", "pick_idx": idx},
            )
        if speak == "gentle_presence":
            text, idx = self._pick(GENTLE_PRESENCE_TEMPLATES, ctx.turn_id)
            return ResponsePlan(
                kind="template", template_id="GENTLE_PRESENCE", template_text=text,
                metadata={"selection_reason": "speak_mode:gentle_presence", "pick_idx": idx},
            )
        if speak == "warm_respond":
            text, idx = self._pick(WARM_RESPOND_TEMPLATES, ctx.turn_id)
            return ResponsePlan(
                kind="template", template_id="WARM_RESPOND", template_text=text,
                format_args={"topic": topic},
                metadata={"selection_reason": "speak_mode:warm_respond", "pick_idx": idx},
            )
        if speak == "warm_acknowledge":
            return ResponsePlan(
                kind="template", template_id="WARM_ACK",
                final_text=f"我听到了。{topic}...",
                metadata={"selection_reason": "speak_mode:warm_acknowledge"},
            )
        if speak == "welcome_back":
            text, idx = self._pick(WELCOME_BACK_TEMPLATES, ctx.turn_id)
            return ResponsePlan(
                kind="template", template_id="WELCOME_BACK", template_text=text,
                format_args={"topic": topic},
                metadata={"selection_reason": "speak_mode:welcome_back", "pick_idx": idx},
            )
        return None

    def _try_event_aware(
        self, plan: ActionPlan, ctx: SelectContext, topic: str
    ) -> Optional[ResponsePlan]:
        ectx = ctx.event_context
        active_events = getattr(ectx, "active_events", [])
        if not active_events:
            return None

        top_event = active_events[0]
        event_title = ""
        if top_event:
            event_title = top_event.get("display_title", "") or top_event.get("title", "")[:15]
        title_or_topic = event_title or topic

        has_unresolved = getattr(ectx, "has_unresolved", False)
        has_high_emotion = getattr(ectx, "has_high_emotion", False)
        should_follow_up = getattr(ectx, "should_follow_up", False)
        continuation_likely = getattr(ectx, "continuation_likely", False)

        if has_unresolved and plan.speak_mode in ("gentle_presence", "warm_respond", "warm_acknowledge"):
            text, idx = self._pick(EVENT_UNRESOLVED_TEMPLATES, ctx.turn_id)
            return ResponsePlan(
                kind="template", template_id="EVENT_UNRESOLVED", template_text=text,
                format_args={"event_title": title_or_topic},
                metadata={"selection_reason": "event_aware:unresolved", "pick_idx": idx},
            )

        if has_high_emotion and plan.speak_mode in ("comfort_only", "comfort_first", "gentle_presence"):
            text, idx = self._pick(EVENT_EMOTION_RECALL_TEMPLATES, ctx.turn_id)
            return ResponsePlan(
                kind="template", template_id="EVENT_EMOTION_RECALL", template_text=text,
                format_args={"event_title": title_or_topic},
                metadata={"selection_reason": "event_aware:high_emotion", "pick_idx": idx},
            )

        if continuation_likely and top_event:
            event_status = top_event.get("status", "")
            if event_status in ("open", "cooled"):
                if top_event.get("unresolved_score", 0) >= 0.4:
                    text, idx = self._pick(EVENT_UNRESOLVED_TEMPLATES, ctx.turn_id)
                    return ResponsePlan(
                        kind="template", template_id="EVENT_UNRESOLVED", template_text=text,
                        format_args={"event_title": title_or_topic},
                        metadata={"selection_reason": "event_aware:continuation_unresolved", "pick_idx": idx},
                    )
                text, idx = self._pick(EVENT_FOLLOWUP_TEMPLATES, ctx.turn_id)
                return ResponsePlan(
                    kind="template", template_id="EVENT_FOLLOWUP", template_text=text,
                    format_args={"event_title": title_or_topic},
                    metadata={"selection_reason": "event_aware:continuation_followup", "pick_idx": idx},
                )
            if event_status == "resolved":
                text, idx = self._pick(EVENT_EMOTION_RECALL_TEMPLATES, ctx.turn_id)
                return ResponsePlan(
                    kind="template", template_id="EVENT_EMOTION_RECALL", template_text=text,
                    format_args={"event_title": title_or_topic},
                    metadata={"selection_reason": "event_aware:resolved_recall", "pick_idx": idx},
                )

        if should_follow_up and plan.speak_mode in ("gentle_presence", "warm_respond"):
            text, idx = self._pick(EVENT_FOLLOWUP_TEMPLATES, ctx.turn_id)
            return ResponsePlan(
                kind="template", template_id="EVENT_FOLLOWUP", template_text=text,
                format_args={"event_title": title_or_topic},
                metadata={"selection_reason": "event_aware:should_follow_up", "pick_idx": idx},
            )

        return None

    def _try_context_aware(
        self, plan: ActionPlan, ctx: SelectContext, topic: str
    ) -> Optional[ResponsePlan]:
        rctx = ctx.recent_context

        if hasattr(rctx, "recent_comfort_count") and rctx.recent_comfort_count >= 2:
            if plan.should_comfort or plan.speak_mode in ("comfort_only", "comfort_first"):
                text, idx = self._pick(COMFORT_CONTINUE_TEMPLATES, ctx.turn_id)
                return ResponsePlan(
                    kind="template", template_id="COMFORT_CONTINUE", template_text=text,
                    metadata={"selection_reason": "context_aware:repeated_comfort", "pick_idx": idx},
                )

        if hasattr(rctx, "last_assistant_speak_mode") and rctx.last_assistant_speak_mode:
            last_mode = rctx.last_assistant_speak_mode
            if last_mode in ("comfort_only", "comfort_first") and plan.speak_mode in ("comfort_only", "comfort_first"):
                text, idx = self._pick(EMOTION_CONTINUE_TEMPLATES, ctx.turn_id)
                return ResponsePlan(
                    kind="template", template_id="EMOTION_CONTINUE", template_text=text,
                    metadata={"selection_reason": "context_aware:emotion_continue", "pick_idx": idx},
                )

        if hasattr(rctx, "last_assistant_had_followup") and rctx.last_assistant_had_followup:
            if plan.speak_mode in ("gentle_presence", "warm_respond"):
                text, idx = self._pick(SELF_FOLLOWUP_TEMPLATES, ctx.turn_id)
                return ResponsePlan(
                    kind="template", template_id="SELF_FOLLOWUP", template_text=text,
                    metadata={"selection_reason": "context_aware:self_followup", "pick_idx": idx},
                )

        if hasattr(rctx, "recent_user_messages") and rctx.recent_user_messages:
            recent_msgs = rctx.recent_user_messages
            if len(recent_msgs) >= 2:
                prev_msg = recent_msgs[-2] if len(recent_msgs) >= 2 else ""
                if prev_msg and plan.speak_mode == "normal":
                    short_topic = prev_msg[:15]
                    text, idx = self._pick(CONTINUE_THREAD_TEMPLATES, ctx.turn_id)
                    return ResponsePlan(
                        kind="template", template_id="CONTINUE_THREAD", template_text=text,
                        format_args={"topic": short_topic},
                        metadata={"selection_reason": "context_aware:continue_thread", "pick_idx": idx},
                    )

        return None

    def _try_world_aware(
        self, plan: ActionPlan, ctx: SelectContext, topic: str
    ) -> Optional[ResponsePlan]:
        wctx = ctx.world_context or {}
        wc_time = wctx.get("time", {})
        wc_ambient = wctx.get("ambient", {})
        wc_npcs = wctx.get("npcs", [])

        if wc_time.get("time_of_day") == "night" and plan.speak_mode in ("normal", "warm_respond", "gentle_presence"):
            text, idx = self._pick(WORLD_NIGHT_TEMPLATES, ctx.turn_id)
            return ResponsePlan(
                kind="template", template_id="WORLD_NIGHT", template_text=text,
                format_args={"topic": topic},
                metadata={"selection_reason": "world_aware:night", "pick_idx": idx},
            )

        wc_weather = wc_time.get("weather", "")
        if wc_weather in ("rainy", "stormy") and plan.speak_mode in ("normal", "warm_respond", "gentle_presence"):
            text, idx = self._pick(WORLD_RAIN_TEMPLATES, ctx.turn_id)
            return ResponsePlan(
                kind="template", template_id="WORLD_RAIN", template_text=text,
                format_args={"topic": topic},
                metadata={"selection_reason": "world_aware:rain", "pick_idx": idx},
            )

        if wc_npcs and plan.speak_mode in ("normal", "warm_respond"):
            nearby = [n for n in wc_npcs if n.get("is_nearby")]
            if nearby:
                npc_name = nearby[0].get("name", "某人")
                text, idx = self._pick(WORLD_NPC_NEARBY_TEMPLATES, ctx.turn_id)
                return ResponsePlan(
                    kind="template", template_id="WORLD_NPC_NEARBY", template_text=text,
                    format_args={"npc_name": npc_name, "topic": topic},
                    metadata={"selection_reason": "world_aware:npc_nearby", "pick_idx": idx},
                )

        wc_mood = wc_ambient.get("mood", "")
        if wc_mood and wc_mood not in ("neutral", "calm") and plan.speak_mode in ("normal", "warm_respond"):
            text, idx = self._pick(WORLD_AMBIENT_TEMPLATES, ctx.turn_id)
            return ResponsePlan(
                kind="template", template_id="WORLD_AMBIENT", template_text=text,
                format_args={"ambient": mood_zh(wc_mood), "topic": topic},
                metadata={"selection_reason": "world_aware:ambient", "pick_idx": idx},
            )

        return None

    def _try_tool_aware(self, plan: ActionPlan, ctx: SelectContext) -> Optional[ResponsePlan]:
        for tr in (ctx.tool_results or []):
            d = tr.to_dict() if hasattr(tr, "to_dict") else tr
            if not isinstance(d, dict) or not d.get("success"):
                continue
            tool_name = d.get("tool_name", "")
            result = d.get("result")

            if tool_name == "time_tool" and isinstance(result, dict):
                world_time = result.get("world_time", "")
                real_time = result.get("real_time", "")
                if world_time:
                    return ResponsePlan(
                        kind="template", template_id="TOOL_TIME",
                        final_text=f"现在是{world_time}。",
                        metadata={"selection_reason": "tool_aware:time_world"},
                    )
                if real_time:
                    return ResponsePlan(
                        kind="template", template_id="TOOL_TIME",
                        final_text=f"现在的时间是{real_time}。",
                        metadata={"selection_reason": "tool_aware:time_real"},
                    )

            if tool_name == "memory_search_tool" and isinstance(result, dict):
                found = result.get("found", False)
                if found:
                    summary = result.get("summary", "")
                    if summary:
                        return ResponsePlan(
                            kind="template", template_id="TOOL_MEMORY",
                            final_text=f"我记得——{summary[:80]}",
                            metadata={"selection_reason": "tool_aware:memory_found_with_summary"},
                        )
                    return ResponsePlan(
                        kind="template", template_id="TOOL_MEMORY",
                        final_text="嗯，我记得这件事。",
                        metadata={"selection_reason": "tool_aware:memory_found_no_summary"},
                    )
                return ResponsePlan(
                    kind="template", template_id="TOOL_MEMORY",
                    final_text="我翻了翻记忆，没有找到相关的。",
                    metadata={"selection_reason": "tool_aware:memory_not_found"},
                )

            if tool_name == "world_state_tool" and isinstance(result, dict):
                location = result.get("location", "")
                weather = result.get("weather", "")
                npcs = result.get("nearby_npcs", [])
                parts = []
                if location:
                    parts.append(f"现在在{location}")
                if weather:
                    parts.append(f"天气{weather}")
                if npcs and isinstance(npcs, list):
                    names = [n if isinstance(n, str) else n.get("name", "") for n in npcs[:3]]
                    names = [n for n in names if n]
                    if names:
                        parts.append(f"附近有{', '.join(names)}")
                if parts:
                    return ResponsePlan(
                        kind="template", template_id="TOOL_WORLD_STATE",
                        final_text="。".join(parts) + "。",
                        metadata={"selection_reason": "tool_aware:world_state"},
                    )
        return None

    # =================== proactive 派发 ===================
    def _select_proactive(self, plan: ActionPlan, ctx: SelectContext) -> ResponsePlan:
        builder_map = {
            "gentle_check_in": self._build_proactive_gentle_check_in,
            "world_observation": self._build_proactive_world_observation,
            "world_event_notify": self._build_proactive_world_observation,
            "reconnect": self._build_proactive_reconnect,
            "unfinished_thread_ping": self._build_proactive_unfinished_thread,
            "unresolved_check": self._build_proactive_unfinished_thread,
            "supportive_presence": self._build_proactive_supportive_presence,
            "light_plan_reminder": self._build_proactive_plan_reminder,
            "proactive_followup": self._build_proactive_followup,
            "relationship_maintain": self._build_proactive_gentle_check_in,
            "digest_opener": self._build_proactive_plan_reminder,
            # T6: inner_impulse goal builders
            "open_chat": self._build_proactive_open_chat,
            "share_with_friend": self._build_proactive_share_with_friend,
            "express_concern": self._build_proactive_express_concern,
        }
        builder = builder_map.get(plan.primary_goal)
        if builder is not None:
            return builder(plan, ctx)
        return self._build_proactive_generic(plan, ctx)

    def _build_proactive_gentle_check_in(self, plan: ActionPlan, ctx: SelectContext) -> ResponsePlan:
        if ctx.relationship_stage in ("stranger", "acquaintance"):
            simple = ["在的。有需要就说。", "嗯，我在。"]
            text, idx = self._pick(simple, ctx.turn_id)
            return ResponsePlan(
                kind="template", template_id="GENTLE_CHECK_IN", template_text=text,
                metadata={"selection_reason": "proactive:gentle_check_in:simple", "pick_idx": idx},
            )
        text, idx = self._pick(GENTLE_CHECK_IN_TEMPLATES, ctx.turn_id)
        return ResponsePlan(
            kind="template", template_id="GENTLE_CHECK_IN", template_text=text,
            metadata={"selection_reason": "proactive:gentle_check_in:full", "pick_idx": idx},
        )

    def _build_proactive_world_observation(self, plan: ActionPlan, ctx: SelectContext) -> ResponsePlan:
        wctx = ctx.world_context or {}
        detail = "有些变化"
        wc_time = wctx.get("time", {})
        wc_npcs = wctx.get("npcs", [])

        weather = wc_time.get("weather", "") if isinstance(wc_time, dict) else ""
        if weather:
            detail = f"天气变成了{weather}"
        time_of_day = wc_time.get("time_of_day", "") if isinstance(wc_time, dict) else ""
        if time_of_day:
            detail = f"现在是{time_of_day}"
        if wc_npcs:
            nearby = [n for n in wc_npcs if isinstance(n, dict) and n.get("is_nearby")]
            if nearby:
                templates = WORLD_OBSERVATION_TEMPLATES.get(
                    "npc_activity_change", WORLD_OBSERVATION_TEMPLATES["default"]
                )
                text, idx = self._pick(templates, ctx.turn_id)
                npc_name = nearby[0].get("name", "某人")
                return ResponsePlan(
                    kind="template", template_id="WORLD_OBSERVATION", template_text=text,
                    format_args={"npc_name": npc_name, "detail": "附近"},
                    metadata={"selection_reason": "proactive:world_observation:npc", "pick_idx": idx},
                )

        event_type = "default"
        if plan.reasoning_summary and "type=" in plan.reasoning_summary:
            for known_type in WORLD_OBSERVATION_TEMPLATES:
                if known_type in plan.reasoning_summary:
                    event_type = known_type
                    break

        templates = WORLD_OBSERVATION_TEMPLATES.get(event_type, WORLD_OBSERVATION_TEMPLATES["default"])
        text, idx = self._pick(templates, ctx.turn_id)
        return ResponsePlan(
            kind="template", template_id="WORLD_OBSERVATION", template_text=text,
            format_args={"detail": detail},
            metadata={"selection_reason": f"proactive:world_observation:{event_type}", "pick_idx": idx},
        )

    def _build_proactive_reconnect(self, plan: ActionPlan, ctx: SelectContext) -> ResponsePlan:
        text, idx = self._pick(RECONNECT_TEMPLATES, ctx.turn_id)
        return ResponsePlan(
            kind="template", template_id="RECONNECT", template_text=text,
            metadata={"selection_reason": "proactive:reconnect", "pick_idx": idx},
        )

    def _build_proactive_unfinished_thread(self, plan: ActionPlan, ctx: SelectContext) -> ResponsePlan:
        topic = "那件事"
        if ctx.event_context:
            active_events = getattr(ctx.event_context, "active_events", [])
            if active_events:
                top = active_events[0]
                if isinstance(top, dict):
                    topic = top.get("display_title", "") or top.get("title", "")[:15] or topic
        text, idx = self._pick(UNFINISHED_THREAD_TEMPLATES, ctx.turn_id)
        return ResponsePlan(
            kind="template", template_id="UNFINISHED_THREAD", template_text=text,
            format_args={"topic": topic},
            metadata={"selection_reason": "proactive:unfinished_thread", "pick_idx": idx},
        )

    def _build_proactive_supportive_presence(self, plan: ActionPlan, ctx: SelectContext) -> ResponsePlan:
        text, idx = self._pick(SUPPORTIVE_PRESENCE_TEMPLATES, ctx.turn_id)
        return ResponsePlan(
            kind="template", template_id="SUPPORTIVE_PRESENCE", template_text=text,
            metadata={"selection_reason": "proactive:supportive_presence", "pick_idx": idx},
        )

    # ─── T6: inner_impulse goal builders ─────────────────────

    def _build_proactive_open_chat(self, plan: ActionPlan, ctx: SelectContext) -> ResponsePlan:
        text, idx = self._pick(OPEN_CHAT_TEMPLATES, ctx.turn_id)
        return ResponsePlan(
            kind="template", template_id="INNER_IMPULSE_OPEN_CHAT", template_text=text,
            metadata={"selection_reason": "proactive:inner_impulse:open_chat", "pick_idx": idx},
        )

    def _build_proactive_share_with_friend(self, plan: ActionPlan, ctx: SelectContext) -> ResponsePlan:
        topic = self._inner_impulse_topic(plan, default="心里那个事")
        text, idx = self._pick(SHARE_WITH_FRIEND_TEMPLATES, ctx.turn_id)
        return ResponsePlan(
            kind="template", template_id="INNER_IMPULSE_SHARE", template_text=text,
            format_args={"topic": topic},
            metadata={"selection_reason": "proactive:inner_impulse:share", "pick_idx": idx},
        )

    def _build_proactive_express_concern(self, plan: ActionPlan, ctx: SelectContext) -> ResponsePlan:
        topic = self._inner_impulse_topic(plan, default="那件事")
        text, idx = self._pick(EXPRESS_CONCERN_TEMPLATES, ctx.turn_id)
        return ResponsePlan(
            kind="template", template_id="INNER_IMPULSE_CONCERN", template_text=text,
            format_args={"topic": topic},
            metadata={"selection_reason": "proactive:inner_impulse:concern", "pick_idx": idx},
        )

    @staticmethod
    def _inner_impulse_topic(plan: ActionPlan, default: str) -> str:
        """从 plan.reasoning_summary / plan tags 中尝试提取 attention summary。

        plan 由上层从 candidate.payload['attention'][0]['summary'] 注入到
        reasoning_summary 或 tags；找不到则用 default 兜底。
        """
        summary = (plan.reasoning_summary or "")[:30]
        if summary:
            return summary
        return default

    def _build_proactive_plan_reminder(self, plan: ActionPlan, ctx: SelectContext) -> ResponsePlan:
        if ctx.digest_context and ctx.digest_context.get("recommended_openers"):
            openers = ctx.digest_context["recommended_openers"]
            if openers:
                return ResponsePlan(
                    kind="template", template_id="DIGEST_OPENER",
                    final_text=openers[0],
                    metadata={"selection_reason": "proactive:plan_reminder:digest"},
                )
        text, idx = self._pick(LIGHT_PLAN_REMINDER_TEMPLATES, ctx.turn_id)
        return ResponsePlan(
            kind="template", template_id="LIGHT_PLAN_REMINDER", template_text=text,
            format_args={"topic": "之前说的"},
            metadata={"selection_reason": "proactive:plan_reminder:light", "pick_idx": idx},
        )

    def _build_proactive_followup(self, plan: ActionPlan, ctx: SelectContext) -> ResponsePlan:
        if plan.expression_style == "gentle":
            text, idx = self._pick(SUPPORTIVE_PRESENCE_TEMPLATES, ctx.turn_id)
            return ResponsePlan(
                kind="template", template_id="SUPPORTIVE_PRESENCE", template_text=text,
                metadata={"selection_reason": "proactive:followup:gentle_supportive", "pick_idx": idx},
            )
        topic = "刚才说的"
        if ctx.event_context:
            active_events = getattr(ctx.event_context, "active_events", [])
            if active_events:
                top = active_events[0]
                if isinstance(top, dict):
                    topic = top.get("display_title", "") or top.get("title", "")[:15] or topic
        text, idx = self._pick(UNFINISHED_THREAD_TEMPLATES, ctx.turn_id)
        return ResponsePlan(
            kind="template", template_id="UNFINISHED_THREAD", template_text=text,
            format_args={"topic": topic},
            metadata={"selection_reason": "proactive:followup:unfinished", "pick_idx": idx},
        )

    def _build_proactive_generic(self, plan: ActionPlan, ctx: SelectContext) -> ResponsePlan:
        if plan.expression_style == "gentle":
            return ResponsePlan(
                kind="template", template_id="PROACTIVE_GENERIC",
                final_text="我在。",
                metadata={"selection_reason": "proactive:generic:gentle"},
            )
        return ResponsePlan(
            kind="template", template_id="PROACTIVE_GENERIC",
            final_text="...",
            metadata={"selection_reason": "proactive:generic:default"},
        )

    # =================== 共享 helpers ===================
    @staticmethod
    def _pick(templates: list, turn_id: int) -> Tuple[str, int]:
        """返 (chosen_template, idx)；turn_id 决定 idx 以便测试可重现。"""
        if not templates:
            return "", -1
        idx = turn_id % len(templates) if turn_id else 0
        return templates[idx], idx
