from typing import Dict, Any

from linger_core.core.state.runtime_state import RuntimeState
from linger_core.core.observability.trace_store import TraceStore
from linger_core.runtime.orchestrator.runtime_orchestrator import RuntimeOrchestrator
from linger_core.runtime.orchestrator.runtime_envelope import create_user_envelope


class ForegroundLoop:
    def __init__(
        self,
        state: RuntimeState,
        orchestrator: RuntimeOrchestrator,
        trace_store: TraceStore,
    ):
        self._state = state
        self._orchestrator = orchestrator
        self._trace_store = trace_store

    def handle_user_input(self, user_message: str) -> Dict[str, Any]:
        envelope = create_user_envelope(
            user_message=user_message,
            real_now=self._state.clock.real_now_time(),
            world_now=self._state.clock.world_now_time(),
        )

        result = self._orchestrator.handle_envelope(envelope, self._state)

        response = {
            "status": "ok",
            "message": result.response_message,
            "action_plan": result.action_plan.to_full_dict(),
            "clock_snapshot": self._state.clock.snapshot(),
            "session_id": self._state.session.session_id,  # noqa: state-penetration (foreground response wrapper; session_id is stable scalar, post-handle read)
            "envelope_id": result.envelope_id,
            "should_emit": result.should_emit,
            "execution_summary": result.execution_summary,
        }

        return response
