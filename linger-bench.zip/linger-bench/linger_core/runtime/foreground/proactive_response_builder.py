"""ProactiveResponseBuilder：主动消息（background tick / proactive trigger）的回复生成入口。

决"LLM vs template"二选一，与 ResponseBuilder 同形态。
返回 ResponsePlan。
"""
from dataclasses import replace
from typing import Any, Dict, Optional

from linger_core.runtime.foreground.prompt_context_summarizer import summarize_world
from linger_core.runtime.foreground.response_plan import ResponsePlan, SelectContext
from linger_core.runtime.foreground.template_rule_engine import TemplateRuleEngine
from linger_core.supervisor.action_plan import ActionPlan


class ProactiveResponseBuilder:
    def __init__(
        self,
        engine: TemplateRuleEngine,
        llm_provider=None,
        prompt_registry=None,
        llm_enabled: bool = False,
        llm_router=None,
    ) -> None:
        self._engine = engine
        self._llm_provider = llm_provider
        self._prompt_registry = prompt_registry
        self._llm_enabled = llm_enabled
        self._llm_router = llm_router

    def build(
        self,
        plan: ActionPlan,
        event_context: Any = None,
        profile_context: Optional[Dict[str, Any]] = None,
        digest_context: Optional[Dict[str, Any]] = None,
        world_context: Optional[Dict[str, Any]] = None,
        relationship_stage: str = "stranger",
        turn_context: Optional[Dict[str, Any]] = None,
        inner_life_block: str = "",
    ) -> ResponsePlan:
        if not plan.can_speak:
            return ResponsePlan(
                kind="template",
                final_text="",
                metadata={"selection_reason": "cannot_speak"},
            )

        turn_id = (turn_context or {}).get("turn_id", 0)
        ctx = SelectContext(
            kind="proactive",
            turn_id=turn_id,
            event_context=event_context,
            profile_context=profile_context,
            digest_context=digest_context,
            world_context=world_context,
            relationship_stage=relationship_stage,
            inner_life_block=inner_life_block,
        )

        if self._llm_enabled and self._llm_provider and self._prompt_registry:
            return self._build_with_llm(plan, ctx)

        return self._engine.select(plan, ctx)

    def _build_with_llm(self, plan: ActionPlan, ctx: SelectContext) -> ResponsePlan:
        try:
            from linger_core.llm.base import LLMMessage, LLMRequest

            template = self._prompt_registry.get("proactive_response")
            system_text = template.system.format(
                persona_name="沈鹿溪",
                persona_alias="鹿溪",
            )

            recent_context_summary = plan.reasoning_summary[:200] if plan.reasoning_summary else ""
            event_summary = ""
            if ctx.event_context:
                active = getattr(ctx.event_context, "active_events", [])
                if active and isinstance(active, list) and len(active) > 0:
                    top = active[0] if isinstance(active[0], dict) else {}
                    event_summary = top.get("display_title", "") or top.get("title", "") or ""
            world_summary = summarize_world(ctx.world_context)

            profile_summary = ""
            if ctx.profile_context and isinstance(ctx.profile_context, dict):
                name = ctx.profile_context.get("name", "")
                if name:
                    profile_summary = f"用户: {name}"

            digest_summary = ""
            if ctx.digest_context and isinstance(ctx.digest_context, dict):
                openers = ctx.digest_context.get("recommended_openers", [])
                if openers:
                    digest_summary = openers[0] if isinstance(openers, list) else ""

            request = LLMRequest(
                messages=[
                    LLMMessage(role="system", content=system_text),
                    LLMMessage(role="developer", content=template.developer),
                    LLMMessage(role="user", content=template.user.format(
                        action_goal=plan.primary_goal,
                        # T7: inner_life_block 占位；T8 接 view → 真实注入
                        inner_life_block=getattr(ctx, "inner_life_block", "") or "",
                        recent_context_summary=recent_context_summary,
                        relationship_stage=ctx.relationship_stage,
                        event_context_summary=event_summary,
                        world_context_summary=world_summary,
                        profile_context_summary=profile_summary,
                        digest_context_summary=digest_summary,
                    )),
                ],
                metadata={
                    "proactive_goal": plan.primary_goal,
                    **template.metadata_dict(),
                },
            )

            response = self._call_llm(request)

            if not response.success or not response.content.strip():
                fallback_plan = self._engine.select(plan, ctx)
                err = getattr(response, "error", "") or "empty content"
                return replace(
                    fallback_plan,
                    metadata={**fallback_plan.metadata, "fallback_from": "llm", "llm_error": str(err)[:200]},
                )

            return ResponsePlan(
                kind="llm",
                final_text=response.content.strip(),
                metadata={"prompt_id": "proactive_response"},
            )

        except Exception as exc:
            fallback_plan = self._engine.select(plan, ctx)
            return replace(
                fallback_plan,
                metadata={**fallback_plan.metadata, "fallback_from": "llm", "llm_error": f"{type(exc).__name__}: {str(exc)[:200]}"},
            )

    def _call_llm(self, request):
        if self._llm_router is not None:
            from linger_core.llm.task_type import LLMTaskType
            return self._llm_router.generate(LLMTaskType.PROACTIVE_RESPONSE, request)

        if self._llm_provider is not None:
            return self._llm_provider.generate(request)

        from linger_core.llm.base import LLMResponse
        return LLMResponse(content="", success=False, error="no llm provider or router")
