"""ResponsePlan：ResponseBuilder / ProactiveResponseBuilder 的中间产物。

LLM 路径：kind="llm"，final_text 已由模型生成；
Template 路径：kind="template"，template_text 是模板原文，format_args 是 .format() 的 kwargs，
               final_text=None 待 render() 时计算。

Phase 3 升级 ModalResponse 时，本类是字段超集扩展（加 audio: Optional[bytes] 等），
render() 改返 dict。
"""
from dataclasses import dataclass, field
from typing import Any, Dict, Literal, Optional


@dataclass(frozen=True)
class ResponsePlan:
    kind: Literal["llm", "template"]
    template_id: Optional[str] = None              # e.g., "EVENT_FOLLOWUP" / "WORLD_NIGHT" / None (LLM)
    template_text: Optional[str] = None            # 选中的模板字符串（含 {placeholder}）
    format_args: Dict[str, Any] = field(default_factory=dict)
    final_text: Optional[str] = None               # LLM 路径 = 模型输出；template 路径 = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    # metadata 字段建议：
    #   selection_reason: str ("event_aware:unresolved" / "speak_mode:comfort_only" / "goal:gentle_check_in")
    #   prompt_hash: str (LLM 路径)
    #   latency_ms: float (LLM 路径)
    #   fallback_from: Optional[str] ("llm" 表示从 LLM fallback 到 template)

    def render(self) -> str:
        if self.final_text is not None:
            return self.final_text
        if self.template_text is None:
            return ""
        return self.template_text.format(**self.format_args)


@dataclass(frozen=True)
class SelectContext:
    """TemplateRuleEngine.select 的入参 bundle。"""

    kind: Literal["user_input", "proactive"]
    turn_id: int = 0
    user_message: str = ""                         # only user_input 用
    recent_context: Any = None
    event_context: Any = None
    profile_context: Optional[Dict[str, Any]] = None
    digest_context: Optional[Dict[str, Any]] = None
    world_context: Optional[Dict[str, Any]] = None
    tool_results: Optional[list] = None
    relationship_stage: str = "stranger"           # only proactive 用
    inner_life_block: str = ""                     # T7/T8: prompt 注入区块
    ltm_context: str = ""                          # E5 B+: 用户事实记忆召回（flag OFF 时为空）
