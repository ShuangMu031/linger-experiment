"""Prompt context summarizers — pure functions used by ResponseBuilder /
ProactiveResponseBuilder LLM branches.

每个函数把一个 context 对象/dict 压成 LLM prompt 用的短字符串。
None / 空 / 非法输入 → ""。
"""
from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.core.emotion.emotion_dimensions import (
    NEUTRAL_VALUE,
    EmotionDimension,
    EmotionVector,
)
from linger_core.world.world_labels import time_zh, weather_zh, mood_zh

_WORLD_RECENT_BUDGET_CHARS = 200  # B3 预算上限:注入世界事件的硬字数天花板


def summarize_event(event_context: Any) -> str:
    if not event_context:
        return ""
    parts: List[str] = []
    active_count = getattr(event_context, "active_event_count", 0)
    if active_count > 0:
        parts.append(f"活跃事件: {active_count}")
    if getattr(event_context, "has_unresolved", False):
        parts.append("有未解决事件")
    title = getattr(event_context, "top_event_title", "") or ""
    if title:
        parts.append(f"最近事件: {title[:40]}")
    return "; ".join(parts)


def summarize_world(world_context: Optional[Dict[str, Any]]) -> str:
    if not world_context or not isinstance(world_context, dict):
        return ""
    parts: List[str] = []
    wc_time = world_context.get("time", {})
    if isinstance(wc_time, dict):
        tod = wc_time.get("time_of_day", "")
        weather = wc_time.get("weather", "")
        if tod:
            parts.append(f"时段: {time_zh(tod)}")
        if weather:
            parts.append(f"天气: {weather_zh(weather)}")
    wc_ambient = world_context.get("ambient", {})
    if isinstance(wc_ambient, dict):
        mood = wc_ambient.get("mood", "")
        if mood:
            parts.append(f"氛围: {mood_zh(mood)}")
    wc_npcs = world_context.get("npcs", [])
    if wc_npcs and isinstance(wc_npcs, list):
        names = [n.get("name", "") for n in wc_npcs if isinstance(n, dict) and n.get("name")]
        if names:
            parts.append(f"附近: {','.join(names[:3])}")
    recent = world_context.get("recent_events", "")
    if recent and isinstance(recent, str):
        recent_text = recent[:_WORLD_RECENT_BUDGET_CHARS]
        if len(recent) > _WORLD_RECENT_BUDGET_CHARS:
            recent_text += "…"
        parts.append(f"最近发生: {recent_text}")
    if not parts:
        return ""
    body = "; ".join(parts)
    return f"【你此刻的世界|背景,可自然提及,但不要编造这里没有的细节】{body}"


def summarize_profile(profile_context: Optional[Dict[str, Any]]) -> str:
    if not profile_context or not isinstance(profile_context, dict):
        return ""
    parts: List[str] = []
    stage = profile_context.get("relationship_stage", "")
    if stage:
        parts.append(f"关系阶段: {stage}")
    style = profile_context.get("preferred_style", "")
    if style and style != "balanced":
        parts.append(f"偏好风格: {style}")
    dominant = profile_context.get("dominant_emotion", "")
    if dominant and dominant != "neutral":
        parts.append(f"主导情绪: {dominant}")
    return "; ".join(parts)


def summarize_tool_results(tool_results: Optional[List[Any]]) -> str:
    if not tool_results:
        return ""
    parts: List[str] = []
    for tr in tool_results:
        if hasattr(tr, "to_dict"):
            d = tr.to_dict()
        elif isinstance(tr, dict):
            d = tr
        else:
            continue
        name = d.get("tool_name", "unknown")
        success = d.get("success", False)
        result = d.get("result")
        if success and result is not None:
            if isinstance(result, dict):
                summary = "; ".join(f"{k}={v}" for k, v in list(result.items())[:5])
                parts.append(f"[{name}] {summary}")
            else:
                parts.append(f"[{name}] {str(result)[:100]}")
        elif not success:
            err = d.get("error", "unknown error")
            parts.append(f"[{name}] 失败: {err}")
    return "\n".join(parts)


def summarize_recent(recent_context: Any, n: int = 3) -> str:
    if not recent_context or not hasattr(recent_context, "recent_user_messages"):
        return ""
    msgs = recent_context.recent_user_messages
    if not msgs:
        return ""
    return " | ".join(str(m)[:60] for m in msgs[-n:])


# ─── T7: InnerLife prompt 注入区块（spec §6.2 §6.3）──────────

_INNER_LIFE_STALE_THRESHOLD_HOURS: float = 24.0


def _format_emotion_line(vec: EmotionVector) -> tuple[str, str]:
    """渲染 8 维分数为两行（每行 4 维）。"""
    d = vec.to_dict()
    line1 = (f"joy={d['joy']}  sadness={d['sadness']}  "
             f"anger={d['anger']}  fear={d['fear']}")
    line2 = (f"trust={d['trust']}  disgust={d['disgust']}  "
             f"surprise={d['surprise']}  anticipation={d['anticipation']}")
    return line1, line2


def _is_baseline_neutral(vec: EmotionVector) -> bool:
    return all(v == NEUTRAL_VALUE for v in vec.to_dict().values())


def _format_stale_label(elapsed: float) -> str:
    """把秒数渲染成「N 分钟前 / N 小时前」自然语言。"""
    if elapsed < 60:
        return "刚刚"
    if elapsed < 3600:
        return f"{int(elapsed // 60)} 分钟前"
    return f"{int(elapsed // 3600)} 小时前"


def summarize_inner_life(
    view: Any,
    instant: Optional[EmotionVector] = None,
    *,
    proactive_cached_instant: Optional[EmotionVector] = None,
    last_emotion_insight_at: Optional[datetime] = None,
    real_now: Optional[datetime] = None,
) -> str:
    """渲染 InnerLife prompt 注入区块。

    路径：
    - user 路径：传 `instant`（本轮 EmotionInsight8d 输出）
    - proactive 路径：`instant=None` + 可选 `proactive_cached_instant` + `last_emotion_insight_at`
      用于标记"上次对话时"；缓存 > 24h 或缺失则省略瞬时段。

    返空串条件（完全冷启动）：
    - mood_baseline 全 = NEUTRAL_VALUE (30)
    - attention_focus 为空
    - 没有可用的 instant（user 路径 instant=None 或 proactive 已过期/冷启动）
    """
    if view is None:
        return ""

    baseline: EmotionVector = view.baseline_emotion()
    attention_list = view.attention_focus()
    phase = view.circadian_phase()

    has_baseline_signal = not _is_baseline_neutral(baseline)
    has_attention = bool(attention_list)

    # 决定瞬时段策略
    show_user_instant = instant is not None
    show_proactive_stale = False
    stale_label = ""

    if not show_user_instant:
        if (proactive_cached_instant is not None
                and last_emotion_insight_at is not None
                and real_now is not None):
            elapsed = (real_now - last_emotion_insight_at).total_seconds()
            if 0 <= elapsed <= _INNER_LIFE_STALE_THRESHOLD_HOURS * 3600:
                show_proactive_stale = True
                stale_label = _format_stale_label(elapsed)

    has_instant_signal = show_user_instant or show_proactive_stale

    # 完全冷启动：无任何信号 → 空串
    if not (has_baseline_signal or has_attention or has_instant_signal):
        return ""

    parts: List[str] = ["【你此刻的内在状态】", ""]

    # 基线
    parts.append("最近基线情绪（0-100）：")
    b1, b2 = _format_emotion_line(baseline)
    parts.append(b1)
    parts.append(b2)
    parts.append("")

    # 瞬时段
    if show_user_instant:
        parts.append("对对方刚才这句话的瞬时反应（0-100）：")
        i1, i2 = _format_emotion_line(instant)
        parts.append(i1)
        parts.append(i2)
        parts.append("")
    elif show_proactive_stale:
        parts.append(f"对你上次和对方对话时的瞬时反应（0-100，{stale_label}）：")
        i1, i2 = _format_emotion_line(proactive_cached_instant)
        parts.append(i1)
        parts.append(i2)
        parts.append("（这是上次的反应，可能已经淡了）")
        parts.append("")

    # 作息 + attention
    parts.append(f"现在: {phase.value}")
    if has_attention:
        top = attention_list[0]
        parts.append(f"你最近一直惦记的事: {top.get('summary', '')}")
    parts.append("")

    # 元规则
    parts.append("【表达约束（最重要）】")
    parts.append(
        "- 绝对不要在回复里说出任何分数（"
        "比如\"我 55 分悲伤\"）或维度名（"
        "比如\"我的 sadness 比较高\"）——说出来就出戏。"
    )
    parts.append(
        "- 让分数高的维度自然渗透你的语气、用词、节奏；"
        "分数低的维度（<20）忽略即可。"
    )
    parts.append(
        "- 基线情绪决定你\"整体的状态\"，"
        "瞬时情绪决定你\"对这一句的本能反应\"。"
    )

    return "\n".join(parts)
