"""ResponseBuilder：用户输入路径的回复生成入口。

决"LLM vs template"二选一：
- LLM 启用 → _build_with_llm（调 prompt_context_summarizer + LLMProvider）
- LLM 失败 / 关闭 → engine.select(plan, ctx)（template 路径）

返回 ResponsePlan，由 caller 调 .render() 取 str。
"""
from dataclasses import replace
from typing import Any, Dict, List, Optional

from linger_core.runtime.foreground.prompt_context_summarizer import (
    summarize_event,
    summarize_profile,
    summarize_recent,
    summarize_tool_results,
    summarize_world,
)
from linger_core.runtime.foreground.response_plan import ResponsePlan, SelectContext
from linger_core.runtime.foreground.template_rule_engine import TemplateRuleEngine
from linger_core.supervisor.action_plan import ActionPlan


class ResponseBuilder:
    def __init__(
        self,
        engine: TemplateRuleEngine,
        llm_provider=None,
        prompt_registry=None,
        llm_enabled: bool = False,
        llm_router=None,
        trace_store=None,
        fallback_to_template: bool = True,
    ) -> None:
        self._engine = engine
        self._llm_provider = llm_provider
        self._prompt_registry = prompt_registry
        self._llm_enabled = llm_enabled
        self._llm_router = llm_router
        self._trace_store = trace_store
        self._fallback_to_template = fallback_to_template

    def build(
        self,
        user_message: str,
        plan: ActionPlan,
        turn_context: Optional[Dict[str, Any]] = None,
        recent_context: Any = None,
        event_context: Any = None,
        profile_context: Optional[Dict[str, Any]] = None,
        digest_context: Optional[Dict[str, Any]] = None,
        world_context: Optional[Dict[str, Any]] = None,
        tool_results: Optional[List[Any]] = None,
        inner_life_block: str = "",
        ltm_context: str = "",
    ) -> ResponsePlan:
        if not plan.can_speak:
            return ResponsePlan(
                kind="template",
                final_text="",
                metadata={"selection_reason": "cannot_speak"},
            )

        turn_id = (turn_context or {}).get("turn_id", 0)
        ctx = SelectContext(
            kind="user_input",
            turn_id=turn_id,
            user_message=user_message,
            recent_context=recent_context,
            event_context=event_context,
            profile_context=profile_context,
            digest_context=digest_context,
            world_context=world_context,
            tool_results=tool_results,
            inner_life_block=inner_life_block,
            ltm_context=ltm_context,
        )

        if self._llm_enabled and self._llm_provider and self._prompt_registry:
            return self._build_with_llm(plan, ctx)

        return self._engine.select(plan, ctx)

    def _build_with_llm(self, plan: ActionPlan, ctx: SelectContext) -> ResponsePlan:
        try:
            from linger_core.llm.base import LLMMessage, LLMRequest
            from linger_core.prompts.prompt_context import PromptContext

            recent_summary = summarize_recent(ctx.recent_context, n=3)
            event_summary = summarize_event(ctx.event_context)
            world_summary = summarize_world(ctx.world_context)
            profile_summary = summarize_profile(ctx.profile_context)
            tool_results_summary = summarize_tool_results(ctx.tool_results)
            _ltm = getattr(ctx, "ltm_context", "") or ""
            ltm_block = f"\n你记得对方的事: {_ltm}" if _ltm else ""

            prompt_ctx = PromptContext(
                user_text=ctx.user_message,
                envelope_source="USER_INPUT",
                action_goal=plan.primary_goal,
                response_strategy=plan.response_strategy,
                recent_context_summary=recent_summary,
                runtime_flags={
                    "speak_mode": plan.speak_mode,
                    "should_comfort": plan.should_comfort,
                    "should_ask_question": plan.should_ask_question,
                },
            )

            template = self._prompt_registry.get("response_builder")
            system_text = template.system.format(
                persona_name=prompt_ctx.persona_name,
                persona_alias="鹿溪",
                persona_shell="密室逃脱NPC / 兼职配音演员",
                voice_texture="清亮但略带沙哑",
            )

            request = LLMRequest(
                messages=[
                    LLMMessage(role="system", content=system_text),
                    LLMMessage(role="developer", content=template.developer),
                    LLMMessage(role="user", content=template.user.format(
                        user_text=prompt_ctx.user_text,
                        # T7: inner_life_block 占位；T8 接 view → 真实注入
                        inner_life_block=getattr(ctx, "inner_life_block", "") or "",
                        action_goal=plan.primary_goal,
                        speak_mode=plan.speak_mode,
                        should_comfort=str(plan.should_comfort),
                        should_ask_question=str(plan.should_ask_question),
                        recent_context_summary=recent_summary,
                        event_context_summary=event_summary,
                        world_context_summary=world_summary,
                        profile_context_summary=profile_summary,
                        user_fact_block=ltm_block,
                        tool_results_summary=tool_results_summary,
                    )),
                ],
                metadata={
                    "action_goal": plan.primary_goal,
                    "speak_mode": plan.speak_mode,
                    **template.metadata_dict(),
                },
            )

            response = self._call_llm(request)

            if not response.success or not response.content.strip():
                err = getattr(response, "error", "") or "empty content"
                self._record_failure("call_llm_returned_failure", str(err), "LLMResponseFailure")
                if not self._fallback_to_template:
                    raise RuntimeError(
                        f"response_generation LLM failed: {err}. "
                        f"Set fallback_to_template=True to allow template fallback."
                    )
                fallback_plan = self._engine.select(plan, ctx)
                return replace(
                    fallback_plan,
                    metadata={**fallback_plan.metadata, "fallback_from": "llm", "llm_error": str(err)[:200]},
                )

            return ResponsePlan(
                kind="llm",
                final_text=response.content.strip(),
                metadata={"prompt_id": "response_builder"},
            )

        except Exception as exc:
            if isinstance(exc, RuntimeError) and "response_generation LLM failed" in str(exc):
                raise
            self._record_failure("build_with_llm_exception", str(exc), type(exc).__name__)
            if not self._fallback_to_template:
                raise
            fallback_plan = self._engine.select(plan, ctx)
            return replace(
                fallback_plan,
                metadata={**fallback_plan.metadata, "fallback_from": "llm", "llm_error": f"{type(exc).__name__}: {str(exc)[:200]}"},
            )

    def _record_failure(self, where: str, error: str, error_type: str) -> None:
        if self._trace_store is None:
            return
        try:
            self._trace_store.add_step({
                "step": "response_llm_failed",
                "where": where,
                "error": error[:300],
                "error_type": error_type,
                "fallback_to_template": self._fallback_to_template,
            })
        except Exception:
            pass

    def _call_llm(self, request):
        if self._llm_router is not None:
            from linger_core.llm.task_type import LLMTaskType
            return self._llm_router.generate(LLMTaskType.RESPONSE_GENERATION, request)

        if self._llm_provider is not None:
            return self._llm_provider.generate(request)

        from linger_core.llm.base import LLMResponse
        return LLMResponse(content="", success=False, error="no llm provider or router")
