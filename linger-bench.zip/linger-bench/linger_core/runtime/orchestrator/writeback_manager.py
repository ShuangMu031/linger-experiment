from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from linger_core.core.state.runtime_state import RuntimeState
from linger_core.supervisor.action_plan import ActionPlan
from linger_core.runtime.orchestrator.runtime_envelope import RuntimeEnvelope, EnvelopeSourceType
from linger_core.memory.event_extractor import EventExtractor
from linger_core.memory.long_term_extractor import LongTermExtractor
from linger_core.memory.relationship_tracker import RelationshipTracker
from linger_core.persistence.repositories.short_term_memory_repository import ShortTermMemoryRepository
from linger_core.persistence.repositories.event_memory_repository import EventMemoryRepository
from linger_core.persistence.repositories.long_term_memory_repository import LongTermMemoryRepository
from linger_core.persistence.repositories.digest_repository import DigestRepository
from linger_core.persistence.repositories.profile_repository import ProfileRepository
from linger_core.persistence.repositories.world_state_repository import WorldStateRepository
from linger_core.persistence.repositories.npc_repository import NpcRepository
from linger_core.persistence.repositories.world_event_repository import WorldEventRepository


@dataclass
class WritebackSummary:
    user_memory_written: bool = False
    assistant_memory_written: bool = False
    events_extracted: int = 0
    events_updated: int = 0
    ltm_updated: bool = False
    profile_updated: bool = False
    relationship_updated: bool = False
    state_impacts_applied: int = 0
    repositories_saved: List[str] = field(default_factory=list)
    persist_errors: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "user_memory_written": self.user_memory_written,
            "assistant_memory_written": self.assistant_memory_written,
            "events_extracted": self.events_extracted,
            "events_updated": self.events_updated,
            "ltm_updated": self.ltm_updated,
            "profile_updated": self.profile_updated,
            "relationship_updated": self.relationship_updated,
            "state_impacts_applied": self.state_impacts_applied,
            "repositories_saved": self.repositories_saved,
            "persist_errors": self.persist_errors,
        }


class WritebackManager:
    def __init__(
        self,
        llm_router=None,
        llm_provider=None,
        prompt_registry=None,
        memory_ttl=None,
        enable_user_fact_memory: bool = False,
    ) -> None:
        self._llm_router = llm_router
        self._enable_user_fact_memory = enable_user_fact_memory
        # T4: EventExtractor 接 cheap LLM 用于 anchor_date 抽取
        self._event_extractor = EventExtractor(
            llm_router=llm_router,
            llm_provider=llm_provider,
            prompt_registry=prompt_registry,
            memory_ttl=memory_ttl,
        )
        self._memory_repo = ShortTermMemoryRepository()
        self._event_repo = EventMemoryRepository()
        self._ltm_repo = LongTermMemoryRepository()
        self._digest_repo = DigestRepository()
        self._profile_repo = ProfileRepository()
        self._world_state_repo = WorldStateRepository()
        self._npc_repo = NpcRepository()
        self._world_event_repo = WorldEventRepository()

    def commit(
        self,
        state: RuntimeState,
        envelope: RuntimeEnvelope,
        plan: ActionPlan,
        response_message: str,
    ) -> WritebackSummary:
        summary = WritebackSummary()

        self._apply_state_impacts(state, plan, summary)

        if envelope.source_type == EnvelopeSourceType.USER_INPUT:
            self._write_user_memory(state, envelope, summary)
            if plan.can_speak and response_message:
                self._write_assistant_memory(state, plan, response_message, summary)
        else:
            if plan.can_speak and response_message:
                self._write_proactive_memory(state, plan, response_message, envelope, summary)

        self._extract_events(state, envelope, summary)
        self._extract_user_facts(state, envelope)

        self._update_derived_state(state, envelope, summary)

        self._persist(state, envelope, summary)

        return summary

    def _apply_state_impacts(
        self,
        state: RuntimeState,
        plan: ActionPlan,
        summary: WritebackSummary,
    ) -> None:
        for write in plan.state_writes:
            if "emotion" in write and "intensity_delta" in write:
                from linger_core.shared.enums import EmotionType

                try:
                    new_emotion = EmotionType(write["emotion"])
                    state.emotion_state.set_emotion(
                        new_emotion,
                        state.emotion_state.intensity + write["intensity_delta"],
                        real_now=state.clock.real_now_time(),
                    )
                    summary.state_impacts_applied += 1
                except (ValueError, KeyError):
                    pass

    def _write_user_memory(
        self,
        state: RuntimeState,
        envelope: RuntimeEnvelope,
        summary: WritebackSummary,
    ) -> None:
        state.short_term_memory.write(
            turn_id=state.clock.logical.turn_id,
            speaker="user",
            message=envelope.text,
            real_now=state.clock.real_now_time(),
            world_now=state.clock.world_now_time(),
            emotion_snapshot={
                "emotion": state.emotion_state.current_emotion.value,
                "intensity": state.emotion_state.intensity,
            },
            tags=["user_input"],
            importance=0.5,
        )
        summary.user_memory_written = True

    def _write_assistant_memory(
        self,
        state: RuntimeState,
        plan: ActionPlan,
        response_message: str,
        summary: WritebackSummary,
    ) -> None:
        followup_id = ""
        if plan.allow_followup and plan.followup_hook:
            followups = state.plan_state.pending_followups
            if followups:
                followup_id = followups[-1].hook_id

        tags = ["assistant_output"]
        if plan.should_comfort:
            tags.append("comfort")
        if plan.should_pause:
            tags.append("pause")
        if plan.allow_followup:
            tags.append("has_followup")

        importance = 0.5
        if plan.emotion_priority in ("high", "critical"):
            importance = 0.8
        elif plan.emotion_priority == "elevated":
            importance = 0.65

        state.short_term_memory.write(
            turn_id=state.clock.logical.turn_id,
            speaker="assistant",
            message=response_message,
            real_now=state.clock.real_now_time(),
            world_now=state.clock.world_now_time(),
            emotion_snapshot={
                "emotion": state.emotion_state.current_emotion.value,
                "intensity": state.emotion_state.intensity,
            },
            action_plan_snapshot=plan.to_dict(),
            speak_mode=plan.speak_mode,
            followup_hook_id=followup_id,
            tags=tags,
            importance=importance,
        )
        summary.assistant_memory_written = True

    def _write_proactive_memory(
        self,
        state: RuntimeState,
        plan: ActionPlan,
        response_message: str,
        envelope: RuntimeEnvelope,
        summary: WritebackSummary,
    ) -> None:
        tags = ["assistant_output", "proactive"]
        if plan.should_comfort:
            tags.append("comfort")
        if plan.should_pause:
            tags.append("pause")
        if plan.allow_followup:
            tags.append("has_followup")
        tags.append(envelope.source_type.value)

        importance = 0.4
        if plan.emotion_priority in ("high", "critical"):
            importance = 0.7
        elif plan.emotion_priority == "elevated":
            importance = 0.55

        followup_id = ""
        if plan.allow_followup and plan.followup_hook:
            followups = state.plan_state.pending_followups
            if followups:
                followup_id = followups[-1].hook_id

        state.short_term_memory.write(
            turn_id=state.clock.logical.turn_id,
            speaker="assistant",
            message=response_message,
            real_now=state.clock.real_now_time(),
            world_now=state.clock.world_now_time(),
            emotion_snapshot={
                "emotion": state.emotion_state.current_emotion.value,
                "intensity": state.emotion_state.intensity,
            },
            action_plan_snapshot=plan.to_dict(),
            speak_mode=plan.speak_mode,
            followup_hook_id=followup_id,
            tags=tags,
            importance=importance,
        )
        summary.assistant_memory_written = True

    def _extract_events(
        self,
        state: RuntimeState,
        envelope: RuntimeEnvelope,
        summary: WritebackSummary,
    ) -> None:
        if envelope.source_type != EnvelopeSourceType.USER_INPUT:
            return

        user_entries = state.short_term_memory.get_latest_user(n=1)
        if not user_entries:
            return
        user_entry = user_entries[-1]

        assistant_entries = state.short_term_memory.get_latest_assistant(n=1)
        assistant_entry = assistant_entries[-1] if assistant_entries else None

        real_now = state.clock.real_now_time()
        world_now = state.clock.world_now_time()

        result = self._event_extractor.extract(
            user_entry=user_entry,
            assistant_entry=assistant_entry,
            store=state.event_memory,
            real_now=real_now,
            world_now=world_now,
            turn_id=state.clock.logical.turn_id,
        )

        if not result.skipped:
            summary.events_extracted = len(result.new_events)
            summary.events_updated = len(result.updated_events)

        state.memory_state.sync_from_event_store(state.event_memory)

        ltm_extractor = LongTermExtractor(state.long_term_memory)
        ltm_extractor.extract_from_events(
            state.event_memory, real_now=state.clock.real_now_time()
        )
        summary.ltm_updated = True

    def _extract_user_facts(
        self,
        state: RuntimeState,
        envelope: RuntimeEnvelope,
    ) -> None:
        if not self._enable_user_fact_memory:
            return
        if envelope.source_type != EnvelopeSourceType.USER_INPUT:
            return
        text = envelope.text
        if not text:
            return
        extractor = LongTermExtractor(state.long_term_memory)
        facts = extractor.extract_user_facts_rule(text)
        if not facts:
            facts = self._llm_extract_user_facts(text)
        if facts:
            extractor.persist_user_facts(facts, state.clock.real_now_time())

    def _llm_extract_user_facts(self, text: str):
        if self._llm_router is None or not text:
            return []
        from linger_core.llm.base import LLMMessage, LLMRequest
        from linger_core.llm.task_type import LLMTaskType
        prompt = (
            "用户在跟朋友聊天。抽取这句话里『关于用户本人、以后可能被朋友问起的具体信息』——"
            "名字(宠物名/人名)、地点(老家/住处)、在看的作品(剧/书/电影/喜欢的歌手)、"
            "日期(生日/纪念日)、职业、学校、专业、食物口味、爱好、常用物品品牌、家人等都算，"
            "不要因为『不够稳定』就跳过。\n"
            "要点：value 取**最具体的那个词**——例如『养了只狗叫小白』要抽出名字『小白』而不是『狗』；"
            "『下个月8号搬家』抽『8号』；『最爱吃火锅』抽『火锅』。属性名用简短中文。"
            "完全没有关于用户本人的信息才返回 []。\n"
            f"用户的话：{text}\n"
            '示例：『我家猫叫毛毛』→[{"attribute":"宠物名","value":"毛毛"}]；'
            '『我在追星际穿越』→[{"attribute":"在看的作品","value":"星际穿越"}]；'
            '『我生日是3月7号』→[{"attribute":"生日","value":"3月7号"}]。'
            "只输出 JSON 数组，可有多条。"
        )
        req = LLMRequest(
            messages=[LLMMessage(role="user", content=prompt)],
            temperature=0.0,
            max_tokens=200,
        )
        try:
            resp = self._llm_router.generate(LLMTaskType.EVENT_EXTRACTION, req)
        except Exception:  # noqa: BLE001
            return []
        if not getattr(resp, "success", False):
            return []
        return self._parse_facts_json(getattr(resp, "content", "") or "")

    @staticmethod
    def _parse_facts_json(text: str):
        import json
        import re
        m = re.search(r"\[.*\]", text, re.S)
        if not m:
            return []
        try:
            data = json.loads(m.group(0))
        except Exception:  # noqa: BLE001
            return []
        out = []
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict) and item.get("attribute") and item.get("value"):
                    out.append({
                        "attribute": str(item["attribute"]),
                        "value": str(item["value"]),
                    })
        return out

    def _update_derived_state(
        self,
        state: RuntimeState,
        envelope: RuntimeEnvelope,
        summary: WritebackSummary,
    ) -> None:
        if envelope.source_type != EnvelopeSourceType.USER_INPUT:
            return

        user_entries = state.short_term_memory.get_latest_user(n=1)
        if not user_entries:
            return

        state.relationship_tracker.update_from_interaction(
            user_message=user_entries[-1].message,
            emotion_label=state.emotion_state.current_emotion.value,
            intensity=state.emotion_state.intensity,
            real_now=state.clock.real_now_time(),
        )
        summary.relationship_updated = True

        state.profile_state.update_from_ltm_store(state.long_term_memory)
        state.profile_state.update_from_relationship(state.relationship_tracker.snapshot)

        state.profile_builder.build(
            ltm_store=state.long_term_memory,
            digests=state.digest_generator.get_all(),
            real_now=state.clock.real_now_time(),
        )
        state.profile_state.update_from_profile_snapshot(state.profile_builder.current_snapshot)
        summary.profile_updated = True

    def _persist(
        self,
        state: RuntimeState,
        envelope: RuntimeEnvelope,
        summary: WritebackSummary,
    ) -> None:
        conversation_id = state.session.conversation_id
        repos_saved: List[str] = []

        try:
            self._memory_repo.save(state.short_term_memory, conversation_id)
            repos_saved.append("short_term_memory")
        except Exception as e:
            summary.persist_errors.append(f"short_term_memory: {e}")

        try:
            self._event_repo.save(state.event_memory, conversation_id)
            repos_saved.append("event_memory")
        except Exception as e:
            summary.persist_errors.append(f"event_memory: {e}")

        if summary.ltm_updated:
            try:
                self._ltm_repo.save(state.long_term_memory, conversation_id)
                repos_saved.append("long_term_memory")
            except Exception as e:
                summary.persist_errors.append(f"long_term_memory: {e}")

        if summary.profile_updated:
            try:
                digests = state.digest_generator.get_all()
                if digests:
                    self._digest_repo.save(digests, conversation_id)
                    repos_saved.append("digests")
                snapshot = state.profile_builder.current_snapshot
                if snapshot:
                    self._profile_repo.save(snapshot, conversation_id)
                    repos_saved.append("profile")
            except Exception as e:
                summary.persist_errors.append(f"profile/digests: {e}")

        summary.repositories_saved = repos_saved

    def persist_background_state(self, state: RuntimeState) -> List[str]:
        conversation_id = state.session.conversation_id
        repos_saved: List[str] = []

        try:
            self._ltm_repo.save(state.long_term_memory, conversation_id)
            repos_saved.append("long_term_memory")
        except Exception as e:
            state.debug_state.record_event({
                "type": "PERSIST_ERROR",
                "repo": "long_term_memory",
                "error": str(e),
            })

        try:
            digests = state.digest_generator.get_all()
            if digests:
                self._digest_repo.save(digests, conversation_id)
                repos_saved.append("digests")
            snapshot = state.profile_builder.current_snapshot
            if snapshot:
                self._profile_repo.save(snapshot, conversation_id)
                repos_saved.append("profile")
        except Exception as e:
            state.debug_state.record_event({
                "type": "PERSIST_ERROR",
                "repo": "profile/digests",
                "error": str(e),
            })

        try:
            self._world_state_repo.save(
                state.world_runtime,
                state.ambient_state,
                conversation_id,
            )
            repos_saved.append("world_state")
        except Exception as e:
            state.debug_state.record_event({
                "type": "PERSIST_ERROR",
                "repo": "world_state",
                "error": str(e),
            })

        try:
            self._npc_repo.save(
                state.npc_registry.get_all(),
                conversation_id,
            )
            repos_saved.append("npcs")
        except Exception as e:
            state.debug_state.record_event({
                "type": "PERSIST_ERROR",
                "repo": "npcs",
                "error": str(e),
            })

        try:
            self._world_event_repo.save(
                state.world_event_store,
                conversation_id,
            )
            repos_saved.append("world_events")
        except Exception as e:
            state.debug_state.record_event({
                "type": "PERSIST_ERROR",
                "repo": "world_events",
                "error": str(e),
            })

        return repos_saved
