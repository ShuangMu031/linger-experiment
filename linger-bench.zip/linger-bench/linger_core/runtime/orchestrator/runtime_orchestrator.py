from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from linger_core.core.state.runtime_state import RuntimeState
from linger_core.core.state.runtime_state_view import RuntimeStateView
from linger_core.core.events.system_event import SystemEvent
from linger_core.core.events.event_types import EventType
from linger_core.core.events.dispatcher import EventDispatcher
from linger_core.core.observability.event_logger import EventLogger
from linger_core.core.observability.trace_store import TraceStore
from linger_core.core.observability.trace_archive import TraceArchive
from linger_core.core.observability.turn_snapshot import build_turn_snapshot
from linger_core.core.observability.health_snapshotter import HealthSnapshotter
from linger_core.supervisor.supervisor_kernel import SupervisorKernel
from linger_core.supervisor.action_plan import ActionPlan, ActionStep
from linger_core.supervisor.proactive_planner import ProactivePlanner
from linger_core.supervisor.followup_hook import create_followup_hook
from linger_core.core.contracts.module_contract import ModuleInput
from linger_core.core.emotion.emotion_dimensions import EmotionVector
from linger_core.runtime.foreground.prompt_context_summarizer import (
    summarize_inner_life,
)
from linger_core.runtime.foreground.response_builder import ResponseBuilder
from linger_core.runtime.foreground.proactive_response_builder import ProactiveResponseBuilder
from linger_core.runtime.foreground.template_rule_engine import TemplateRuleEngine
from linger_core.supervisor.modules.inner_life_update_module import (
    InnerLifeUpdateModule,
)
from linger_core.runtime.orchestrator.runtime_envelope import RuntimeEnvelope, EnvelopeSourceType
from linger_core.runtime.orchestrator.context_assembler import ContextAssembler, ContextBundle
from linger_core.runtime.orchestrator.writeback_manager import WritebackManager, WritebackSummary
from linger_core.runtime.actions.action_result import record_action_step, mark_step_completed
from linger_core.supervisor.tool_request_planner import ToolRequestPlanner
from linger_core.tools import create_default_registry, ToolExecutor
from linger_core.tools.tool_types import ToolResult


@dataclass
class OrchestratorResult:
    envelope_id: str
    action_plan: ActionPlan
    response_message: str
    context_bundle: ContextBundle
    should_emit: bool
    writeback_summary: WritebackSummary
    execution_summary: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "envelope_id": self.envelope_id,
            "should_emit": self.should_emit,
            "action_plan": self.action_plan.to_dict(),
            "response_message": self.response_message[:200],
            "writeback_summary": self.writeback_summary.to_dict(),
            "execution_summary": self.execution_summary,
        }


class RuntimeOrchestrator:
    def __init__(
        self,
        supervisor: SupervisorKernel,
        dispatcher: EventDispatcher,
        event_logger: EventLogger,
        trace_store: TraceStore,
        llm_provider=None,
        prompt_registry=None,
        llm_enabled: bool = False,
        llm_router=None,
        trace_archive: Optional["TraceArchive"] = None,
        bad_case_archiver=None,
        health_snapshotter: Optional["HealthSnapshotter"] = None,
        fallback_to_template: bool = False,
        enable_user_fact_memory: bool = False,
    ) -> None:
        self._supervisor = supervisor
        self._dispatcher = dispatcher
        self._event_logger = event_logger
        self._trace_store = trace_store
        self._trace_archive = trace_archive
        self._bad_case_archiver = bad_case_archiver
        self._health_snapshotter = health_snapshotter
        self._enable_user_fact_memory = enable_user_fact_memory
        self._context_assembler = ContextAssembler(trace_store=trace_store)
        # T4: pass LLM + prompt_registry so EventExtractor can run
        # anchor_date_extract; memory_ttl defaults inside if not given.
        self._writeback_manager = WritebackManager(
            llm_router=llm_router,
            llm_provider=llm_provider,
            prompt_registry=prompt_registry,
            enable_user_fact_memory=enable_user_fact_memory,
        )
        self._proactive_planner = ProactivePlanner()
        self._template_engine = TemplateRuleEngine()
        self._response_builder = ResponseBuilder(
            engine=self._template_engine,
            llm_provider=llm_provider,
            prompt_registry=prompt_registry,
            llm_enabled=llm_enabled,
            llm_router=llm_router,
            trace_store=trace_store,
            fallback_to_template=fallback_to_template,
        )
        self._proactive_response_builder = ProactiveResponseBuilder(
            engine=self._template_engine,
            llm_provider=llm_provider,
            prompt_registry=prompt_registry,
            llm_enabled=llm_enabled,
            llm_router=llm_router,
        )
        self._llm_router = llm_router
        self._tool_request_planner = ToolRequestPlanner()
        self._tool_registry = None
        self._tool_executor = None
        self._inner_life_module = InnerLifeUpdateModule()

    def handle_envelope(
        self, envelope: RuntimeEnvelope, state: RuntimeState
    ) -> OrchestratorResult:
        trace_label = f"ORCHESTRATOR_{envelope.source_type.value.upper()}"
        trace_id = self._trace_store.start_trace(trace_label)
        self._trace_store.start_whitebox_trace(trace_id, state.clock.logical.turn_id)  # noqa: state-penetration (pre-view: trace starts before _prepare_user_input mutates clock)

        planned_steps: list = []
        archive_action_plan: Optional[ActionPlan] = None
        archive_response_message: str = ""
        archive_should_emit: bool = False
        archive_writeback_summary: Optional[WritebackSummary] = None
        view: Optional[RuntimeStateView] = None

        try:
            self._trace_store.add_step({
                "step": "envelope_received",
                "source_type": envelope.source_type.value,
                "envelope_id": envelope.envelope_id,
            })

            if envelope.source_type == EnvelopeSourceType.USER_INPUT:
                self._prepare_user_input(state, envelope)
            else:
                self._prepare_proactive_input(state, envelope)

            view = RuntimeStateView.from_state(state)
            context_bundle = self._context_assembler.build(state, envelope, view=view)

            record_action_step("assemble_context", envelope.source_type.value,
                               reason=envelope.text[:80] if envelope.text else "",
                               planned_steps=planned_steps)

            self._trace_store.add_step({
                "step": "context_assembled",
                "has_recent": context_bundle.recent_context is not None,
                "has_event": context_bundle.event_context is not None,
                "has_profile": context_bundle.profile_context is not None,
                "has_world": context_bundle.world_context is not None,
            })

            if envelope.source_type == EnvelopeSourceType.USER_INPUT:
                action_plan = self._supervisor.process(
                    state=state,
                    user_message=envelope.text,
                    event_type="USER_INPUT",
                    event_context=context_bundle.event_context,
                    context_bundle=context_bundle,
                    trace_id=trace_id,
                )
            else:
                action_plan = self._proactive_planner.process_candidate(
                    envelope, state, context_bundle
                )

            record_action_step("route_task", action_plan.primary_goal,
                               reason=action_plan.reasoning_summary[:80],
                               planned_steps=planned_steps)

            self._trace_store.add_step({
                "step": "plan_produced",
                "primary_goal": action_plan.primary_goal,
                "strategy": action_plan.response_strategy,
                "confidence": action_plan.confidence,
                "can_speak": action_plan.can_speak,
            })

            tool_results: List[ToolResult] = []
            if envelope.source_type == EnvelopeSourceType.USER_INPUT:
                tool_results = self._execute_tools_if_needed(
                    envelope.text, state, trace_id, planned_steps
                )

            # ─── T8: InnerLife 集成 ─────────────────────────────────
            inner_life_block_text = ""
            if envelope.source_type == EnvelopeSourceType.USER_INPUT:
                ei_payload = self._extract_emotion_insight_payload(action_plan)
                if ei_payload is not None:
                    real_now = state.clock.real_now_time()
                    self._inner_life_module.process(
                        state,
                        ModuleInput(
                            user_message=envelope.text,
                            event_type="USER_INPUT",
                            context={
                                "emotion_insight_8d": ei_payload,
                                "real_now": real_now,
                            },
                        ),
                    )
                    instant_vec = EmotionVector.from_dict(
                        ei_payload.get("dimensions") or {}
                    )
                    inner_life_block_text = summarize_inner_life(
                        view.inner_life, instant=instant_vec,
                    )
                self._trace_store.add_step({
                    "step": "inner_life_snapshot",
                    "phase": "after_emotion_router",
                    "snapshot": view.inner_life.snapshot(),
                })
            else:
                inner_life_block_text = summarize_inner_life(
                    view.inner_life, instant=None,
                )
                self._trace_store.add_step({
                    "step": "inner_life_snapshot",
                    "phase": "before_proactive_response",
                    "snapshot": view.inner_life.snapshot(),
                })

            if envelope.source_type == EnvelopeSourceType.USER_INPUT:
                response_plan = self._response_builder.build(
                    user_message=envelope.text,
                    plan=action_plan,
                    turn_context={"turn_id": view.clock.turn_id},
                    recent_context=context_bundle.recent_context,
                    event_context=context_bundle.event_context,
                    profile_context=context_bundle.profile_context,
                    digest_context=context_bundle.digest_context,
                    world_context=context_bundle.world_context,
                    tool_results=tool_results,
                    inner_life_block=inner_life_block_text,
                    ltm_context=self._recall_user_facts(state),
                )
                response_message = response_plan.render()
                self._trace_store.add_step({
                    "step": "response_planned",
                    "kind": response_plan.kind,
                    "template_id": response_plan.template_id,
                    "metadata": dict(response_plan.metadata),
                })
            else:
                relationship_stage = view.relationship.snapshot.relationship_stage
                response_plan = self._proactive_response_builder.build(
                    plan=action_plan,
                    event_context=context_bundle.event_context,
                    profile_context=context_bundle.profile_context,
                    digest_context=context_bundle.digest_context,
                    world_context=context_bundle.world_context,
                    relationship_stage=relationship_stage,
                    turn_context={"turn_id": view.clock.turn_id},
                    inner_life_block=inner_life_block_text,
                )
                response_message = response_plan.render()
                self._trace_store.add_step({
                    "step": "response_planned",
                    "kind": response_plan.kind,
                    "template_id": response_plan.template_id,
                    "metadata": dict(response_plan.metadata),
                })

            record_action_step("build_response", action_plan.speak_mode,
                               reason=f"should_emit={action_plan.can_speak and bool(response_message)}",
                               planned_steps=planned_steps)

            if action_plan.allow_followup and action_plan.followup_hook:
                self._register_followup(state, action_plan)
                record_action_step("register_followup", action_plan.followup_hook,
                                   planned_steps=planned_steps)

            writeback_summary = self._writeback_manager.commit(
                state, envelope, action_plan, response_message
            )

            record_action_step("writeback_memory", "short_term+event+profile",
                               reason=f"repos={writeback_summary.repositories_saved}",
                               planned_steps=planned_steps)

            state.debug_state.record_event({
                "type": "ORCHESTRATOR_RESULT",
                "source_type": envelope.source_type.value,
                "primary_goal": action_plan.primary_goal,
                "strategy": action_plan.response_strategy,
                "confidence": action_plan.confidence,
                "speak_mode": action_plan.speak_mode,
                "can_speak": action_plan.can_speak,
            })

            should_emit = action_plan.can_speak and bool(response_message)

            if should_emit:
                if envelope.source_type == EnvelopeSourceType.USER_INPUT:
                    state.session.last_speaker = "assistant"
                    state.session.consecutive_assistant_turns += 1
                    state.session.assistant_messages_since_user += 1
                    state.session.last_assistant_message_at = state.clock.real_now_time()
                    if action_plan.should_pause or action_plan.pause_required:
                        state.session.waiting_for_user_reply = True
                    else:
                        state.session.waiting_for_user_reply = False
                else:
                    state.session.mark_assistant_proactive_sent(
                        now=state.clock.real_now_time(),
                    )
                    # T8: proactive 消息发出后释放 impulse
                    self._inner_life_module.process(
                        state,
                        ModuleInput(
                            user_message="",
                            event_type="PROACTIVE_SENT",
                            context={"real_now": state.clock.real_now_time()},
                        ),
                    )
                state.clock.mark_assistant_event()

            self._trace_store.set_action_result(trace_id, {
                "source_type": envelope.source_type.value,
                "response_type": action_plan.response_strategy,
                "should_emit": should_emit,
                "speak_mode": action_plan.speak_mode,
            })

            for step in planned_steps:
                if step.status == "executing":
                    mark_step_completed(step)

            action_plan.planned_steps = planned_steps

            archive_action_plan = action_plan
            archive_response_message = response_message
            archive_should_emit = should_emit
            archive_writeback_summary = writeback_summary

            execution_summary: Dict[str, Any] = {
                "envelope_source": envelope.source_type.value,
                "context_layers": {
                    "recent": context_bundle.recent_context is not None,
                    "event": context_bundle.event_context is not None,
                    "profile": context_bundle.profile_context is not None,
                    "world": context_bundle.world_context is not None,
                },
                "decision": {
                    "primary_goal": action_plan.primary_goal,
                    "strategy": action_plan.response_strategy,
                    "speak_mode": action_plan.speak_mode,
                    "can_speak": action_plan.can_speak,
                },
                "tool_results": [tr.to_dict() for tr in tool_results],
                "writeback": writeback_summary.to_dict(),
            }

            return OrchestratorResult(
                envelope_id=envelope.envelope_id,
                action_plan=action_plan,
                response_message=response_message,
                context_bundle=context_bundle,
                should_emit=should_emit,
                writeback_summary=writeback_summary,
                execution_summary=execution_summary,
            )
        except Exception as e:
            self._trace_store.add_step({
                "step": "orchestrator_error",
                "error": str(e),
            })
            raise
        finally:
            wb_closed = self._trace_store.end_whitebox_trace(trace_id=trace_id)
            tr_closed = self._trace_store.end_trace(result="orchestrated_or_error")
            self._maybe_archive_turn(
                trace_id=trace_id,
                envelope=envelope,
                turn_id=view.clock.turn_id if view is not None else 0,
                wb_closed=wb_closed,
                tr_closed=tr_closed,
                action_plan=archive_action_plan,
                response_message=archive_response_message,
                should_emit=archive_should_emit,
                writeback_summary=archive_writeback_summary,
            )

    def _maybe_archive_turn(
        self,
        *,
        trace_id: str,
        envelope: RuntimeEnvelope,
        turn_id: int,
        wb_closed,
        tr_closed,
        action_plan: Optional[ActionPlan],
        response_message: str,
        should_emit: bool,
        writeback_summary: Optional[WritebackSummary],
    ) -> None:
        if self._trace_archive is None:
            return
        try:
            wb_dict = wb_closed.to_dict() if wb_closed is not None else {}
            steps = list(getattr(tr_closed, "steps", []) or [])
            duration_ms = float(getattr(wb_closed, "duration_ms", 0.0) or 0.0)
            ap_dict = action_plan.to_full_dict() if action_plan is not None else {}
            wb_summary = writeback_summary.to_dict() if writeback_summary is not None else {}

            snapshot = build_turn_snapshot(
                turn_id=turn_id,
                trace_id=trace_id,
                envelope_source=envelope.source_type.value,
                user_message=envelope.text or "",
                response_message=response_message or "",
                should_emit=bool(should_emit),
                action_plan_dict=ap_dict,
                whitebox_dict=wb_dict,
                trace_steps=steps,
                writeback_summary_dict=wb_summary,
                duration_ms=duration_ms,
            )
            path = self._trace_archive.persist(snapshot)

            if self._bad_case_archiver is not None:
                self._bad_case_archiver.maybe_archive(snapshot, path)
            if self._health_snapshotter is not None:
                self._health_snapshotter.maybe_snapshot()
        except Exception as e:
            self._trace_store.add_step({
                "step": "trace_archive_error",
                "error": f"{type(e).__name__}: {e}",
            })

    @staticmethod
    def _extract_emotion_insight_payload(action_plan: ActionPlan) -> Optional[Dict[str, Any]]:
        """T8: 从 action_plan.state_writes 找 EmotionInsightModule 的 8 维输出。

        若找不到（emotion_insight 没运行 / 出错 fallback），返 None；
        InnerLifeUpdateModule 因此走 noop 路径。
        """
        for write in action_plan.state_writes:
            if isinstance(write, dict) and "dimensions" in write and "dominant_dimension" in write:
                return {
                    "dimensions": write.get("dimensions") or {},
                    "dominant_dimension": write.get("dominant_dimension") or "",
                    "event_id": "",  # T8: 暂不连接 event_id（spec §4.6 attention_writes 需 event_id）
                    "summary": "",
                }
        return None

    def _prepare_user_input(
        self, state: RuntimeState, envelope: RuntimeEnvelope
    ) -> None:
        state.clock.mark_user_event()
        state.session.mark_active(real_now=state.clock.real_now_time())

        prev_turn = state.clock.logical.turn_id - 1  # noqa: state-penetration (inside _prepare_user_input, runs before view construction)
        state.plan_state.cancel_followups_for_turn(prev_turn, reason="user_responded")

        state.session.last_speaker = "user"
        state.session.consecutive_assistant_turns = 0
        state.session.assistant_messages_since_user = 0
        state.session.assistant_proactive_streak = 0
        state.session.waiting_for_user_reply = False

        end_signals = [
            "再见", "拜拜", "晚安", "先这样", "走了",
            "下次聊", "不说了", "bye", "goodbye",
        ]
        msg_lower = envelope.text.lower().strip()
        state.session.last_user_end_signal = any(s in msg_lower for s in end_signals)

        event = SystemEvent(
            event_type=EventType.USER_INPUT,
            payload={"message": envelope.text},
            source="user",
        )
        self._dispatcher.dispatch(event)
        self._event_logger.log_event(event)

    def _prepare_proactive_input(
        self, state: RuntimeState, envelope: RuntimeEnvelope
    ) -> None:
        state.debug_state.record_event({
            "type": "PROACTIVE_ENVELOPE_PREPARED",
            "envelope_id": envelope.envelope_id,
            "source_type": envelope.source_type.value,
        })

    def _recall_user_facts(self, state) -> str:
        if not self._enable_user_fact_memory:
            return ""
        from linger_core.memory.profile_recall import ProfileRecall
        return ProfileRecall(state.long_term_memory).recall_user_facts()

    def _register_followup(
        self, state: RuntimeState, plan: ActionPlan
    ) -> None:
        conditions: Dict[str, Any] = {}
        if plan.speak_mode in ("comfort_only", "comfort_first", "gentle_presence"):
            conditions["require_idle_min_seconds"] = 30
            conditions["require_emotion_not_escalated"] = True
        if plan.speak_mode in ("warm_respond", "warm_acknowledge"):
            conditions["require_idle_min_seconds"] = 15
        conditions["max_consecutive_assistant_turns"] = 2
        conditions["require_no_user_end_signal"] = True

        hook = create_followup_hook(
            hook_type=plan.followup_hook,
            source_turn_id=state.clock.logical.turn_id,  # noqa: state-penetration (helper takes state only; view not threaded here)
            world_now=state.clock.world_now_time(),
            reason=plan.reasoning_summary[:200],
            trigger_conditions=conditions,
        )
        if hook:
            state.plan_state.add_followup(hook)

    @property
    def writeback_manager(self) -> WritebackManager:
        return self._writeback_manager

    @property
    def llm_router(self):
        return self._llm_router

    def _ensure_tool_system(self, state: RuntimeState) -> None:
        if self._tool_registry is None:
            self._tool_registry = create_default_registry(state=state)
            self._tool_executor = ToolExecutor(self._tool_registry, approver="supervisor")

    def _execute_tools_if_needed(
        self,
        user_message: str,
        state: RuntimeState,
        trace_id: str,
        planned_steps: list,
    ) -> List[ToolResult]:
        self._ensure_tool_system(state)

        requests = self._tool_request_planner.plan(user_message)
        if not requests:
            return []

        results: List[ToolResult] = []
        for req in requests:
            self._trace_store.add_step({
                "step": "tool_request_created",
                "tool_name": req.tool_name,
                "arguments": req.arguments,
                "requester": req.requester,
                "reason": req.reason,
            })

            record_action_step("tool_request", req.tool_name,
                               reason=req.reason,
                               planned_steps=planned_steps)

            result = self._tool_executor.approve_and_execute(req)

            self._trace_store.add_step({
                "step": "tool_executed",
                "tool_name": result.tool_name,
                "success": result.success,
                "error": result.error,
                "approved_by": result.approved_by,
                "execution_time_ms": result.execution_time_ms,
            })

            results.append(result)

        return results
