from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView

from linger_core.core.observability.trace_store import TraceStore
from linger_core.core.state.runtime_state import RuntimeState
from linger_core.memory.short_term_recall import ShortTermRecall
from linger_core.memory.event_recall import EventRecall
from linger_core.runtime.orchestrator.runtime_envelope import RuntimeEnvelope, EnvelopeSourceType
from linger_core.runtime.startup.startup_context_builder import StartupContextBuilder


@dataclass
class ContextBundle:
    recent_context: Optional[Any] = None
    event_context: Optional[Any] = None
    profile_context: Optional[Dict[str, Any]] = None
    digest_context: Optional[Dict[str, Any]] = None
    startup_context: Optional[Dict[str, Any]] = None
    world_context: Optional[Dict[str, Any]] = None
    session_context: Optional[Dict[str, Any]] = None
    plan_context: Optional[Dict[str, Any]] = None
    assembly_errors: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {}
        if self.recent_context is not None:
            result["recent_context"] = (
                self.recent_context.to_dict()
                if hasattr(self.recent_context, "to_dict")
                else self.recent_context
            )
        if self.event_context is not None:
            result["event_context"] = (
                self.event_context.to_dict()
                if hasattr(self.event_context, "to_dict")
                else self.event_context
            )
        if self.profile_context is not None:
            result["profile_context"] = self.profile_context
        if self.digest_context is not None:
            result["digest_context"] = self.digest_context
        if self.startup_context is not None:
            result["startup_context"] = self.startup_context
        if self.world_context is not None:
            result["world_context"] = self.world_context
        if self.session_context is not None:
            result["session_context"] = self.session_context
        if self.plan_context is not None:
            result["plan_context"] = self.plan_context
        if self.assembly_errors:
            result["assembly_errors"] = self.assembly_errors
        return result


class ContextAssembler:
    def __init__(self, trace_store: Optional[TraceStore] = None) -> None:
        self._recall = ShortTermRecall()
        self._event_recall = EventRecall()
        self._startup_builder = StartupContextBuilder()
        self._trace_store = trace_store

    def build(
        self,
        state: RuntimeState,
        envelope: RuntimeEnvelope,
        view: "RuntimeStateView",
    ) -> ContextBundle:
        """Assemble the per-turn ContextBundle from the frozen view.

        ``state`` is retained in the signature only for the single
        ``self._startup_builder.build(state)`` pass-through call below.
        StartupContextBuilder itself is in ``runtime/startup/`` and outside
        this plan's scope; its migration is deferred to plan-5 or an
        independent follow-up. All other reads in this method go through
        ``view``.
        """
        errors: List[str] = []

        recent_context = self._recall.recall(view.memory.short_term._store_ref)

        event_context = None
        if envelope.text:
            event_context = self._event_recall.recall(
                view.memory.events._store_ref, current_message=envelope.text
            )

        profile_context = view.profile._state_ref.to_dict()

        digest_context = self._build_digest_context(view, errors)

        startup_context = None
        if view.profile.active_ltm_count > 0:
            try:
                startup_context = self._startup_builder.build(state)
            except Exception as e:
                startup_context = None
                errors.append(f"startup_context: {e}")
                self._trace_error("startup_context_build_error", str(e))

        world_context = None
        if view.world._snapshot_builder_ref is not None:
            try:
                world_context = view.world._snapshot_builder_ref.build(
                    place_registry=view.world._place_registry_ref
                )
            except Exception as e:
                world_context = None
                errors.append(f"world_context: {e}")
                self._trace_error("world_context_build_error", str(e))

        session_context = self._build_session_context(view)

        plan_context = self._build_plan_context(view)

        return ContextBundle(
            recent_context=recent_context,
            event_context=event_context,
            profile_context=profile_context,
            digest_context=digest_context,
            startup_context=startup_context,
            world_context=world_context,
            session_context=session_context,
            plan_context=plan_context,
            assembly_errors=errors,
        )

    def _build_digest_context(self, view: "RuntimeStateView", errors: List[str]) -> Optional[Dict[str, Any]]:
        try:
            from linger_core.memory.digest_recall import DigestRecall

            recall = DigestRecall(view.memory.long_term._digest_generator_ref.get_all())
            latest = recall.get_latest()
            if not latest:
                return None
            return {
                "summary_short": latest.summary_short,
                "recommended_style": latest.recommended_style,
                "recommended_openers": latest.recommended_openers,
                "relationship_trend": latest.relationship_trend,
                "main_topics": latest.main_topics,
            }
        except Exception as e:
            errors.append(f"digest_context: {e}")
            self._trace_error("digest_context_build_error", str(e))
            return None

    def _build_session_context(self, view: "RuntimeStateView") -> Dict[str, Any]:
        return {
            "session_id": view.session.session_id,
            "conversation_id": view.session.conversation_id,
            "turn_id": view.clock.turn_id,
            "idle_seconds": view.session.idle_seconds_at_freeze,
            "last_speaker": view.session.last_speaker,
            "waiting_for_user_reply": view.session.waiting_for_user_reply,
            "consecutive_assistant_turns": view.session.consecutive_assistant_turns,
            "assistant_messages_since_user": view.session.assistant_messages_since_user,
            "assistant_proactive_streak": view.session.assistant_proactive_streak,
            "last_user_end_signal": view.session.last_user_end_signal,
        }

    def _build_plan_context(self, view: "RuntimeStateView") -> Dict[str, Any]:
        return {
            "active_plans": len(view.plan.active_plans()),
            "pending_followups": view.plan.pending_followups_count,
            "outbound_candidates": view.plan.outbound_candidates_count,
        }

    def _trace_error(self, step: str, error: str) -> None:
        if self._trace_store is not None:
            self._trace_store.add_step({
                "step": step,
                "error": error,
            })
