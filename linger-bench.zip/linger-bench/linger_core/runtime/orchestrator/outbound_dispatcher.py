from typing import TYPE_CHECKING, List, Optional

from linger_core.core.observability.trace_store import TraceStore
from linger_core.core.state.runtime_state import RuntimeState
from linger_core.runtime.orchestrator.runtime_envelope import (
    RuntimeEnvelope,
    EnvelopeSourceType,
)
from linger_core.runtime.orchestrator.runtime_orchestrator import RuntimeOrchestrator, OrchestratorResult
from linger_core.supervisor.proactive_guard import ProactiveGuard
from linger_core.triggers.trigger_candidate import TriggerCandidate, TriggerSourceType

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


_ENVELOPE_TYPE_MAP = {
    TriggerSourceType.FOLLOWUP: EnvelopeSourceType.FOLLOWUP_CANDIDATE,
    TriggerSourceType.WORLD_EVENT: EnvelopeSourceType.WORLD_EVENT_CANDIDATE,
    TriggerSourceType.UNRESOLVED_EVENT: EnvelopeSourceType.UNRESOLVED_EVENT_CANDIDATE,
    TriggerSourceType.RECONNECT: EnvelopeSourceType.RECONNECT_CANDIDATE,
    TriggerSourceType.RELATIONSHIP_PING: EnvelopeSourceType.RELATIONSHIP_PING_CANDIDATE,
    TriggerSourceType.DIGEST_OPENER: EnvelopeSourceType.DIGEST_OPENER_CANDIDATE,
}


class OutboundDispatcher:
    def __init__(
        self,
        orchestrator: RuntimeOrchestrator,
        guard: Optional[ProactiveGuard] = None,
        trace_store: Optional[TraceStore] = None,
    ) -> None:
        self._orchestrator = orchestrator
        self._guard = guard or ProactiveGuard()
        self._trace_store = trace_store

    def drain_and_dispatch(
        self, state: RuntimeState, view: "RuntimeStateView"
    ) -> List[OrchestratorResult]:
        results: List[OrchestratorResult] = []

        for candidate in state.plan_state.drain_outbound_candidates():
            decision = self._guard.evaluate(candidate, state)
            if not decision.allowed:
                self._trace_suppressed(candidate, decision.suppressed_reason)
                continue

            envelope = self._envelope_from_trigger_candidate(candidate, view)
            if envelope is None:
                continue

            envelope.priority = decision.adjusted_priority

            result = self._orchestrator.handle_envelope(envelope, state)
            results.append(result)

        return results

    def _envelope_from_trigger_candidate(
        self, candidate: TriggerCandidate, view: "RuntimeStateView"
    ) -> Optional[RuntimeEnvelope]:
        trigger_type = candidate.source_type
        envelope_type = _ENVELOPE_TYPE_MAP.get(trigger_type)
        if envelope_type is None:
            return None

        from linger_core.shared.ids import generate_id

        real_now = view.clock.real_now_time()
        world_now = view.clock.world_now_time()

        original_payload = candidate.payload or {}
        payload = {
            **original_payload,
            "candidate_id": candidate.candidate_id,
            "proactive_goal": candidate.proactive_goal,
            "suggested_style": candidate.suggested_style,
            "confidence": candidate.confidence,
            "trigger_type": candidate.source_type.value,
        }

        return RuntimeEnvelope(
            envelope_id=f"env_{generate_id()[:12]}",
            source_type=envelope_type,
            source_id=candidate.source_id,
            source_event_type=f"{trigger_type.value.upper()}_CANDIDATE",
            created_at_real=real_now,
            created_at_world=world_now,
            text=candidate.reason[:200],
            priority=candidate.priority,
            user_relevance=candidate.user_relevance,
            requires_response=True,
            related_event_id=candidate.related_event_id,
            related_world_event_id=candidate.related_world_event_id,
            related_followup_hook_id=candidate.related_followup_hook_id,
            related_npc_id=candidate.related_npc_id,
            payload=payload,
            tags=candidate.tags,
        )

    def _trace_suppressed(self, candidate: TriggerCandidate, reason: str) -> None:
        if self._trace_store is not None:
            self._trace_store.add_step({
                "step": "outbound_suppressed",
                "source_type": candidate.source_type.value,
                "candidate_id": candidate.candidate_id,
                "reason": reason,
            })
