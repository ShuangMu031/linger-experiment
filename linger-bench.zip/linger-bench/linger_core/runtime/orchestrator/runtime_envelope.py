from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from linger_core.shared.ids import generate_id


class EnvelopeSourceType(str, Enum):
    USER_INPUT = "user_input"
    FOLLOWUP_CANDIDATE = "followup_candidate"
    WORLD_EVENT_CANDIDATE = "world_event_candidate"
    UNRESOLVED_EVENT_CANDIDATE = "unresolved_event_candidate"
    RECONNECT_CANDIDATE = "reconnect_candidate"
    RELATIONSHIP_PING_CANDIDATE = "relationship_ping_candidate"
    DIGEST_OPENER_CANDIDATE = "digest_opener_candidate"


@dataclass
class RuntimeEnvelope:
    envelope_id: str
    source_type: EnvelopeSourceType
    source_id: str
    source_event_type: str
    created_at_real: datetime
    created_at_world: datetime

    text: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)

    priority: float = 0.5
    user_relevance: float = 0.5
    requires_response: bool = True

    related_event_id: Optional[str] = None
    related_world_event_id: Optional[str] = None
    related_followup_hook_id: Optional[str] = None
    related_npc_id: Optional[str] = None

    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "envelope_id": self.envelope_id,
            "source_type": self.source_type.value,
            "source_id": self.source_id,
            "source_event_type": self.source_event_type,
            "created_at_real": self.created_at_real.isoformat(),
            "created_at_world": self.created_at_world.isoformat(),
            "text": self.text[:200],
            "priority": self.priority,
            "user_relevance": self.user_relevance,
            "requires_response": self.requires_response,
            "related_event_id": self.related_event_id,
            "related_world_event_id": self.related_world_event_id,
            "related_followup_hook_id": self.related_followup_hook_id,
            "related_npc_id": self.related_npc_id,
            "tags": self.tags,
            "payload_keys": list(self.payload.keys()),
            "payload_preview": {
                key: str(value)[:120]
                for key, value in self.payload.items()
            },
        }


def create_user_envelope(
    user_message: str,
    real_now: datetime,
    world_now: datetime,
) -> RuntimeEnvelope:
    return RuntimeEnvelope(
        envelope_id=f"env_{generate_id()[:12]}",
        source_type=EnvelopeSourceType.USER_INPUT,
        source_id="user",
        source_event_type="USER_INPUT",
        created_at_real=real_now,
        created_at_world=world_now,
        text=user_message,
        priority=1.0,
        user_relevance=1.0,
        requires_response=True,
        tags=["user_input"],
    )
