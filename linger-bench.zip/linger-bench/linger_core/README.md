# linger_core — vendored backend (research snapshot)

This is the backend that **is** the B / B⁻ system in the paper: a single
deterministic, **rule-based cognitive-orchestration** pipeline
(interpret → decide → generate → extract). It is **not** a multi-agent system and
**not** production code — it is the research snapshot that actually produced the
E5/E6 numbers, vendored here verbatim so the experiments are reproducible.

## Honesty notes (please keep if you fork)

- **Faithful, not polished.** This is research code: naming is uneven and there is
  no production hardening. It is included *as-is* on purpose — the value is that it
  is the exact code behind the reported results, not a cleaned-up rewrite that
  might silently diverge from them.
- **Provenance.** Vendored from the `the_new_world` companion project; the import
  prefix was mechanically renamed `the_new_world` → `linger_core`. The
  non-experiment surface (`web/`, `cli/`, frontend) was dropped — none of it is on
  the B/B⁻ execution path.
- **Coverage.** A single B run (warmup + plant / recall / identity / boundary
  turns) loads 202 of the 208 modules here. The remaining few (snapshot
  persistence, quality scoring, proactive triggers) are part of the companion
  system but are not exercised by the scripted benchmark; they are kept so the
  backend stays complete and faithful rather than trimmed to only what E5/E6 hits.

## Entry points the experiments use

`experiments/common/systems.py` drives B / B⁻ through:

- `linger_core.runtime.bootstrap.startup.Startup(load_memory=False, config=cfg)`
  → `.initialize()` → `.foreground.handle_user_input(text)`
- `linger_core.config.default_config.DefaultConfig` — the single flag
  `memory.enable_user_fact_memory` is the **only** difference between B (True) and
  B⁻ (False).
- `linger_core.llm.*` — the OpenAI-compatible provider layer (also used by the
  bare / RAG baselines A1 / A2).

The `*_SPEC.md` design notes in this directory document the 19-field ActionPlan,
layered memory, persona invariants, and the single-write boundary.
