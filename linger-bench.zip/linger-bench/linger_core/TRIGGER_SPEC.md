# TRIGGER_SPEC — the_new_world v0.4.0a14

> **性质**：触发系统的字段与行为冻结文档。  
> **适用范围**：所有 TriggerSource 实现、OutboundDispatcher、ProactiveGuard、ProactivePlanner。

---

## 1. TriggerSourceType 枚举

| 值 | 含义 | 对应 TriggerSource |
|----|------|-------------------|
| `followup` | 用户回复后的跟进检查 | FollowupTriggerSource |
| `world_event` | 世界状态变化 | WorldTriggerSource |
| `unresolved_event` | 未解决的高情绪事件 | EventTriggerSource |
| `reconnect` | 用户长时间离开后重连 | ReconnectTriggerSource |
| `relationship_ping` | 周期关系维护 | RelationshipTriggerSource |
| `digest_opener` | 新摘要触发轻量开场 | (预留) |

---

## 2. TriggerCandidate 字段固化

| 字段 | 类型 | 是否冻结合同 | 含义 |
|------|------|-------------|------|
| `candidate_id` | `str` | ✅ | 唯一标识 |
| `source_type` | `TriggerSourceType` | ✅ | 候选来源类型 |
| `source_id` | `str` | ✅ | 来源实体 ID（hook_id/event_id 等） |
| `reason` | `str` | ✅ | 人类可读的触发原因 |
| `created_at_real` | `datetime` | ✅ | 真实时间 |
| `created_at_world` | `datetime` | ✅ | 世界时间 |
| `priority` | `float` | ✅ | 0.0-1.0，候选排序依据 |
| `user_relevance` | `float` | ✅ | 此事件对用户的相关性 |
| `confidence` | `float` | ✅ | 触发源的置信度 |
| `proactive_goal` | `str` | ✅ | 合法枚举见 §3 |
| `suggested_style` | `str` | ✅ | 合法枚举见 §4 |
| `related_event_id` | `str?` | ✅ | 关联的事件记忆 ID |
| `related_world_event_id` | `str?` | ✅ | 关联的世界事件 ID |
| `related_followup_hook_id` | `str?` | ✅ | 关联的 followup hook ID |
| `related_npc_id` | `str?` | ✅ | 关联的 NPC ID |
| `payload` | `dict` | ✅ | 额外上下文（禁止携带大体积数据） |
| `tags` | `List[str]` | ✅ | 分类标签 |

---

## 3. proactive_goal 合法枚举

| 值 | 含义 | 来源类型 |
|----|------|---------|
| `gentle_check_in` | 轻量状态检查 | followup, reconnect, relationship_ping |
| `world_observation` | 世界状态变化通报 | world_event |
| `unfinished_thread_ping` | 未完成话题轻触 | unresolved_event |
| `reconnect` | 用户回归欢迎 | reconnect |
| `supportive_presence` | 静默陪伴 | unresolved_event (高情绪) |
| `light_plan_reminder` | 轻量计划提醒 | followup, digest_opener |

---

## 4. suggested_style 合法枚举

| 值 | 含义 | 适用场景 |
|----|------|---------|
| `warm` | 温暖自然 | 日常检查、回归、世界观察 |
| `gentle` | 克制柔和 | 情绪支持、高敏感事件 |
| `neutral` | 中性客观 | 系统通知 |
| `casual` | 轻松随意 | 日常闲聊触发 |

---

## 5. priority / user_relevance / confidence 区别

| 字段 | 语义 | 谁设置 |
|------|------|--------|
| `priority` | 候选在队列中的排序权重 | TriggerSource |
| `user_relevance` | 事件与用户的相关程度 | TriggerSource，Guard 以此判断是否拦截低相关候选 |
| `confidence` | 触发源对"应该触发"的置信度 | TriggerSource，Guard 可下调，最终写入 ActionPlan |

---

## 6. 必须进入 RuntimeEnvelope 的字段

`OutboundDispatcher._envelope_from_trigger_candidate()` 必须将以下字段写入 `envelope.payload`：

```
proactive_goal
suggested_style
confidence
trigger_type (= source_type 的字符串值)
```

这些字段在 `ProactivePlanner.process_candidate()` 中被优先读取。

---

## 7. Guard 拦截条件

ProactiveGuard 在以下情况必须返回 `allowed=False`：

| 条件 | suppressed_reason 前缀 |
|------|----------------------|
| `session.last_user_end_signal == True` | `user_end_signal` |
| `session.consecutive_assistant_turns >= max_consecutive_proactive` | `consecutive_assistant_limit` |
| `session.assistant_proactive_streak >= max_proactive_streak` | `proactive_streak_limit` |
| RELATIONSHIP_PING 且 `trust_level < min_trust_for_proactive` | `trust_too_low` |
| `user_relevance < min_user_relevance` | `low_relevance` |
| WORLD_EVENT 且 `user_relevance < world_event_min_user_relevance` | `low_world_relevance` |
| recall_priority 相关 `recall_priority < min_recall_priority` | `low_recall_priority` |
| 最近窗口内 proactive 次数超限 | `recent_proactive_window` |

---

## 8. 候选到 Envelope 的映射

```
TriggerSourceType.FOLLOWUP          → EnvelopeSourceType.FOLLOWUP_CANDIDATE
TriggerSourceType.WORLD_EVENT       → EnvelopeSourceType.WORLD_EVENT_CANDIDATE
TriggerSourceType.UNRESOLVED_EVENT  → EnvelopeSourceType.UNRESOLVED_EVENT_CANDIDATE
TriggerSourceType.RECONNECT         → EnvelopeSourceType.RECONNECT_CANDIDATE
TriggerSourceType.RELATIONSHIP_PING → EnvelopeSourceType.RELATIONSHIP_PING_CANDIDATE
TriggerSourceType.DIGEST_OPENER     → EnvelopeSourceType.DIGEST_OPENER_CANDIDATE
```
