from enum import Enum, auto


class EmotionType(Enum):
    NEUTRAL = "neutral"
    HAPPY = "happy"
    SAD = "sad"
    ANGRY = "angry"
    ANXIOUS = "anxious"
    SURPRISED = "surprised"
    CALM = "calm"


class MemoryType(Enum):
    SHORT_TERM = "short_term"
    EPISODIC = "episodic"
    LONG_TERM = "long_term"


class EventStatus(Enum):
    OPEN = "open"
    COOLING = "cooling"
    COOLED = "cooled"
    RESOLVED = "resolved"
    ARCHIVED = "archived"


class EventType(Enum):
    HIGH_EMOTION = "high_emotion"
    UNRESOLVED = "unresolved"
    EXPLICIT_EXPERIENCE = "explicit_experience"
    REPEATED_MENTION = "repeated_mention"
    WORLD_EVENT = "world_event"


class SessionStatus(Enum):
    ACTIVE = "active"
    IDLE = "idle"
    CLOSED = "closed"


class LongTermMemoryCategory(Enum):
    PREFERENCE = "preference"
    STYLE = "style"
    RELATION = "relation"
    CONCERN = "concern"
    IDENTITY_HINT = "identity_hint"
    HABIT = "habit"


class LongTermMemoryStatus(Enum):
    ACTIVE = "active"
    TENTATIVE = "tentative"
    COOLING = "cooling"
    COOLED = "cooled"
    ARCHIVED = "archived"


class DigestWindowType(Enum):
    THREE_DAY = "3d"
    SEVEN_DAY = "7d"
    PHASE = "phase"


class TimeOfDay(Enum):
    MORNING = "morning"
    AFTERNOON = "afternoon"
    EVENING = "evening"
    NIGHT = "night"


class WorldEventType(Enum):
    TIME_CHANGE = "time_change"
    WEATHER_CHANGE = "weather_change"
    PLACE_AMBIENT_CHANGE = "place_ambient_change"
    NPC_ACTIVITY_CHANGE = "npc_activity_change"
    USER_EVENT_ECHO = "user_event_echo"


class WorldEventStatus(Enum):
    ACTIVE = "active"
    COOLING = "cooling"
    EXPIRED = "expired"
    ARCHIVED = "archived"


class PlaceCategory(Enum):
    INDOOR_PRIVATE = "indoor_private"
    INDOOR_PUBLIC = "indoor_public"
    OUTDOOR_OPEN = "outdoor_open"
    OUTDOOR_URBAN = "outdoor_urban"


class NpcActivity(Enum):
    RESTING = "resting"
    WORKING = "working"
    SOCIALIZING = "socializing"
    WANDERING = "wandering"
    EATING = "eating"
    IDLE = "idle"
