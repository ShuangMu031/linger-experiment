class EmotionWorldError(Exception):
    pass


class StateValidationError(EmotionWorldError):
    pass


class ClockError(EmotionWorldError):
    pass


class TimelineRuleError(EmotionWorldError):
    pass


class EventDispatchError(EmotionWorldError):
    pass


class PersistenceError(EmotionWorldError):
    pass


class ContractViolationError(EmotionWorldError):
    pass
