import uuid
from datetime import datetime


def generate_id() -> str:
    return uuid.uuid4().hex


def generate_event_id() -> str:
    return f"evt_{uuid.uuid4().hex[:12]}"


def generate_session_id() -> str:
    return f"ses_{uuid.uuid4().hex[:12]}"


def generate_tick_id() -> str:
    return f"tick_{uuid.uuid4().hex[:8]}"


def timestamp_now() -> datetime:
    return datetime.now()
