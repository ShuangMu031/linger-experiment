from datetime import datetime, timedelta
from typing import Optional


def delta_to_seconds(delta: timedelta) -> float:
    return delta.total_seconds()


def seconds_to_delta(seconds: float) -> timedelta:
    return timedelta(seconds=seconds)


def minutes_ago(minutes: float) -> datetime:
    return datetime.now() - timedelta(minutes=minutes)


def time_since(reference: datetime) -> timedelta:
    return datetime.now() - reference


def is_expired(updated_at: datetime, ttl: timedelta) -> bool:
    return datetime.now() - updated_at > ttl


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def safe_get(data: dict, path: str, default=None):
    keys = path.split(".")
    current = data
    for key in keys:
        if isinstance(current, dict) and key in current:
            current = current[key]
        else:
            return default
    return current
