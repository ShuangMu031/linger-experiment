from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.core.state.base_state import BaseState
from linger_core.shared.enums import NpcActivity
from linger_core.world.npc_relation import NpcRelation


@dataclass
class NpcRuntimeState(BaseState):
    npc_id: str = ""
    name: str = ""
    role: str = ""
    current_place_id: str = "home"
    current_activity: NpcActivity = NpcActivity.IDLE
    current_mood: str = "neutral"
    energy: float = 0.7
    availability: float = 0.8
    favorability_to_user: float = 0.5  # 注：实为"对沈鹿溪"的好感（字段名本轮不改名，见 spec §4.4）
    closeness_to_user: float = 0.3  # 注：实为"对沈鹿溪"的亲近度
    last_seen_world: Optional[datetime] = None
    last_interaction_world: Optional[datetime] = None
    npc_relations: Dict[str, NpcRelation] = field(default_factory=dict)
    personality_traits: List[str] = field(default_factory=list)
    description: str = ""

    def set_activity(self, activity: NpcActivity, world_now: Optional[datetime] = None) -> None:
        self.current_activity = activity
        self.last_seen_world = world_now or datetime.now()
        self.touch()

    def set_mood(self, mood: str) -> None:
        self.current_mood = mood
        self.touch()

    def set_place(self, place_id: str, world_now: Optional[datetime] = None) -> None:
        self.current_place_id = place_id
        self.last_seen_world = world_now or datetime.now()
        self.touch()

    def update_energy(self, delta: float) -> None:
        self.energy = max(0.0, min(1.0, self.energy + delta))
        self.touch()

    def update_favorability(self, delta: float) -> None:
        self.favorability_to_user = max(0.0, min(1.0, self.favorability_to_user + delta))
        self.touch()

    def update_closeness(self, delta: float) -> None:
        self.closeness_to_user = max(0.0, min(1.0, self.closeness_to_user + delta))
        self.touch()

    def record_interaction(self, world_now: Optional[datetime] = None) -> None:
        self.last_interaction_world = world_now or datetime.now()
        self.last_seen_world = world_now or datetime.now()
        self.touch()

    def get_relation(self, target_npc_id: str) -> NpcRelation:
        if target_npc_id not in self.npc_relations:
            self.npc_relations[target_npc_id] = NpcRelation(target_npc_id=target_npc_id)
        return self.npc_relations[target_npc_id]

    def to_dict(self) -> Dict[str, Any]:
        base = super().to_dict()
        base.update({
            "npc_id": self.npc_id,
            "name": self.name,
            "role": self.role,
            "current_place_id": self.current_place_id,
            "current_activity": self.current_activity.value,
            "current_mood": self.current_mood,
            "energy": self.energy,
            "availability": self.availability,
            "favorability_to_user": self.favorability_to_user,
            "closeness_to_user": self.closeness_to_user,
            "last_seen_world": self.last_seen_world.isoformat() if self.last_seen_world else None,
            "last_interaction_world": self.last_interaction_world.isoformat() if self.last_interaction_world else None,
            "npc_relations": {k: v.to_dict() for k, v in self.npc_relations.items()},
            "personality_traits": self.personality_traits,
            "description": self.description,
        })
        return base


# npc_id 是内部键，从不外露（只 name 展示）。这些 NPC 是沈鹿溪的社交圈，不是用户的人。
# 现实含义映射：npc_ling=林安安(室友) / npc_chen=赵一鸣(密室店长) / npc_yue=苏棠(配音师姐)
DEFAULT_NPCS = [
    NpcRuntimeState(
        npc_id="npc_ling",
        name="林安安",
        role="合租室友",
        current_place_id="home",
        current_activity=NpcActivity.IDLE,
        current_mood="cheerful",
        energy=0.8,
        availability=0.9,
        favorability_to_user=0.6,
        closeness_to_user=0.5,
        personality_traits=["lively", "frank", "warm"],
        description="大大咧咧的合租室友，插画师，养了只橘猫天天和麦克风打架，是鹿溪少数能说心里话的人",
    ),
    NpcRuntimeState(
        npc_id="npc_chen",
        name="赵一鸣",
        role="密室店长",
        current_place_id="cafe",
        current_activity=NpcActivity.WORKING,
        current_mood="steady",
        energy=0.7,
        availability=0.6,
        favorability_to_user=0.6,
        closeness_to_user=0.4,
        personality_traits=["steady", "protective", "experienced"],
        description="前话剧演员转行的密室店长，鹿溪的职场贵人，兄妹相称，请过她很多次火锅",
    ),
    NpcRuntimeState(
        npc_id="npc_yue",
        name="苏棠",
        role="配音圈朋友",
        current_place_id="street",
        current_activity=NpcActivity.WANDERING,
        current_mood="frank",
        energy=0.8,
        availability=0.5,
        favorability_to_user=0.5,
        closeness_to_user=0.4,
        personality_traits=["direct", "sharp", "caring"],
        description="入行早三年的自由配音演员，鹿溪的半个师傅，说话毒辣但关键时刻请她喝酒",
    ),
]
