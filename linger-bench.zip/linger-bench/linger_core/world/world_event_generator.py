from datetime import datetime, timedelta
from typing import List, Optional

from linger_core.shared.enums import (
    TimeOfDay,
    WorldEventType,
)
from linger_core.world.world_runtime_state import WorldRuntimeState
from linger_core.world.world_event_entry import WorldEventEntry
from linger_core.world.world_event_store import WorldEventStore
from linger_core.world.npc_registry import NpcRegistry
from linger_core.world.ambient_state import AmbientState
from linger_core.world.world_labels import time_zh, weather_zh, mood_zh, place_zh, activity_zh


class WorldEventGenerator:
    def __init__(
        self,
        event_store: WorldEventStore,
        npc_registry: NpcRegistry,
    ):
        self._store = event_store
        self._npcs = npc_registry

    def check_time_change(
        self,
        old_time: TimeOfDay,
        new_time: TimeOfDay,
        world_now: Optional[datetime] = None,
    ) -> Optional[WorldEventEntry]:
        if old_time == new_time:
            return None
        new_label = time_zh(new_time.value)
        title = f"时间来到{new_label}"
        summary = f"天色到了{new_label}。"
        if new_time == TimeOfDay.NIGHT:
            summary += "周围渐渐安静下来，灯一盏盏亮起来。"
        elif new_time == TimeOfDay.MORNING:
            summary += "天慢慢亮了，又是新的一天。"
        return self._store.create(
            event_type=WorldEventType.TIME_CHANGE,
            title=title,
            summary=summary,
            world_now=world_now,
            importance=0.6,
            user_relevance=0.4,
            emotional_tone="calm" if new_time in (TimeOfDay.MORNING, TimeOfDay.AFTERNOON) else "quiet",
        )

    def check_weather_change(
        self,
        old_weather: str,
        new_weather: str,
        world_now: Optional[datetime] = None,
    ) -> Optional[WorldEventEntry]:
        if old_weather == new_weather:
            return None
        new_label = weather_zh(new_weather)
        title = f"天转{new_label}"
        summary = f"天{new_label}了。"
        if new_weather == "rainy":
            summary += "成都的雨，空气里全是潮气。"
        elif new_weather == "clear":
            summary += "难得放晴，天透亮。"
        elif new_weather == "cloudy":
            summary += "又是灰蒙蒙的一天。"
        elif new_weather == "foggy":
            summary += "起雾了，远处都看不真切。"
        return self._store.create(
            event_type=WorldEventType.WEATHER_CHANGE,
            title=title,
            summary=summary,
            world_now=world_now,
            importance=0.5,
            user_relevance=0.35,
            emotional_tone="melancholy" if new_weather == "rainy" else "bright",
        )

    def check_ambient_change(
        self,
        old_mood: str,
        new_mood: str,
        place_id: str,
        world_now: Optional[datetime] = None,
    ) -> Optional[WorldEventEntry]:
        if old_mood == new_mood:
            return None
        new_label = mood_zh(new_mood)
        title = f"气氛变得{new_label}"
        summary = f"这地方的气氛{new_label}了起来。"
        return self._store.create(
            event_type=WorldEventType.PLACE_AMBIENT_CHANGE,
            title=title,
            summary=summary,
            world_now=world_now,
            place_id=place_id,
            importance=0.3,
            user_relevance=0.2,
            emotional_tone=new_mood,
        )

    def check_npc_changes(
        self,
        npc_id: str,
        old_activity: str,
        new_activity: str,
        old_place: str,
        new_place: str,
        world_now: Optional[datetime] = None,
    ) -> Optional[WorldEventEntry]:
        if old_activity == new_activity and old_place == new_place:
            return None
        npc = self._npcs.get(npc_id)
        if not npc:
            return None
        parts = []
        if old_place != new_place:
            parts.append(f"{npc.name}从{place_zh(old_place)}去了{place_zh(new_place)}")
        if old_activity != new_activity:
            parts.append(f"开始{activity_zh(new_activity)}")
        title = f"{npc.name}的活动变化"
        summary = "，".join(parts) + "。"
        return self._store.create(
            event_type=WorldEventType.NPC_ACTIVITY_CHANGE,
            title=title,
            summary=summary,
            world_now=world_now,
            place_id=new_place,
            involved_npc_ids=[npc_id],
            importance=0.5,
            user_relevance=0.45,
            emotional_tone=npc.current_mood,
        )

    def generate_user_echo(
        self,
        user_event_summary: str,
        related_npc_ids: Optional[List[str]] = None,
        world_now: Optional[datetime] = None,
    ) -> Optional[WorldEventEntry]:
        if not user_event_summary:
            return None
        title = "惦记着的事"
        summary = user_event_summary
        return self._store.create(
            event_type=WorldEventType.USER_EVENT_ECHO,
            title=title,
            summary=summary,
            world_now=world_now,
            involved_npc_ids=related_npc_ids or [],
            importance=0.7,
            user_relevance=0.8,
            emotional_tone="reflective",
        )
