"""世界内部键 → 中文展示标签的集中映射。

内部键(time_of_day / weather / mood)全程不变;凡是会进入"她能看到的文案"
(事件 summary、world_context 注入、snapshot 拍平)的地方统一经此映射成中文,
避免英文内部键裸露(穿帮)。未知键回退原值,保证不抛错。
"""
from typing import Dict, Final

TIME_ZH: Final[Dict[str, str]] = {
    "morning": "清晨",
    "afternoon": "午后",
    "evening": "傍晚",
    "night": "深夜",
}

WEATHER_ZH: Final[Dict[str, str]] = {
    "clear": "晴",
    "cloudy": "多云",
    "rainy": "雨",
    "stormy": "暴风雨",
    "foggy": "雾",
    "snowy": "雪",  # 成都极罕见,保留以防御历史/外部数据
}

MOOD_ZH: Final[Dict[str, str]] = {
    "friendly": "热络", "warm": "温和", "curious": "好奇", "cheerful": "轻快",
    "gentle": "温柔", "calm": "平静", "steady": "沉稳", "thoughtful": "若有所思",
    "quiet": "安静", "content": "满足", "lively": "活泼", "excited": "兴奋",
    "caring": "体贴", "playful": "俏皮", "fresh": "清爽", "melancholy": "有点闷",
    "tense": "紧绷", "subdued": "低沉", "neutral": "平常", "frank": "直率",
}

PLACE_ZH: Final[Dict[str, str]] = {
    "home": "合租屋",
    "cafe": "密室逃脱店",
    "street": "东郊记忆",
    "park": "城市绿道",
    "office": "配音小工作室",
}

ACTIVITY_ZH: Final[Dict[str, str]] = {
    "resting": "休息", "working": "工作中", "socializing": "社交中",
    "wandering": "闲逛", "eating": "用餐", "idle": "闲着",
}


def time_zh(key: str) -> str:
    return TIME_ZH.get(key, key)


def weather_zh(key: str) -> str:
    return WEATHER_ZH.get(key, key)


def mood_zh(key: str) -> str:
    return MOOD_ZH.get(key, key)


def place_zh(key: str) -> str:
    return PLACE_ZH.get(key, key)


def activity_zh(key: str) -> str:
    return ACTIVITY_ZH.get(key, key)
