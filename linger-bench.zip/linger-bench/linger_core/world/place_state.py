from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.core.state.base_state import BaseState
from linger_core.shared.enums import PlaceCategory


@dataclass
class PlaceState(BaseState):
    place_id: str = ""
    display_name: str = ""
    category: PlaceCategory = PlaceCategory.INDOOR_PRIVATE
    noise_level: float = 0.3
    crowding_level: float = 0.2
    comfort_level: float = 0.7
    safety_feeling: float = 0.8
    weather_exposure: float = 0.0
    tags: List[str] = field(default_factory=list)
    linked_npc_ids: List[str] = field(default_factory=list)
    description: str = ""

    def update_noise(self, level: float) -> None:
        self.noise_level = max(0.0, min(1.0, level))
        self.touch()

    def update_crowding(self, level: float) -> None:
        self.crowding_level = max(0.0, min(1.0, level))
        self.touch()

    def update_comfort(self, level: float) -> None:
        self.comfort_level = max(0.0, min(1.0, level))
        self.touch()

    def add_npc(self, npc_id: str) -> None:
        if npc_id not in self.linked_npc_ids:
            self.linked_npc_ids.append(npc_id)
        self.touch()

    def remove_npc(self, npc_id: str) -> None:
        if npc_id in self.linked_npc_ids:
            self.linked_npc_ids.remove(npc_id)
        self.touch()

    def has_tag(self, tag: str) -> bool:
        return tag in self.tags

    def add_tag(self, tag: str) -> None:
        if tag not in self.tags:
            self.tags.append(tag)
            self.touch()

    def remove_tag(self, tag: str) -> None:
        if tag in self.tags:
            self.tags.remove(tag)
            self.touch()

    def update_safety(self, level: float) -> None:
        self.safety_feeling = max(0.0, min(1.0, level))
        self.touch()

    def update_weather_exposure(self, level: float) -> None:
        self.weather_exposure = max(0.0, min(1.0, level))
        self.touch()

    def update_description(self, desc: str) -> None:
        self.description = desc
        self.touch()

    def to_dict(self) -> Dict[str, Any]:
        base = super().to_dict()
        base.update({
            "place_id": self.place_id,
            "display_name": self.display_name,
            "category": self.category.value,
            "noise_level": self.noise_level,
            "crowding_level": self.crowding_level,
            "comfort_level": self.comfort_level,
            "safety_feeling": self.safety_feeling,
            "weather_exposure": self.weather_exposure,
            "tags": self.tags,
            "linked_npc_ids": self.linked_npc_ids,
            "description": self.description,
        })
        return base


# place_id 是内部键，从不展示给用户/LLM（只 display_name 外流）。
# 现实含义映射：home=合租屋 / cafe=密室逃脱店 / office=配音小工作室 / street=东郊记忆 / park=城市绿道
DEFAULT_PLACES = [
    PlaceState(
        place_id="home",
        display_name="合租屋",
        category=PlaceCategory.INDOOR_PRIVATE,
        noise_level=0.15,
        crowding_level=0.1,
        comfort_level=0.9,
        safety_feeling=0.95,
        weather_exposure=0.0,
        tags=["private", "rest", "record"],
        description="东郊记忆旁老小区顶楼的合租单间，角落用被子搭了个录音棚，黑猫麦克风总蹲在桌下",
    ),
    PlaceState(
        place_id="cafe",
        display_name="密室逃脱店",
        category=PlaceCategory.INDOOR_PUBLIC,
        noise_level=0.55,
        crowding_level=0.6,
        comfort_level=0.5,
        safety_feeling=0.75,
        weather_exposure=0.0,
        tags=["work", "perform", "social"],
        description="她上班的密室店，黑灯瞎火、戏服厚重，旺季一天能演七八场",
    ),
    PlaceState(
        place_id="street",
        display_name="东郊记忆",
        category=PlaceCategory.OUTDOOR_URBAN,
        noise_level=0.5,
        crowding_level=0.55,
        comfort_level=0.6,
        safety_feeling=0.7,
        weather_exposure=0.7,
        tags=["art", "walk", "relax"],
        description="家旁边的文创园区，常有艺术展和Live，她爱来逛、放空",
    ),
    PlaceState(
        place_id="park",
        display_name="城市绿道",
        category=PlaceCategory.OUTDOOR_OPEN,
        noise_level=0.3,
        crowding_level=0.3,
        comfort_level=0.7,
        safety_feeling=0.75,
        weather_exposure=1.0,
        tags=["nature", "relax", "open"],
        description="成都的城市绿道，她偶尔来走走、发呆",
    ),
    PlaceState(
        place_id="office",
        display_name="配音小工作室",
        category=PlaceCategory.INDOOR_PUBLIC,
        noise_level=0.2,
        crowding_level=0.3,
        comfort_level=0.6,
        safety_feeling=0.85,
        weather_exposure=0.0,
        tags=["work", "record", "focused"],
        description="偶尔去录游戏NPC、广播剧的小工作室，安静、专注",
    ),
]
