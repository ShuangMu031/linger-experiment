from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, Optional

from linger_core.core.state.base_state import BaseState


@dataclass
class AmbientState(BaseState):
    ambient_mood: str = "calm"
    energy_level: float = 0.5
    social_density: float = 0.3
    novelty: float = 0.1
    pressure_level: float = 0.2
    last_changed_at: Optional[datetime] = None

    def update_mood(self, mood: str, world_now: Optional[datetime] = None) -> None:
        if mood != self.ambient_mood:
            self.ambient_mood = mood
            self.last_changed_at = world_now or datetime.now()
            self.touch(world_now)

    def update_energy(self, level: float) -> None:
        self.energy_level = max(0.0, min(1.0, level))
        self.touch()

    def update_social_density(self, level: float) -> None:
        self.social_density = max(0.0, min(1.0, level))
        self.touch()

    def update_pressure(self, level: float) -> None:
        self.pressure_level = max(0.0, min(1.0, level))
        self.touch()

    def to_dict(self) -> Dict[str, Any]:
        base = super().to_dict()
        base.update({
            "ambient_mood": self.ambient_mood,
            "energy_level": self.energy_level,
            "social_density": self.social_density,
            "novelty": self.novelty,
            "pressure_level": self.pressure_level,
            "last_changed_at": self.last_changed_at.isoformat() if self.last_changed_at else None,
        })
        return base
