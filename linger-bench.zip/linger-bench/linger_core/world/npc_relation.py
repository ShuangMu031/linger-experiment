from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.core.state.base_state import BaseState
from linger_core.shared.enums import NpcActivity


@dataclass
class NpcRelation:
    target_npc_id: str = ""
    familiarity: float = 0.3
    warmth: float = 0.5
    trust: float = 0.3
    awkwardness: float = 0.1
    tension: float = 0.0
    last_updated_world: Optional[datetime] = None

    def update_familiarity(self, delta: float) -> None:
        self.familiarity = max(0.0, min(1.0, self.familiarity + delta))

    def update_warmth(self, delta: float) -> None:
        self.warmth = max(0.0, min(1.0, self.warmth + delta))

    def update_trust(self, delta: float) -> None:
        self.trust = max(0.0, min(1.0, self.trust + delta))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "target_npc_id": self.target_npc_id,
            "familiarity": self.familiarity,
            "warmth": self.warmth,
            "trust": self.trust,
            "awkwardness": self.awkwardness,
            "tension": self.tension,
            "last_updated_world": self.last_updated_world.isoformat() if self.last_updated_world else None,
        }
