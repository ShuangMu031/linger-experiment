from typing import Any, Dict, List, Optional

from linger_core.world.npc_runtime_state import NpcRuntimeState, DEFAULT_NPCS
from linger_core.shared.enums import NpcActivity


class NpcRegistry:
    def __init__(self):
        self._npcs: Dict[str, NpcRuntimeState] = {}

    def initialize_defaults(self) -> None:
        for npc in DEFAULT_NPCS:
            self._npcs[npc.npc_id] = npc

    def register(self, npc: NpcRuntimeState) -> None:
        self._npcs[npc.npc_id] = npc

    def get(self, npc_id: str) -> Optional[NpcRuntimeState]:
        return self._npcs.get(npc_id)

    def get_all(self) -> List[NpcRuntimeState]:
        return list(self._npcs.values())

    def get_by_place(self, place_id: str) -> List[NpcRuntimeState]:
        return [n for n in self._npcs.values() if n.current_place_id == place_id]

    def get_by_activity(self, activity: NpcActivity) -> List[NpcRuntimeState]:
        return [n for n in self._npcs.values() if n.current_activity == activity]

    def get_available(self) -> List[NpcRuntimeState]:
        return [n for n in self._npcs.values() if n.availability >= 0.5]

    def remove(self, npc_id: str) -> bool:
        if npc_id in self._npcs:
            del self._npcs[npc_id]
            return True
        return False

    @property
    def count(self) -> int:
        return len(self._npcs)

    @property
    def active_npc_ids(self) -> List[str]:
        return list(self._npcs.keys())
