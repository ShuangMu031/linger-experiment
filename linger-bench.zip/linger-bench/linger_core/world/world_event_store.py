from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.shared.enums import WorldEventType, WorldEventStatus
from linger_core.shared.ids import generate_id
from linger_core.world.world_event_entry import WorldEventEntry


class WorldEventStore:
    def __init__(self, max_events: int = 100):
        self._events: Dict[str, WorldEventEntry] = {}
        self._max_events = max_events

    def create(
        self,
        event_type: WorldEventType,
        title: str,
        summary: str,
        world_now: Optional[datetime] = None,
        place_id: str = "",
        involved_npc_ids: Optional[List[str]] = None,
        importance: float = 0.5,
        user_relevance: float = 0.3,
        emotional_tone: str = "neutral",
        expires_at_world: Optional[datetime] = None,
    ) -> WorldEventEntry:
        entry = WorldEventEntry(
            world_event_id=f"wev_{generate_id()[:10]}",
            event_type=event_type,
            title=title,
            summary=summary,
            status=WorldEventStatus.ACTIVE,
            place_id=place_id,
            involved_npc_ids=involved_npc_ids or [],
            importance=importance,
            user_relevance=user_relevance,
            emotional_tone=emotional_tone,
            created_at_world=world_now,
            last_updated_world=world_now,
            expires_at_world=expires_at_world,
        )
        self._events[entry.world_event_id] = entry
        self._enforce_limit()
        return entry

    def get(self, world_event_id: str) -> Optional[WorldEventEntry]:
        return self._events.get(world_event_id)

    def get_active(self) -> List[WorldEventEntry]:
        return [e for e in self._events.values() if e.is_active()]

    def get_by_type(self, event_type: WorldEventType) -> List[WorldEventEntry]:
        return [e for e in self._events.values() if e.event_type == event_type and e.is_active()]

    def get_by_place(self, place_id: str) -> List[WorldEventEntry]:
        return [e for e in self._events.values() if e.place_id == place_id and e.is_active()]

    def get_high_relevance(self, min_relevance: float = 0.6) -> List[WorldEventEntry]:
        return [e for e in self.get_active() if e.user_relevance >= min_relevance]

    def get_recent(self, n: int = 5) -> List[WorldEventEntry]:
        active = self.get_active()
        active.sort(key=lambda e: e.created_at_world or datetime.min, reverse=True)
        return active[:n]

    def cool_all(self, delta: float = 0.1) -> int:
        count = 0
        for e in self._events.values():
            if e.is_active():
                e.cool_down(delta)
                count += 1
        return count

    def archive_expired(self) -> int:
        count = 0
        now = datetime.now()
        for e in list(self._events.values()):
            if e.expires_at_world and now > e.expires_at_world and e.is_active():
                e.expire()
                count += 1
        return count

    def remove(self, world_event_id: str) -> bool:
        if world_event_id in self._events:
            del self._events[world_event_id]
            return True
        return False

    def _enforce_limit(self) -> None:
        if len(self._events) <= self._max_events:
            return
        expired = [e for e in self._events.values() if e.status == WorldEventStatus.EXPIRED]
        if expired:
            expired.sort(key=lambda e: e.importance)
            for e in expired[:len(self._events) - self._max_events]:
                del self._events[e.world_event_id]

    @property
    def all_events(self) -> List[WorldEventEntry]:
        return list(self._events.values())

    @property
    def count(self) -> int:
        return len(self._events)

    @property
    def active_count(self) -> int:
        return len(self.get_active())
