from datetime import datetime
from typing import List, Optional

from linger_core.memory.event_memory_store import EventMemoryStore
from linger_core.shared.enums import EventType, EventStatus
from linger_core.world.world_event_entry import WorldEventEntry
from linger_core.world.world_event_store import WorldEventStore


class WorldEventBridge:
    MIN_USER_RELEVANCE = 0.6   # 无 config 时的兜底默认;运行时由 ProactiveConfig.world_event_bridge_min_relevance 覆盖
    MIN_IMPORTANCE = 0.5       # 同上,运行时由 world_event_bridge_min_importance 覆盖

    def __init__(
        self,
        world_store: WorldEventStore,
        event_store: EventMemoryStore,
        min_user_relevance: Optional[float] = None,
        min_importance: Optional[float] = None,
    ):
        self._world_store = world_store
        self._event_store = event_store
        self._bridged_ids: set = set()
        self._min_user_relevance = min_user_relevance if min_user_relevance is not None else self.MIN_USER_RELEVANCE
        self._min_importance = min_importance if min_importance is not None else self.MIN_IMPORTANCE

    def bridge(self, real_now: Optional[datetime] = None, world_now: Optional[datetime] = None) -> int:
        now_real = real_now or datetime.now()
        now_world = world_now or datetime.now()
        count = 0

        candidates = self._world_store.get_active()
        for we in candidates:
            if we.world_event_id in self._bridged_ids:
                continue
            if we.user_relevance < self._min_user_relevance:
                continue
            if we.importance < self._min_importance:
                continue

            existing = self._event_store.find_similar_open(
                title=we.title[:30],
                tags=["world_event", we.event_type.value],
            )
            if existing:
                self._bridged_ids.add(we.world_event_id)
                continue

            self._event_store.create(
                event_type=EventType.WORLD_EVENT,
                title=f"[世界] {we.title[:40]}",
                summary=we.summary[:120],
                real_now=now_real,
                world_now=now_world,
                importance=we.importance * 0.8,
                unresolved_score=0.0,
                emotion_label=we.emotional_tone,
                related_tags=["world_event", we.event_type.value, f"place:{we.place_id}"],
                topic_key=f"world_{we.event_type.value}",
                display_title=we.title[:25],
            )
            self._bridged_ids.add(we.world_event_id)
            count += 1

        return count

    def bridge_single(
        self,
        world_event: WorldEventEntry,
        real_now: Optional[datetime] = None,
        world_now: Optional[datetime] = None,
    ) -> bool:
        if world_event.world_event_id in self._bridged_ids:
            return False
        if world_event.user_relevance < self._min_user_relevance:
            return False
        if world_event.importance < self._min_importance:
            return False

        now_real = real_now or datetime.now()
        now_world = world_now or datetime.now()

        self._event_store.create(
            event_type=EventType.WORLD_EVENT,
            title=f"[世界] {world_event.title[:40]}",
            summary=world_event.summary[:120],
            real_now=now_real,
            world_now=now_world,
            importance=world_event.importance * 0.8,
            unresolved_score=0.0,
            emotion_label=world_event.emotional_tone,
            related_tags=["world_event", world_event.event_type.value, f"place:{world_event.place_id}"],
            topic_key=f"world_{world_event.event_type.value}",
            display_title=world_event.title[:25],
        )
        self._bridged_ids.add(world_event.world_event_id)
        return True

    def sync_bridged(self) -> None:
        active_ids = {e.world_event_id for e in self._world_store.get_active()}
        self._bridged_ids = self._bridged_ids & active_ids

    @property
    def bridged_count(self) -> int:
        return len(self._bridged_ids)
