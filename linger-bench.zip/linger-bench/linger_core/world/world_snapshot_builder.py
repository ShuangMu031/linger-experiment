from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.world.world_runtime_state import WorldRuntimeState
from linger_core.world.place_state import PlaceState
from linger_core.world.ambient_state import AmbientState
from linger_core.world.npc_registry import NpcRegistry
from linger_core.world.world_event_recall import WorldEventRecall
from linger_core.world.world_labels import time_zh, weather_zh, mood_zh


class WorldSnapshotBuilder:
    def __init__(
        self,
        world_runtime: WorldRuntimeState,
        npc_registry: NpcRegistry,
        event_recall: WorldEventRecall,
    ):
        self._world = world_runtime
        self._npcs = npc_registry
        self._recall = event_recall

    def build(self, place_registry: Optional[Dict[str, PlaceState]] = None) -> Dict[str, Any]:
        current_place = None
        if place_registry:
            current_place = place_registry.get(self._world.current_place_id)

        snapshot: Dict[str, Any] = {
            "scene": self._world.current_scene_id,
            "place": self._build_place_summary(current_place),
            "time": {
                "time_of_day": self._world.time_of_day.value,
                "day_index": self._world.day_index,
                "weather": self._world.weather,
            },
            "ambient": {
                "mood": self._world.ambient_mood,
            },
            "npcs": self._build_npc_summary(),
            "recent_events": self._recall.build_context_summary(
                place_id=self._world.current_place_id, n=3
            ),
        }
        self._world.last_world_summary = self._flatten(snapshot)
        return snapshot

    def _build_place_summary(self, place: Optional[PlaceState]) -> Dict[str, Any]:
        if not place:
            return {"id": self._world.current_place_id, "name": self._world.current_place_id}
        return {
            "id": place.place_id,
            "name": place.display_name,
            "category": place.category.value,
            "noise": place.noise_level,
            "comfort": place.comfort_level,
            "tags": place.tags,
        }

    def _build_npc_summary(self) -> List[Dict[str, Any]]:
        npcs = self._npcs.get_by_place(self._world.current_place_id)
        if not npcs:
            npcs = self._npcs.get_available()[:2]
        result = []
        for npc in npcs[:3]:
            result.append({
                "id": npc.npc_id,
                "name": npc.name,
                "role": npc.role,
                "activity": npc.current_activity.value,
                "mood": npc.current_mood,
            })
        return result

    def _flatten(self, snapshot: Dict[str, Any]) -> str:
        parts = []
        time_info = snapshot.get("time", {})
        parts.append(
            f"第{time_info.get('day_index', 1)}天 · "
            f"{time_zh(time_info.get('time_of_day', ''))} · "
            f"{weather_zh(time_info.get('weather', ''))}"
        )
        place_info = snapshot.get("place", {})
        parts.append(f"地点:{place_info.get('name', '')}")
        ambient = snapshot.get("ambient", {})
        parts.append(f"气氛:{mood_zh(ambient.get('mood', ''))}")
        npcs = snapshot.get("npcs", [])
        if npcs:
            npc_names = [n.get("name", "") for n in npcs]
            parts.append(f"附近:{','.join(npc_names)}")
        events = snapshot.get("recent_events", "")
        if events:
            parts.append(f"近期:{events[:80]}")
        return " | ".join(parts)
