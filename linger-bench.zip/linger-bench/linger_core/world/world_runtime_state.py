from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.core.state.base_state import BaseState
from linger_core.shared.enums import TimeOfDay


@dataclass
class WorldRuntimeState(BaseState):
    current_scene_id: str = "default"
    current_place_id: str = "home"
    time_of_day: TimeOfDay = TimeOfDay.MORNING
    day_index: int = 1
    weather: str = "clear"
    ambient_mood: str = "calm"
    world_flags: Dict[str, Any] = field(default_factory=dict)
    active_world_event_ids: List[str] = field(default_factory=list)
    last_world_tick_at: Optional[datetime] = None
    last_scene_change_at: Optional[datetime] = None
    last_time_change_at: Optional[datetime] = None
    last_weather_change_at: Optional[datetime] = None
    last_world_summary: str = ""

    def advance_time(self, new_time: TimeOfDay, world_now: Optional[datetime] = None) -> None:
        if new_time != self.time_of_day:
            self.time_of_day = new_time
            self.last_time_change_at = world_now or datetime.now()
            if new_time == TimeOfDay.MORNING:
                self.day_index += 1
            self.touch(world_now)

    def change_weather(self, weather: str, world_now: Optional[datetime] = None) -> None:
        if weather != self.weather:
            self.weather = weather
            self.last_weather_change_at = world_now or datetime.now()
            self.touch(world_now)

    def change_scene(self, scene_id: str, place_id: str, world_now: Optional[datetime] = None) -> None:
        self.current_scene_id = scene_id
        self.current_place_id = place_id
        self.last_scene_change_at = world_now or datetime.now()
        self.touch(world_now)

    def set_flag(self, key: str, value: Any) -> None:
        self.world_flags[key] = value
        self.touch()

    def mark_world_tick(self, world_now: Optional[datetime] = None) -> None:
        self.last_world_tick_at = world_now or datetime.now()
        self.touch(world_now)

    def to_dict(self) -> Dict[str, Any]:
        base = super().to_dict()
        base.update({
            "current_scene_id": self.current_scene_id,
            "current_place_id": self.current_place_id,
            "time_of_day": self.time_of_day.value,
            "day_index": self.day_index,
            "weather": self.weather,
            "ambient_mood": self.ambient_mood,
            "world_flags": self.world_flags,
            "active_world_event_ids": self.active_world_event_ids,
            "last_world_tick_at": self.last_world_tick_at.isoformat() if self.last_world_tick_at else None,
            "last_scene_change_at": self.last_scene_change_at.isoformat() if self.last_scene_change_at else None,
            "last_time_change_at": self.last_time_change_at.isoformat() if self.last_time_change_at else None,
            "last_weather_change_at": self.last_weather_change_at.isoformat() if self.last_weather_change_at else None,
            "last_world_summary": self.last_world_summary,
        })
        return base
