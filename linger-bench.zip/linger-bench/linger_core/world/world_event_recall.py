from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.shared.enums import WorldEventType, WorldEventStatus
from linger_core.world.world_event_entry import WorldEventEntry
from linger_core.world.world_event_store import WorldEventStore


class WorldEventRecall:
    def __init__(self, event_store: WorldEventStore):
        self._store = event_store

    def recall_recent(self, n: int = 3) -> List[WorldEventEntry]:
        return self._store.get_recent(n)

    def recall_by_place(self, place_id: str) -> List[WorldEventEntry]:
        return self._store.get_by_place(place_id)

    def recall_by_type(self, event_type: WorldEventType) -> List[WorldEventEntry]:
        return self._store.get_by_type(event_type)

    def recall_high_relevance(self, min_relevance: float = 0.6) -> List[WorldEventEntry]:
        return self._store.get_high_relevance(min_relevance)

    def recall_for_context(self, place_id: str = "", n: int = 3) -> List[WorldEventEntry]:
        candidates = self._store.get_active()
        scored: List[tuple] = []
        for e in candidates:
            score = e.importance * 0.4 + e.user_relevance * 0.6
            if place_id and e.place_id == place_id:
                score += 0.3
            scored.append((score, e))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [e for _, e in scored[:n]]

    def build_context_summary(self, place_id: str = "", n: int = 3) -> str:
        events = self.recall_for_context(place_id, n)
        if not events:
            return ""
        parts = []
        for e in events:
            parts.append(f"[{e.event_type.value}] {e.title}: {e.summary}")
        return " | ".join(parts)
