from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.shared.enums import WorldEventType, WorldEventStatus
from linger_core.shared.ids import generate_id


@dataclass
class WorldEventEntry:
    world_event_id: str = ""
    event_type: WorldEventType = WorldEventType.TIME_CHANGE
    title: str = ""
    summary: str = ""
    status: WorldEventStatus = WorldEventStatus.ACTIVE
    place_id: str = ""
    involved_npc_ids: List[str] = field(default_factory=list)
    importance: float = 0.5
    user_relevance: float = 0.3
    emotional_tone: str = "neutral"
    created_at_world: Optional[datetime] = None
    last_updated_world: Optional[datetime] = None
    expires_at_world: Optional[datetime] = None

    def cool_down(self, delta: float = 0.1) -> None:
        self.importance = max(0.0, self.importance - delta)
        if self.importance < 0.2:
            self.status = WorldEventStatus.COOLING

    def expire(self) -> None:
        self.status = WorldEventStatus.EXPIRED
        self.importance = 0.0

    def archive(self) -> None:
        self.status = WorldEventStatus.ARCHIVED

    def is_active(self) -> bool:
        return self.status in (WorldEventStatus.ACTIVE, WorldEventStatus.COOLING)

    def refresh(self, delta: float = 0.1) -> None:
        if self.status == WorldEventStatus.COOLING:
            self.importance = min(1.0, self.importance + delta)
            if self.importance >= 0.5:
                self.status = WorldEventStatus.ACTIVE

    def to_dict(self) -> Dict[str, Any]:
        return {
            "world_event_id": self.world_event_id,
            "event_type": self.event_type.value,
            "title": self.title,
            "summary": self.summary,
            "status": self.status.value,
            "place_id": self.place_id,
            "involved_npc_ids": self.involved_npc_ids,
            "importance": self.importance,
            "user_relevance": self.user_relevance,
            "emotional_tone": self.emotional_tone,
            "created_at_world": self.created_at_world.isoformat() if self.created_at_world else None,
            "last_updated_world": self.last_updated_world.isoformat() if self.last_updated_world else None,
            "expires_at_world": self.expires_at_world.isoformat() if self.expires_at_world else None,
        }
