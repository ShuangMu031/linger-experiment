# INVARIANTS — the_new_world v0.4.0a14

> **性质**：不可破坏的系统规则。  
> **违反任一条 = 架构回退承认。**

---

## 触发与消息规则

| # | 不变量 | 说明 |
|---|--------|------|
| 1 | TriggerSource 只能产出候选，不能直接发消息 | 所有输出必须经过 RuntimeOrchestrator |
| 2 | ProactiveGuard 拒绝的候选不能进入 RuntimeOrchestrator | `OutboundDispatcher` 在 `evaluate()` 返回 `allowed=False` 时即 skip |
| 3 | 没有 `should_emit=True`，就不能增加主动消息计数 | 计数在 `handle_envelope` 的 `should_emit` 后才执行 |
| 4 | Guard 负责能不能发，Planner 负责发什么 | `ProactivePlanner` 不再持有 `ProactiveGuard` |

---

## 编排规则

| # | 不变量 | 说明 |
|---|--------|------|
| 5 | RuntimeOrchestrator 不能直接跳过 ContextAssembler | 每次 `handle_envelope` 必调用 `context_assembler.build` |
| 6 | SupervisorKernel 不能另建上下文路径 | 强制依赖 `ContextBundle`，不再持 ShortTermRecall/StartupContextBuilder |
| 7 | 没有 `response_message`，就不能写 assistant memory | WritebackManager 检查 response 有效性 |
| 8 | ContextAssembler 是上下文唯一来源 | SupervisorKernel 只消费不召回 |

---

## 生成与写入规则

| # | 不变量 | 说明 |
|---|--------|------|
| 9 | ResponseBuilder 只能生成文本，不能写状态 | 所有状态写入统一由 WritebackManager 执行 |
| 10 | LLM 将来不能直接写 RuntimeState | 必须通过 ActionPlan → WritebackManager |
| 11 | 工具将来不能绕过 ActionPlan 或 ToolPlan | 工具结果必须反映在 plan 的 state_writes 中 |
| 12 | BackgroundLoop 不能直接生成用户可见文本 | 用户可见内容必须通过 OrchestratorResult 返回 |

---

## 可观测性规则

| # | 不变量 | 说明 |
|---|--------|------|
| 13 | 任意 trace 开始后都必须结束 | `start_trace` 必须有对应的 `end_trace`，异常路径用 finally |
| 14 | parent_trace_id 和 depth 必须反映真实嵌套 | `start_trace` 时填入 `current_trace().trace_id` 和栈深度 |
| 15 | WhiteboxTrace 按 trace_id 隔离 | 不再使用全局 `_active_whitebox`，所有写入绑定 trace_id |
| 16 | 异常不得静默吞掉 | `_bridge_world_events`、`_on_proactive` 异常必须记录 trace 和 debug |

---

## 人设规则

| # | 不变量 | 说明 |
|---|--------|------|
| 17 | 沈鹿溪是表达外壳，不是真实人类 | 不声称居住地、现实行动、真实关系 |
| 18 | 人格只影响语气，不影响系统权限 | 决策权在 Supervisor/ActionPlan/Guard |
| 19 | 安全问题人设降到最低 | `safety_or_crisis` 模式 intensity=0.10 |

---

## 数据规则

| # | 不变量 | 说明 |
|---|--------|------|
| 20 | turn_id 是消息事件序号 | `clock.logical.turn_id`：user event +1, assistant emit +1；一问一答=2个事件 |
| 21 | TriggerCandidate 对象化传输 | 不得转为 dict 再重建；PlanState 只存对象 |
| 22 | 主动 envelope 只由 OutboundDispatcher 创建 | `create_followup_envelope` / `create_world_event_envelope` 已从生产代码删除 |

---

## 命中后果

违反任一条不变量：
- cycle8 收口未完成，不可进入 cycle9
- 需要先补修复或补测试，再重跑全量验收
