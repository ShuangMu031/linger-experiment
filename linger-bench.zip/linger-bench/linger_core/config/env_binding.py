"""声明式环境变量 → 配置字段绑定。

为什么存在：
  原 `Startup._apply_env_to_config` 是 100+ 行手写 `if env_var: cfg.field = ...`。
  这种写法的问题不在于丑，在于每加一个新 env 变量都在邀请同类 bug：
  C12 上线时捕获到的 `OPENAI_MODEL_CHEAP` 无差别覆盖 SF 模型，就是因为
  override 漏写了 `provider == "openai"` 的过滤条件。

设计：
  每个 env→field 绑定声明为一条 `EnvBinding` 记录：
    - env_key:        从哪个环境变量读
    - target:         配置树上的目标路径（例: "llm.cheap.model"）
    - cast:           类型转换（str / int / float / bool）
    - filter_provider: 仅当 cfg.llm.provider 命中时才生效（None = 总是生效）
    - allow_empty:    True 表示空字符串也覆盖（默认 False）
    - choices:        枚举校验（仅对 str）

  应用器读 `BINDINGS` 列表，对每条做一致处理。新增 env 变量 = 新增一行声明。
  不可能再"忘了写 if 检查"——过滤条件写在声明里，不写就不存在。
"""

import os
from dataclasses import dataclass
from typing import Any, Callable, List, Optional, Tuple


@dataclass
class EnvBinding:
    env_key: str
    target: str
    cast: Callable[[str], Any] = str
    filter_provider: Optional[str] = None
    allow_empty: bool = False
    choices: Optional[Tuple[str, ...]] = None


def _to_int(v: str) -> int:
    return int(v)


def _to_float(v: str) -> float:
    return float(v)


def _to_lower_str(v: str) -> str:
    return v.lower()


def _to_bool_strict(v: str) -> Optional[bool]:
    s = v.strip().lower()
    if s in ("true", "1", "yes"):
        return True
    if s in ("false", "0", "no"):
        return False
    return None


# === 配置绑定声明 ===
# 这是项目里唯一应该手写"哪个 env 影响哪个 field"的地方。
LLM_BINDINGS: List[EnvBinding] = [
    EnvBinding("RUNTIME_MODE", "llm.runtime_mode", cast=_to_lower_str,
               choices=("dev", "prod")),

    EnvBinding("LLM_ENABLED", "llm.enabled", cast=_to_bool_strict),
    EnvBinding("LLM_PROVIDER", "llm.provider", cast=_to_lower_str,
               choices=("mock", "siliconflow", "openai", "openai_compatible")),

    EnvBinding("SILICONFLOW_BASE_URL", "llm.base_url"),
    EnvBinding("SF_TIMEOUT_SECONDS", "llm.timeout_seconds", cast=_to_int),

    EnvBinding("SF_MODEL_CHEAP", "llm.cheap.model"),
    EnvBinding("SF_MODEL_STANDARD", "llm.standard.model"),
    EnvBinding("SF_MODEL_TOP", "llm.top.model"),

    EnvBinding("SF_CHEAP_TEMPERATURE", "llm.cheap.temperature", cast=_to_float),
    EnvBinding("SF_STANDARD_TEMPERATURE", "llm.standard.temperature", cast=_to_float),
    EnvBinding("SF_TOP_TEMPERATURE", "llm.top.temperature", cast=_to_float),

    EnvBinding("SF_CHEAP_MAX_TOKENS", "llm.cheap.max_tokens", cast=_to_int),
    EnvBinding("SF_STANDARD_MAX_TOKENS", "llm.standard.max_tokens", cast=_to_int),
    EnvBinding("SF_TOP_MAX_TOKENS", "llm.top.max_tokens", cast=_to_int),

    EnvBinding("OPENAI_BASE_URL", "llm.base_url", filter_provider="openai"),
    EnvBinding("OPENAI_MODEL_CHEAP", "llm.cheap.model", filter_provider="openai"),
    EnvBinding("OPENAI_MODEL_STANDARD", "llm.standard.model", filter_provider="openai"),
    EnvBinding("OPENAI_MODEL_TOP", "llm.top.model", filter_provider="openai"),
]


# === §5.1 记忆轴 TTL / 召回偏置 ===
# 字段命名采用 hours/days/entries 直觉单位，store 层从 *_seconds property 读。
MEMORY_BINDINGS: List[EnvBinding] = [
    EnvBinding("LINGER_SHORT_TERM_TTL_HOURS",
               "memory_ttl.short_term_ttl_hours", cast=_to_float),
    EnvBinding("LINGER_SHORT_TERM_MAX_ENTRIES",
               "memory_ttl.short_term_max_entries", cast=_to_int),
    EnvBinding("LINGER_EVENT_DEFAULT_TTL_DAYS",
               "memory_ttl.event_default_ttl_days", cast=_to_float),
    EnvBinding("LINGER_ANCHOR_BUFFER_DAYS",
               "memory_ttl.anchor_buffer_days", cast=_to_float),
]


def _resolve_target(cfg: Any, dotted: str) -> Tuple[Any, str]:
    parts = dotted.split(".")
    obj = cfg
    for p in parts[:-1]:
        obj = getattr(obj, p)
    return obj, parts[-1]


def apply_bindings(cfg: Any, bindings: List[EnvBinding], env=None) -> List[str]:
    """应用一组 EnvBinding 到 cfg。返回成功应用的字段列表。"""
    env = env if env is not None else os.environ
    applied: List[str] = []

    for b in bindings:
        raw = env.get(b.env_key, "")
        if not raw and not b.allow_empty:
            continue

        if b.filter_provider is not None:
            llm_cfg = getattr(cfg, "llm", None)
            if llm_cfg is None or getattr(llm_cfg, "provider", "") != b.filter_provider:
                continue

        try:
            value = b.cast(raw)
        except (ValueError, TypeError):
            continue
        if value is None:
            continue

        if b.choices is not None and value not in b.choices:
            continue

        try:
            parent, attr = _resolve_target(cfg, b.target)
            setattr(parent, attr, value)
            applied.append(b.target)
        except AttributeError:
            continue

    return applied


def apply_special_overrides(cfg: Any, env=None) -> List[str]:
    """少数不能用纯绑定表达的复杂逻辑（保留少量例外）。"""
    env = env if env is not None else os.environ
    notes: List[str] = []

    strict_raw = env.get("STRICT_LLM_INIT", "")
    strict = _to_bool_strict(strict_raw)
    explicit_strict = strict is not None
    if explicit_strict:
        cfg.llm.strict_init = strict
        notes.append(f"strict_init={strict}")

    if cfg.llm.runtime_mode == "prod" and not explicit_strict:
        cfg.llm.strict_init = True
        notes.append("strict_init=True (forced by runtime_mode=prod)")

    sf_api_key = env.get("SILICONFLOW_API_KEY", "")
    if sf_api_key and cfg.llm.provider == "siliconflow":
        cfg.llm.api_key_env = "SILICONFLOW_API_KEY"
        notes.append("api_key_env=SILICONFLOW_API_KEY")

    openai_api_key = env.get("OPENAI_API_KEY", "")
    if openai_api_key and cfg.llm.provider == "openai":
        cfg.llm.api_key_env = "OPENAI_API_KEY"
        notes.append("api_key_env=OPENAI_API_KEY")

    return notes
