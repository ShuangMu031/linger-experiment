from dataclasses import dataclass, field
from typing import Dict, Any

from linger_core.config.memory_ttl_config import MemoryTTLConfig
from linger_core.config.proactive_config import ProactiveConfig
from linger_core.llm.llm_config import LLMConfig


@dataclass
class SystemConfig:
    system_name: str = "EmotionWorld"
    version: str = "0.4.0a14"
    debug: bool = True


@dataclass
class EmotionConfig:
    default_emotion: str = "neutral"
    default_intensity: float = 0.5
    decay_rate: float = 0.02
    min_intensity: float = 0.05
    max_intensity: float = 1.0


@dataclass
class MemoryConfig:
    short_term_ttl_seconds: float = 86400.0
    short_term_max_items: int = 50
    # E5 B+: 用户陈述事实记忆（写入+召回）总开关；OFF=现状 B0，逐字不变
    enable_user_fact_memory: bool = False


@dataclass
class WorldConfig:
    default_scene: str = "default"
    world_tick_interval_seconds: float = 60.0


@dataclass
class SessionConfig:
    idle_threshold_seconds: float = 300.0


@dataclass
class PlanConfig:
    default_plan_ttl_seconds: float = 3600.0


@dataclass
class ObservabilityConfig:
    log_level: str = "DEBUG"
    trace_enabled: bool = True
    change_log_enabled: bool = True


@dataclass
class DefaultConfig:
    system: SystemConfig = field(default_factory=SystemConfig)
    emotion: EmotionConfig = field(default_factory=EmotionConfig)
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    memory_ttl: MemoryTTLConfig = field(default_factory=MemoryTTLConfig)
    world: WorldConfig = field(default_factory=WorldConfig)
    session: SessionConfig = field(default_factory=SessionConfig)
    plan: PlanConfig = field(default_factory=PlanConfig)
    observability: ObservabilityConfig = field(default_factory=ObservabilityConfig)
    proactive: ProactiveConfig = field(default_factory=ProactiveConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)

    def to_dict(self) -> Dict[str, Any]:
        import dataclasses
        return dataclasses.asdict(self)
