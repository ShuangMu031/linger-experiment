from dataclasses import dataclass


@dataclass
class TimeConfig:
    background_tick_interval_seconds: float = 60.0
    world_time_multiplier: float = 1.0
    emotion_decay_per_second: float = 0.0003
    session_idle_threshold_seconds: float = 300.0
    short_term_memory_ttl_seconds: float = 86400.0
    plan_default_ttl_seconds: float = 3600.0
    world_update_interval_seconds: float = 600.0
