from dataclasses import dataclass


@dataclass
class ProactiveConfig:
    max_consecutive_proactive: int = 2
    max_proactive_streak: int = 3
    min_trust_for_proactive: float = 0.2
    min_seconds_since_assistant: float = 10.0
    min_user_relevance: float = 0.3
    min_recall_priority: float = 0.2
    max_recent_proactive_per_window: int = 3
    proactive_window_seconds: float = 300.0
    world_event_min_user_relevance: float = 0.4
    world_event_bridge_min_relevance: float = 0.45
    world_event_bridge_min_importance: float = 0.4
