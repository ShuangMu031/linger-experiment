"""§5.1 记忆轴 TTL 与召回偏置参数（spec §4.1）。

字段单位采用「人类直觉单位」（hours/days）以便 env 直接覆盖；
seconds property 由派生计算，store 层消费 seconds。env 前缀 LINGER_。

env 覆盖参考 env_binding.MEMORY_BINDINGS。
"""
from dataclasses import dataclass


@dataclass
class MemoryTTLConfig:
    # ─── 短期记忆 ─────────────────────────────────────
    short_term_ttl_hours: float = 24.0           # v0.5 §5.1.1：30min → 24h
    short_term_max_entries: int = 50             # 兜底（OR with TTL）

    # ─── 事件记忆 ─────────────────────────────────────
    event_default_ttl_days: float = 14.0         # v0.5 §5.1.1：24h → 14d
    anchor_buffer_days: float = 7.0              # anchor 之后再保留多久

    # ─── anchor_date 召回分段加权 ─────────────────────
    anchor_recall_window_pre_days: float = 7.0   # phase A: anchor 前 N 天 → +0.4
    anchor_recall_window_post_days: float = 14.0 # phase B: anchor 后 N 天 → +0.2
    anchor_recall_fadeout_days: float = 30.0     # phase C 末端：+0.05

    # ─── 派生 seconds（store 层消费）─────────────────
    @property
    def short_term_ttl_seconds(self) -> float:
        return self.short_term_ttl_hours * 3600.0

    @property
    def event_default_ttl_seconds(self) -> float:
        return self.event_default_ttl_days * 86400.0

    @property
    def anchor_buffer_seconds(self) -> float:
        return self.anchor_buffer_days * 86400.0
