import json
import os
from datetime import datetime
from typing import List, Optional

from linger_core.memory.memory_entry import MemoryEntry
from linger_core.memory.short_term_memory import ShortTermMemory
from linger_core.persistence.data_paths import MEMORY_DIR


class ShortTermMemoryRepository:
    def __init__(self, base_dir: str = ""):
        self._base_dir = base_dir or MEMORY_DIR
        os.makedirs(self._base_dir, exist_ok=True)

    def _session_path(self, session_id: str) -> str:
        safe_id = session_id.replace("/", "_").replace("\\", "_")
        return os.path.join(self._base_dir, f"{safe_id}.json")

    def save(self, memory: ShortTermMemory, session_id: str) -> int:
        entries_data = [e.to_dict() for e in memory.all_entries if e.is_active]
        path = self._session_path(session_id)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(entries_data, f, ensure_ascii=False, indent=2)
        return len(entries_data)

    def load(self, session_id: str) -> ShortTermMemory:
        memory = ShortTermMemory()
        path = self._session_path(session_id)
        if not os.path.exists(path):
            return memory

        with open(path, "r", encoding="utf-8") as f:
            entries_data = json.load(f)

        for d in entries_data:
            expires_at = None
            if d.get("expires_at_world"):
                expires_at = datetime.fromisoformat(d["expires_at_world"])
            entry = MemoryEntry(
                entry_id=d["entry_id"],
                turn_id=d["turn_id"],
                speaker=d["speaker"],
                message=d["message"],
                created_at_real=datetime.fromisoformat(d["created_at_real"]),
                created_at_world=datetime.fromisoformat(d["created_at_world"]),
                emotion_snapshot=d.get("emotion_snapshot", {}),
                action_plan_snapshot=d.get("action_plan_snapshot", {}),
                speak_mode=d.get("speak_mode", ""),
                followup_hook_id=d.get("followup_hook_id", ""),
                tags=d.get("tags", []),
                importance=d.get("importance", 0.5),
                is_active=d.get("is_active", True),
                expires_at_world=expires_at,
            )
            memory.add_entry(entry)

        return memory

    def exists(self, session_id: str) -> bool:
        return os.path.exists(self._session_path(session_id))

    def delete(self, session_id: str) -> bool:
        path = self._session_path(session_id)
        if os.path.exists(path):
            os.remove(path)
            return True
        return False
