import json
import os
from datetime import datetime
from typing import List, Optional

from linger_core.memory.digest_bundle import DigestBundle
from linger_core.shared.enums import DigestWindowType
from linger_core.persistence.data_paths import DIGESTS_DIR


class DigestRepository:
    def __init__(self, base_dir: str = ""):
        self._base_dir = base_dir or DIGESTS_DIR
        os.makedirs(self._base_dir, exist_ok=True)

    def _path(self, profile_id: str) -> str:
        safe_id = profile_id.replace("/", "_").replace("\\", "_")
        return os.path.join(self._base_dir, f"{safe_id}.json")

    def save(self, bundles: List[DigestBundle], profile_id: str = "default") -> int:
        all_data = [b.to_dict() for b in bundles]
        payload = {
            "metadata": {
                "profile_id": profile_id,
                "saved_at": datetime.now().isoformat(),
                "total_count": len(all_data),
            },
            "bundles": all_data,
        }
        path = self._path(profile_id)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        return len(all_data)

    def load(self, profile_id: str = "default") -> List[DigestBundle]:
        path = self._path(profile_id)
        if not os.path.exists(path):
            return []

        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)

        bundles_data = payload if isinstance(payload, list) else payload.get("bundles", [])
        results = []
        for d in bundles_data:
            bundle = self._dict_to_bundle(d)
            if bundle:
                results.append(bundle)
        return results

    def exists(self, profile_id: str = "default") -> bool:
        return os.path.exists(self._path(profile_id))

    def delete(self, profile_id: str = "default") -> bool:
        path = self._path(profile_id)
        if os.path.exists(path):
            os.remove(path)
            return True
        return False

    def _dict_to_bundle(self, d: dict) -> Optional[DigestBundle]:
        try:
            window_type = DigestWindowType(d.get("window_type", "3d"))
            start_time = datetime.fromisoformat(d.get("start_time", datetime.now().isoformat()))
            end_time = datetime.fromisoformat(d.get("end_time", datetime.now().isoformat()))
            generated_at = None
            if d.get("generated_at"):
                generated_at = datetime.fromisoformat(d["generated_at"])

            return DigestBundle(
                digest_id=d["digest_id"],
                window_type=window_type,
                start_time=start_time,
                end_time=end_time,
                main_topics=d.get("main_topics", []),
                emotion_trend=d.get("emotion_trend", {}),
                high_importance_events=d.get("high_importance_events", []),
                unresolved_events=d.get("unresolved_events", []),
                resolved_events=d.get("resolved_events", []),
                interaction_density=d.get("interaction_density", 0.0),
                relationship_trend=d.get("relationship_trend", ""),
                recommended_style=d.get("recommended_style", ""),
                recommended_openers=d.get("recommended_openers", []),
                summary_short=d.get("summary_short", ""),
                summary_full=d.get("summary_full", ""),
                source_event_ids=d.get("source_event_ids", []),
                generated_at=generated_at,
                version=d.get("version", 1),
            )
        except (ValueError, KeyError):
            return None
