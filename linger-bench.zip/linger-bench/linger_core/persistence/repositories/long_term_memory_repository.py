import json
import os
from datetime import datetime
from typing import Optional

from linger_core.memory.long_term_memory_entry import LongTermMemoryEntry
from linger_core.memory.long_term_memory_store import LongTermMemoryStore
from linger_core.shared.enums import LongTermMemoryCategory, LongTermMemoryStatus
from linger_core.persistence.data_paths import LONG_TERM_DIR


class LongTermMemoryRepository:
    def __init__(self, base_dir: str = ""):
        self._base_dir = base_dir or LONG_TERM_DIR
        os.makedirs(self._base_dir, exist_ok=True)

    def _path(self, profile_id: str) -> str:
        safe_id = profile_id.replace("/", "_").replace("\\", "_")
        return os.path.join(self._base_dir, f"{safe_id}.json")

    def save(self, store: LongTermMemoryStore, profile_id: str = "default") -> int:
        all_data = [e.to_dict() for e in store.all_entries]
        payload = {
            "metadata": {
                "profile_id": profile_id,
                "saved_at": datetime.now().isoformat(),
                "total_count": len(all_data),
            },
            "entries": all_data,
        }
        path = self._path(profile_id)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        return len(all_data)

    def load(self, profile_id: str = "default") -> LongTermMemoryStore:
        store = LongTermMemoryStore()
        path = self._path(profile_id)
        if not os.path.exists(path):
            return store

        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)

        entries_data = payload if isinstance(payload, list) else payload.get("entries", [])
        for d in entries_data:
            entry = self._dict_to_entry(d)
            if entry:
                store.add(entry)
        return store

    def exists(self, profile_id: str = "default") -> bool:
        return os.path.exists(self._path(profile_id))

    def delete(self, profile_id: str = "default") -> bool:
        path = self._path(profile_id)
        if os.path.exists(path):
            os.remove(path)
            return True
        return False

    def _dict_to_entry(self, d: dict) -> Optional[LongTermMemoryEntry]:
        try:
            category = LongTermMemoryCategory(d.get("category", "preference"))
            status = LongTermMemoryStatus(d.get("status", "tentative"))

            first_seen_real = None
            if d.get("first_seen_real"):
                first_seen_real = datetime.fromisoformat(d["first_seen_real"])

            last_seen_real = None
            if d.get("last_seen_real"):
                last_seen_real = datetime.fromisoformat(d["last_seen_real"])

            last_confirmed_real = None
            if d.get("last_confirmed_real"):
                last_confirmed_real = datetime.fromisoformat(d["last_confirmed_real"])

            last_used_real = None
            if d.get("last_used_real"):
                last_used_real = datetime.fromisoformat(d["last_used_real"])

            return LongTermMemoryEntry(
                memory_id=d["memory_id"],
                category=category,
                key=d.get("key", ""),
                value=d.get("value", ""),
                summary=d.get("summary", ""),
                confidence=d.get("confidence", 0.5),
                stability=d.get("stability", 0.5),
                importance=d.get("importance", 0.5),
                visibility=d.get("visibility", "system"),
                source_event_ids=d.get("source_event_ids", []),
                source_digest_ids=d.get("source_digest_ids", []),
                first_seen_real=first_seen_real,
                last_seen_real=last_seen_real,
                last_confirmed_real=last_confirmed_real,
                last_used_real=last_used_real,
                confirm_count=d.get("confirm_count", 0),
                contradict_count=d.get("contradict_count", 0),
                status=status,
                decay_policy=d.get("decay_policy", "normal"),
                tags=d.get("tags", []),
            )
        except (ValueError, KeyError):
            return None
