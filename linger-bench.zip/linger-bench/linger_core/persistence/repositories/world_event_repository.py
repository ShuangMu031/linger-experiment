import json
import os
from datetime import datetime
from typing import List, Optional

from linger_core.world.world_event_entry import WorldEventEntry
from linger_core.world.world_event_store import WorldEventStore
from linger_core.shared.enums import WorldEventType, WorldEventStatus
from linger_core.persistence.data_paths import WORLD_EVENTS_DIR


class WorldEventRepository:
    def __init__(self, base_dir: str = ""):
        self._base_dir = base_dir or WORLD_EVENTS_DIR
        os.makedirs(self._base_dir, exist_ok=True)

    def _path(self, conversation_id: str) -> str:
        safe_id = conversation_id.replace("/", "_").replace("\\", "_")
        return os.path.join(self._base_dir, f"wev_{safe_id}.json")

    def save(self, store: WorldEventStore, conversation_id: str = "default") -> int:
        all_data = [e.to_dict() for e in store.all_events]
        payload = {
            "metadata": {
                "conversation_id": conversation_id,
                "saved_at": datetime.now().isoformat(),
                "total_count": len(all_data),
            },
            "events": all_data,
        }
        path = self._path(conversation_id)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        return len(all_data)

    def load(self, conversation_id: str = "default") -> WorldEventStore:
        store = WorldEventStore()
        path = self._path(conversation_id)
        if not os.path.exists(path):
            return store
        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)
        events_data = payload if isinstance(payload, list) else payload.get("events", [])
        for d in events_data:
            entry = self._dict_to_entry(d)
            if entry:
                store._events[entry.world_event_id] = entry
        return store

    def _dict_to_entry(self, d: dict) -> Optional[WorldEventEntry]:
        try:
            entry = WorldEventEntry(
                world_event_id=d.get("world_event_id", ""),
                event_type=WorldEventType(d.get("event_type", "time_change")),
                title=d.get("title", ""),
                summary=d.get("summary", ""),
                status=WorldEventStatus(d.get("status", "active")),
                place_id=d.get("place_id", ""),
                involved_npc_ids=d.get("involved_npc_ids", []),
                importance=d.get("importance", 0.5),
                user_relevance=d.get("user_relevance", 0.3),
                emotional_tone=d.get("emotional_tone", "neutral"),
            )
            if d.get("created_at_world"):
                entry.created_at_world = datetime.fromisoformat(d["created_at_world"])
            if d.get("last_updated_world"):
                entry.last_updated_world = datetime.fromisoformat(d["last_updated_world"])
            if d.get("expires_at_world"):
                entry.expires_at_world = datetime.fromisoformat(d["expires_at_world"])
            return entry
        except (ValueError, KeyError):
            return None

    def exists(self, conversation_id: str = "default") -> bool:
        return os.path.exists(self._path(conversation_id))

    def delete(self, conversation_id: str = "default") -> bool:
        path = self._path(conversation_id)
        if os.path.exists(path):
            os.remove(path)
            return True
        return False
