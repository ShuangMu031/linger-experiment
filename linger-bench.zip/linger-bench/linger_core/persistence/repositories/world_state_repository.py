import json
import os
from datetime import datetime
from typing import Optional

from linger_core.world.world_runtime_state import WorldRuntimeState
from linger_core.world.ambient_state import AmbientState
from linger_core.shared.enums import TimeOfDay
from linger_core.persistence.data_paths import WORLD_DIR


class WorldStateRepository:
    def __init__(self, base_dir: str = ""):
        self._base_dir = base_dir or WORLD_DIR
        os.makedirs(self._base_dir, exist_ok=True)

    def _path(self, conversation_id: str) -> str:
        safe_id = conversation_id.replace("/", "_").replace("\\", "_")
        return os.path.join(self._base_dir, f"world_{safe_id}.json")

    def save(
        self,
        world_runtime: WorldRuntimeState,
        ambient_state: AmbientState,
        conversation_id: str = "default",
    ) -> bool:
        payload = {
            "metadata": {
                "conversation_id": conversation_id,
                "saved_at": datetime.now().isoformat(),
            },
            "world_runtime": world_runtime.to_dict(),
            "ambient_state": ambient_state.to_dict(),
        }
        path = self._path(conversation_id)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        return True

    def load(self, conversation_id: str = "default") -> Optional[dict]:
        path = self._path(conversation_id)
        if not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def restore_runtime(self, data: dict) -> WorldRuntimeState:
        wr = data.get("world_runtime", {})
        state = WorldRuntimeState()
        state.current_scene_id = wr.get("current_scene_id", "default")
        state.current_place_id = wr.get("current_place_id", "home")
        state.time_of_day = TimeOfDay(wr.get("time_of_day", "morning"))
        state.day_index = wr.get("day_index", 1)
        state.weather = wr.get("weather", "clear")
        state.ambient_mood = wr.get("ambient_mood", "calm")
        state.world_flags = wr.get("world_flags", {})
        state.active_world_event_ids = wr.get("active_world_event_ids", [])
        if wr.get("last_world_tick_at"):
            state.last_world_tick_at = datetime.fromisoformat(wr["last_world_tick_at"])
        if wr.get("last_scene_change_at"):
            state.last_scene_change_at = datetime.fromisoformat(wr["last_scene_change_at"])
        if wr.get("last_time_change_at"):
            state.last_time_change_at = datetime.fromisoformat(wr["last_time_change_at"])
        if wr.get("last_weather_change_at"):
            state.last_weather_change_at = datetime.fromisoformat(wr["last_weather_change_at"])
        state.last_world_summary = wr.get("last_world_summary", "")
        return state

    def restore_ambient(self, data: dict) -> AmbientState:
        ar = data.get("ambient_state", {})
        state = AmbientState()
        state.ambient_mood = ar.get("ambient_mood", "calm")
        state.energy_level = ar.get("energy_level", 0.5)
        state.social_density = ar.get("social_density", 0.3)
        state.novelty = ar.get("novelty", 0.1)
        state.pressure_level = ar.get("pressure_level", 0.2)
        if ar.get("last_changed_at"):
            state.last_changed_at = datetime.fromisoformat(ar["last_changed_at"])
        return state

    def exists(self, conversation_id: str = "default") -> bool:
        return os.path.exists(self._path(conversation_id))

    def delete(self, conversation_id: str = "default") -> bool:
        path = self._path(conversation_id)
        if os.path.exists(path):
            os.remove(path)
            return True
        return False
