import json
import os
from datetime import datetime
from typing import Dict, List, Optional

from linger_core.world.npc_runtime_state import NpcRuntimeState
from linger_core.world.npc_relation import NpcRelation
from linger_core.shared.enums import NpcActivity
from linger_core.persistence.data_paths import NPCS_DIR


class NpcRepository:
    def __init__(self, base_dir: str = ""):
        self._base_dir = base_dir or NPCS_DIR
        os.makedirs(self._base_dir, exist_ok=True)

    def _path(self, conversation_id: str) -> str:
        safe_id = conversation_id.replace("/", "_").replace("\\", "_")
        return os.path.join(self._base_dir, f"npcs_{safe_id}.json")

    def save(self, npcs: List[NpcRuntimeState], conversation_id: str = "default") -> int:
        all_data = [n.to_dict() for n in npcs]
        payload = {
            "metadata": {
                "conversation_id": conversation_id,
                "saved_at": datetime.now().isoformat(),
                "total_count": len(all_data),
            },
            "npcs": all_data,
        }
        path = self._path(conversation_id)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        return len(all_data)

    def load(self, conversation_id: str = "default") -> List[NpcRuntimeState]:
        path = self._path(conversation_id)
        if not os.path.exists(path):
            return []
        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)
        npcs_data = payload if isinstance(payload, list) else payload.get("npcs", [])
        results = []
        for d in npcs_data:
            npc = self._dict_to_npc(d)
            if npc:
                results.append(npc)
        return results

    def _dict_to_npc(self, d: dict) -> Optional[NpcRuntimeState]:
        try:
            npc = NpcRuntimeState(
                npc_id=d.get("npc_id", ""),
                name=d.get("name", ""),
                role=d.get("role", ""),
                current_place_id=d.get("current_place_id", "home"),
                current_activity=NpcActivity(d.get("current_activity", "idle")),
                current_mood=d.get("current_mood", "neutral"),
                energy=d.get("energy", 0.7),
                availability=d.get("availability", 0.8),
                favorability_to_user=d.get("favorability_to_user", 0.5),
                closeness_to_user=d.get("closeness_to_user", 0.3),
                personality_traits=d.get("personality_traits", []),
                description=d.get("description", ""),
            )
            if d.get("last_seen_world"):
                npc.last_seen_world = datetime.fromisoformat(d["last_seen_world"])
            if d.get("last_interaction_world"):
                npc.last_interaction_world = datetime.fromisoformat(d["last_interaction_world"])
            for k, v in d.get("npc_relations", {}).items():
                npc.npc_relations[k] = NpcRelation(
                    target_npc_id=v.get("target_npc_id", k),
                    familiarity=v.get("familiarity", 0.3),
                    warmth=v.get("warmth", 0.5),
                    trust=v.get("trust", 0.3),
                    awkwardness=v.get("awkwardness", 0.1),
                    tension=v.get("tension", 0.0),
                )
            return npc
        except (ValueError, KeyError):
            return None

    def exists(self, conversation_id: str = "default") -> bool:
        return os.path.exists(self._path(conversation_id))

    def delete(self, conversation_id: str = "default") -> bool:
        path = self._path(conversation_id)
        if os.path.exists(path):
            os.remove(path)
            return True
        return False
