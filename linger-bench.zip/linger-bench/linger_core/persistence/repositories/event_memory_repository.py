import json
import os
from datetime import datetime
from typing import Optional

from linger_core.memory.event_memory_entry import EventMemoryEntry
from linger_core.memory.event_memory_store import EventMemoryStore
from linger_core.shared.enums import EventStatus, EventType
from linger_core.persistence.data_paths import EVENTS_DIR


class EventMemoryRepository:
    def __init__(self, base_dir: str = ""):
        self._base_dir = base_dir or EVENTS_DIR
        os.makedirs(self._base_dir, exist_ok=True)

    def _conversation_path(self, conversation_id: str) -> str:
        safe_id = conversation_id.replace("/", "_").replace("\\", "_")
        return os.path.join(self._base_dir, f"{safe_id}.json")

    def save(self, store: EventMemoryStore, conversation_id: str, session_id: str = "", top_event_id: str = "") -> int:
        active_data = [e.to_dict() for e in store.all_events if e.is_active()]
        resolved_data = [e.to_dict() for e in store.get_by_status(EventStatus.RESOLVED)]
        archived_data = [e.to_dict() for e in store.get_by_status(EventStatus.ARCHIVED)]

        payload = {
            "metadata": {
                "conversation_id": conversation_id,
                "session_id": session_id,
                "saved_at": datetime.now().isoformat(),
                "top_event_id": top_event_id,
                "active_count": len(active_data),
                "resolved_count": len(resolved_data),
                "archived_count": len(archived_data),
            },
            "active_events": active_data,
            "resolved_events": resolved_data,
            "archived_events": archived_data,
        }

        path = self._conversation_path(conversation_id)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        return len(active_data) + len(resolved_data) + len(archived_data)

    def load(self, conversation_id: str) -> EventMemoryStore:
        store = EventMemoryStore()
        path = self._conversation_path(conversation_id)
        if not os.path.exists(path):
            return store

        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)

        if isinstance(payload, list):
            for d in payload:
                event = self._dict_to_event(d)
                if event:
                    store.add(event)
            return store

        for key in ("active_events", "resolved_events", "archived_events"):
            events_data = payload.get(key, [])
            for d in events_data:
                event = self._dict_to_event(d)
                if event:
                    store.add(event)

        return store

    def exists(self, conversation_id: str) -> bool:
        return os.path.exists(self._conversation_path(conversation_id))

    def delete(self, conversation_id: str) -> bool:
        path = self._conversation_path(conversation_id)
        if os.path.exists(path):
            os.remove(path)
            return True
        return False

    def _dict_to_event(self, d: dict) -> Optional[EventMemoryEntry]:
        try:
            event_type = EventType(d.get("event_type", "high_emotion"))
            status = EventStatus(d.get("status", "open"))

            first_seen_real = None
            if d.get("first_seen_real"):
                first_seen_real = datetime.fromisoformat(d["first_seen_real"])

            first_seen_world = None
            if d.get("first_seen_world"):
                first_seen_world = datetime.fromisoformat(d["first_seen_world"])

            last_seen_real = None
            if d.get("last_seen_real"):
                last_seen_real = datetime.fromisoformat(d["last_seen_real"])

            last_seen_world = None
            if d.get("last_seen_world"):
                last_seen_world = datetime.fromisoformat(d["last_seen_world"])

            event = EventMemoryEntry(
                event_id=d["event_id"],
                event_type=event_type,
                title=d.get("title", ""),
                summary=d.get("summary", ""),
                status=status,
                participants=d.get("participants", ["user", "assistant"]),
                source_entry_ids=d.get("source_entry_ids", []),
                source_turn_ids=d.get("source_turn_ids", []),
                first_seen_real=first_seen_real,
                first_seen_world=first_seen_world,
                last_seen_real=last_seen_real,
                last_seen_world=last_seen_world,
                emotion_label=d.get("emotion_label", ""),
                emotion_peak=d.get("emotion_peak", 0.0),
                importance=d.get("importance", 0.5),
                unresolved_score=d.get("unresolved_score", 0.0),
                mention_count=d.get("mention_count", 1),
                followup_hook_ids=d.get("followup_hook_ids", []),
                related_tags=d.get("related_tags", []),
                last_user_message=d.get("last_user_message", ""),
                last_assistant_message=d.get("last_assistant_message", ""),
                resolution_hint=d.get("resolution_hint", ""),
                is_user_core_event=d.get("is_user_core_event", False),
                continuity_score=d.get("continuity_score", 0.5),
                recall_priority=d.get("recall_priority", 0.5),
                topic_key=d.get("topic_key", ""),
                topic_summary=d.get("topic_summary", ""),
                parent_event_id=d.get("parent_event_id", ""),
                display_title=d.get("display_title", ""),
                merge_count=d.get("merge_count", 0),
            )

            resolved_at_real = None
            if d.get("resolved_at_real"):
                resolved_at_real = datetime.fromisoformat(d["resolved_at_real"])

            resolved_at_world = None
            if d.get("resolved_at_world"):
                resolved_at_world = datetime.fromisoformat(d["resolved_at_world"])

            archived_at_real = None
            if d.get("archived_at_real"):
                archived_at_real = datetime.fromisoformat(d["archived_at_real"])

            event.resolved_at_real = resolved_at_real
            event.resolved_at_world = resolved_at_world
            event.archived_at_real = archived_at_real

            # T3: anchor_date / expire_at（§5.1.2）
            if d.get("anchor_date"):
                event.anchor_date = datetime.fromisoformat(d["anchor_date"])
            if d.get("expire_at"):
                event.expire_at = datetime.fromisoformat(d["expire_at"])
            return event
        except (ValueError, KeyError):
            return None
