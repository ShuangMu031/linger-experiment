import json
import os
from datetime import datetime
from typing import Optional

from linger_core.memory.profile_snapshot import ProfileSnapshot
from linger_core.shared.ids import generate_id
from linger_core.persistence.data_paths import PROFILES_DIR


class ProfileRepository:
    def __init__(self, base_dir: str = ""):
        self._base_dir = base_dir or PROFILES_DIR
        os.makedirs(self._base_dir, exist_ok=True)

    def _path(self, profile_id: str) -> str:
        safe_id = profile_id.replace("/", "_").replace("\\", "_")
        return os.path.join(self._base_dir, f"{safe_id}.json")

    def save(self, snapshot: ProfileSnapshot, profile_id: str = "default") -> bool:
        if not snapshot.profile_id:
            snapshot.profile_id = f"prof_{generate_id()[:10]}"
        payload = snapshot.to_dict()
        path = self._path(profile_id)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        return True

    def load(self, profile_id: str = "default") -> Optional[ProfileSnapshot]:
        path = self._path(profile_id)
        if not os.path.exists(path):
            return None

        with open(path, "r", encoding="utf-8") as f:
            d = json.load(f)

        try:
            snapshot = ProfileSnapshot(
                profile_id=d.get("profile_id", ""),
                communication_preferences=d.get("communication_preferences", {}),
                emotion_baseline=d.get("emotion_baseline", {}),
                topic_distribution=d.get("topic_distribution", {}),
                relationship_profile=d.get("relationship_profile", {}),
                recent_risk_flags=d.get("recent_risk_flags", []),
                source_memory_ids=d.get("source_memory_ids", []),
                source_digest_ids=d.get("source_digest_ids", []),
                version=d.get("version", 1),
            )
            if d.get("created_at"):
                snapshot.created_at = datetime.fromisoformat(d["created_at"])
            if d.get("updated_at"):
                snapshot.updated_at = datetime.fromisoformat(d["updated_at"])
            return snapshot
        except (ValueError, KeyError):
            return None

    def exists(self, profile_id: str = "default") -> bool:
        return os.path.exists(self._path(profile_id))

    def delete(self, profile_id: str = "default") -> bool:
        path = self._path(profile_id)
        if os.path.exists(path):
            os.remove(path)
            return True
        return False
