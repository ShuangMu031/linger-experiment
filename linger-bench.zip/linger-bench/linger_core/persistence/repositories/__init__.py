from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class BaseRepository(ABC):
    @abstractmethod
    def save(self, key: str, data: Dict[str, Any]) -> None:
        pass

    @abstractmethod
    def load(self, key: str) -> Optional[Dict[str, Any]]:
        pass

    @abstractmethod
    def delete(self, key: str) -> bool:
        pass

    @abstractmethod
    def list_keys(self) -> List[str]:
        pass


class InMemoryRepository(BaseRepository):
    def __init__(self):
        self._store: Dict[str, Dict[str, Any]] = {}

    def save(self, key: str, data: Dict[str, Any]) -> None:
        self._store[key] = data

    def load(self, key: str) -> Optional[Dict[str, Any]]:
        return self._store.get(key)

    def delete(self, key: str) -> bool:
        if key in self._store:
            del self._store[key]
            return True
        return False

    def list_keys(self) -> List[str]:
        return list(self._store.keys())
