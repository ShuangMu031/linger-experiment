# LEGACY: cycle7-8 persistence snapshot prototype.
# This module is NOT wired into the main runtime chain.
# Retained as future reference for cycle11 persistence engineering.
#
# Current main chain uses persistence/repositories/*.py
# Do not add new code that depends on SnapshotManager.

from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.persistence.repositories import InMemoryRepository
from linger_core.persistence.serializers import JsonSerializer


class SnapshotManager:
    def __init__(self):
        self._repo = InMemoryRepository()
        self._serializer = JsonSerializer()

    def save_snapshot(self, name: str, state_dict: Dict[str, Any]) -> None:
        snapshot = {
            "name": name,
            "saved_at": datetime.now().isoformat(),
            "data": state_dict,
        }
        self._repo.save(f"snapshot:{name}", snapshot)

    def load_snapshot(self, name: str) -> Optional[Dict[str, Any]]:
        snapshot = self._repo.load(f"snapshot:{name}")
        if snapshot:
            return snapshot.get("data")
        return None

    def list_snapshots(self) -> List[str]:
        keys = self._repo.list_keys()
        return [k.replace("snapshot:", "") for k in keys if k.startswith("snapshot:")]

    def delete_snapshot(self, name: str) -> bool:
        return self._repo.delete(f"snapshot:{name}")
