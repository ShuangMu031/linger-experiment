from abc import ABC, abstractmethod
from typing import Any, Dict


class BaseSerializer(ABC):
    @abstractmethod
    def serialize(self, obj: Any) -> str:
        pass

    @abstractmethod
    def deserialize(self, data: str) -> Any:
        pass


class JsonSerializer(BaseSerializer):
    def serialize(self, obj: Any) -> str:
        import json
        return json.dumps(obj, default=str, ensure_ascii=False)

    def deserialize(self, data: str) -> Any:
        import json
        return json.loads(data)
