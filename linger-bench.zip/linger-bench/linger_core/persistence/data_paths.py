import os

DATA_ROOT = os.environ.get("THE_NEW_WORLD_DATA_DIR", ".data")

MEMORY_DIR = os.path.join(DATA_ROOT, "memory")
EVENTS_DIR = os.path.join(DATA_ROOT, "events")
LONG_TERM_DIR = os.path.join(DATA_ROOT, "long_term")
DIGESTS_DIR = os.path.join(DATA_ROOT, "digests")
PROFILES_DIR = os.path.join(DATA_ROOT, "profiles")
WORLD_DIR = os.path.join(DATA_ROOT, "world")
NPCS_DIR = os.path.join(DATA_ROOT, "npcs")
WORLD_EVENTS_DIR = os.path.join(DATA_ROOT, "world_events")
TRACES_DIR = os.path.join(DATA_ROOT, "traces")
BAD_CASES_DIR = os.path.join(DATA_ROOT, "bad_cases")
HEALTH_DIR = os.path.join(DATA_ROOT, "health")
DIGESTS_WEEKLY_DIR = os.path.join(DATA_ROOT, "digests", "weekly")

ALL_DIRS = [
    MEMORY_DIR,
    EVENTS_DIR,
    LONG_TERM_DIR,
    DIGESTS_DIR,
    PROFILES_DIR,
    WORLD_DIR,
    NPCS_DIR,
    WORLD_EVENTS_DIR,
    TRACES_DIR,
    BAD_CASES_DIR,
    HEALTH_DIR,
    DIGESTS_WEEKLY_DIR,
]


def ensure_dirs() -> None:
    for d in ALL_DIRS:
        os.makedirs(d, exist_ok=True)
