from typing import TYPE_CHECKING, List

from linger_core.shared.enums import EventStatus
from linger_core.triggers.trigger_candidate import (
    TriggerCandidate,
    TriggerSourceType,
    make_candidate_id,
)
from linger_core.triggers.trigger_registry import TriggerSource

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


class EventTriggerSource(TriggerSource):

    def source_type(self) -> str:
        return "unresolved_event"

    def collect(self, view: "RuntimeStateView") -> List[TriggerCandidate]:
        candidates: List[TriggerCandidate] = []
        real_now = view.clock.real_now_time()
        world_now = view.clock.world_now_time()

        active_events = view.memory.events.active()

        for evt in active_events:
            if evt.status not in (EventStatus.OPEN, EventStatus.COOLED):
                continue

            if evt.recall_priority < 0.3:
                continue

            if evt.unresolved_score < 0.3 and evt.status != EventStatus.OPEN:
                continue

            style = "gentle"
            goal = "unfinished_thread_ping"
            if evt.emotion_label in ("sad", "angry", "anxious") and evt.emotion_peak > 0.6:
                style = "gentle"
                goal = "supportive_presence"
            elif evt.unresolved_score >= 0.5:
                style = "warm"
                goal = "unfinished_thread_ping"

            candidate = TriggerCandidate(
                candidate_id=make_candidate_id(),
                source_type=TriggerSourceType.UNRESOLVED_EVENT,
                source_id=evt.event_id,
                reason=f"unresolved: {evt.title[:100]}",
                created_at_real=real_now,
                created_at_world=world_now,
                priority=0.3 + evt.recall_priority * 0.4,
                user_relevance=0.6 if evt.is_user_core_event else 0.4,
                confidence=0.4 + evt.unresolved_score * 0.3,
                related_event_id=evt.event_id,
                payload={
                    "event_type": evt.event_type.value,
                    "unresolved_score": evt.unresolved_score,
                    "recall_priority": evt.recall_priority,
                    "emotion_label": evt.emotion_label,
                    "emotion_peak": evt.emotion_peak,
                    "topic_key": evt.topic_key,
                },
                tags=["unresolved_event", evt.event_type.value],
                proactive_goal=goal,
                suggested_style=style,
            )
            candidates.append(candidate)

        return candidates
