from typing import TYPE_CHECKING, List

from linger_core.supervisor.followup_hook import check_followup_conditions
from linger_core.triggers.trigger_candidate import (
    TriggerCandidate,
    TriggerSourceType,
    make_candidate_id,
)
from linger_core.triggers.trigger_registry import TriggerSource

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


class FollowupTriggerSource(TriggerSource):

    def source_type(self) -> str:
        return "followup"

    def collect(self, view: "RuntimeStateView") -> List[TriggerCandidate]:
        candidates: List[TriggerCandidate] = []
        world_now = view.clock.world_now_time()
        real_now = view.clock.real_now_time()

        eligible = view.plan.check_eligible_followups(world_now)

        for hook in eligible:
            if not check_followup_conditions(hook, view):
                hook.mark_cancelled("conditions_not_met")
                continue

            hook.mark_fired()

            goal_map = {
                "gentle_check_in": "gentle_check_in",
                "soft_followup": "unfinished_thread_ping",
                "warm_check": "gentle_check_in",
                "quiet_companion": "supportive_presence",
                "light_followup": "unfinished_thread_ping",
                "reconnect": "reconnect",
                "plan_reminder": "light_plan_reminder",
            }

            style_map = {
                "gentle_check_in": "gentle",
                "soft_followup": "warm",
                "warm_check": "warm",
                "quiet_companion": "gentle",
                "light_followup": "warm",
                "reconnect": "warm",
                "plan_reminder": "neutral",
            }

            candidate = TriggerCandidate(
                candidate_id=make_candidate_id(),
                source_type=TriggerSourceType.FOLLOWUP,
                source_id=hook.hook_id,
                reason=hook.reason[:200],
                created_at_real=real_now,
                created_at_world=world_now,
                priority=0.6,
                user_relevance=0.7,
                confidence=0.6,
                related_followup_hook_id=hook.hook_id,
                payload={
                    "hook_type": hook.hook_type,
                    "source_turn_id": hook.source_turn_id,
                },
                tags=["followup", hook.hook_type],
                proactive_goal=goal_map.get(hook.hook_type, "gentle_check_in"),
                suggested_style=style_map.get(hook.hook_type, "warm"),
            )
            candidates.append(candidate)

        return candidates
