from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, List

from linger_core.core.observability.trace_store import TraceStore
from linger_core.triggers.trigger_candidate import TriggerCandidate

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


class TriggerSource(ABC):
    @abstractmethod
    def source_type(self) -> str:
        ...

    @abstractmethod
    def collect(self, view: "RuntimeStateView") -> List[TriggerCandidate]:
        ...


class TriggerRegistry:
    def __init__(self, trace_store: TraceStore = None) -> None:
        self._sources: List[TriggerSource] = []
        self._trace_store = trace_store

    def register(self, source: TriggerSource) -> None:
        self._sources.append(source)

    def collect_all(self, view: "RuntimeStateView") -> List[TriggerCandidate]:
        candidates: List[TriggerCandidate] = []
        for source in self._sources:
            try:
                batch = source.collect(view)
                candidates.extend(batch)
            except Exception as e:
                if self._trace_store is not None:
                    self._trace_store.add_step({
                        "step": "trigger_source_error",
                        "source_type": source.source_type(),
                        "error": str(e),
                    })
        candidates.sort(key=lambda c: c.priority, reverse=True)
        return candidates

    @property
    def source_count(self) -> int:
        return len(self._sources)

    @property
    def source_types(self) -> List[str]:
        return [s.source_type() for s in self._sources]
