from typing import TYPE_CHECKING, List

from linger_core.triggers.trigger_candidate import (
    TriggerCandidate,
    TriggerSourceType,
    make_candidate_id,
)
from linger_core.triggers.trigger_registry import TriggerSource

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


class WorldTriggerSource(TriggerSource):

    def source_type(self) -> str:
        return "world_event"

    def collect(self, view: "RuntimeStateView") -> List[TriggerCandidate]:
        candidates: List[TriggerCandidate] = []

        real_now = view.clock.real_now_time()
        world_now = view.clock.world_now_time()
        active_events = view.world.world_events_active()

        for we in active_events:
            # 仅过滤极低噪音;主动开口的真正门槛由 ProactiveGuard.world_event_min_user_relevance 把关
            if we.user_relevance < 0.1:
                continue

            style_map = {
                "weather_change": "warm",
                "time_change": "neutral",
                "npc_activity_change": "casual",
                "place_ambient_change": "warm",
                "user_event_echo": "gentle",
            }

            goal_map = {
                "weather_change": "world_observation",
                "time_change": "world_observation",
                "npc_activity_change": "world_observation",
                "place_ambient_change": "world_observation",
                "user_event_echo": "unfinished_thread_ping",
            }

            event_type_str = we.event_type.value

            candidate = TriggerCandidate(
                candidate_id=make_candidate_id(),
                source_type=TriggerSourceType.WORLD_EVENT,
                source_id=we.world_event_id,
                reason=we.title[:200],
                created_at_real=real_now,
                created_at_world=world_now,
                priority=0.4 + we.importance * 0.3,
                user_relevance=we.user_relevance,
                confidence=0.5,
                related_world_event_id=we.world_event_id,
                payload={
                    "event_type": event_type_str,
                    "place_id": we.place_id,
                    "importance": we.importance,
                    "emotional_tone": we.emotional_tone,
                },
                tags=["world_event", event_type_str],
                proactive_goal=goal_map.get(event_type_str, "world_observation"),
                suggested_style=style_map.get(event_type_str, "neutral"),
            )
            candidates.append(candidate)

        return candidates
