"""InnerImpulseTriggerSource — 第 7 个 trigger source（spec §4.7）。

她的"想找你"的内在冲动一旦累积到阈值且作息合适，就产 1 个 candidate。

约束：
- 隐性开关 enabled 默认 OFF（不暴露给终端用户）
- 即使 ON，最少间隔 2h（min_interval_seconds）
- pressure ≥ pressure_threshold 才产
- 深夜禁（forbidden_phases）；attention[0].intensity ≥ override_threshold 可破禁
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, List, Tuple

from linger_core.core.emotion.emotion_dimensions import EmotionDimension
from linger_core.core.state.inner_life_state import CircadianPhase
from linger_core.triggers.trigger_candidate import (
    TriggerCandidate,
    TriggerSourceType,
    make_candidate_id,
)
from linger_core.triggers.trigger_registry import TriggerSource

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


@dataclass(frozen=True)
class InnerImpulseConfig:
    enabled: bool = False                      # 隐性开关，默认 OFF
    min_interval_seconds: int = 7200           # 2 小时硬节流
    pressure_threshold: int = 70
    forbidden_phases: Tuple[CircadianPhase, ...] = (CircadianPhase.LATE_NIGHT,)
    attention_override_threshold: int = 90     # attention 强度足够可破深夜禁


_CONCERN_DIMS = (EmotionDimension.SADNESS, EmotionDimension.FEAR)


def _pick_proactive_goal(attention_focus: List[dict]) -> str:
    """根据 attention 状态决定 inner_impulse goal。"""
    if not attention_focus:
        return "open_chat"
    top = attention_focus[0]
    dim_str = top.get("dominant_emotion", "")
    intensity = int(top.get("intensity", 0) or 0)
    if intensity >= 60 and dim_str in {d.value for d in _CONCERN_DIMS}:
        return "express_concern"
    return "share_with_friend"


class InnerImpulseTriggerSource(TriggerSource):
    def __init__(self, config: InnerImpulseConfig) -> None:
        self._config = config

    def source_type(self) -> str:
        return "inner_impulse"

    def collect(self, view: "RuntimeStateView") -> List[TriggerCandidate]:
        cfg = self._config

        # 1. 开关 OFF → 直接返回
        if not cfg.enabled:
            return []

        real_now = view.clock.real_now_time()
        world_now = view.clock.world_now_time()
        inner = view.inner_life

        # 2. 节流：距上次主动 < min_interval
        last_proactive = inner.last_proactive_at()
        if last_proactive is not None:
            elapsed = (real_now - last_proactive).total_seconds()
            if elapsed < cfg.min_interval_seconds:
                return []

        # 3. pressure 不够
        pressure = inner.impulse_pressure()
        if pressure < cfg.pressure_threshold:
            return []

        # 4. 深夜禁；attention override 例外
        phase = inner.circadian_phase()
        attention = inner.attention_focus()
        override_used = False
        if phase in cfg.forbidden_phases:
            top_intensity = (
                int(attention[0].get("intensity", 0))
                if attention else 0
            )
            if top_intensity < cfg.attention_override_threshold:
                return []
            override_used = True

        # 5. 通过：构造 1 个候选
        goal = _pick_proactive_goal(attention)
        reason_bits = [
            f"pressure={pressure}",
            f"phase={phase.value}",
        ]
        if attention:
            reason_bits.append(
                f"attention={attention[0].get('summary', '')[:20]}"
            )
        if override_used:
            reason_bits.append("override")

        candidate = TriggerCandidate(
            candidate_id=make_candidate_id(),
            source_type=TriggerSourceType.INNER_IMPULSE,
            source_id=f"ii_{view.session.session_id}",
            reason="inner_impulse: " + ", ".join(reason_bits),
            created_at_real=real_now,
            created_at_world=world_now,
            priority=0.45,
            user_relevance=0.5,
            confidence=0.5,
            payload={
                "impulse_pressure": pressure,
                "phase": phase.value,
                "attention": attention,
                "override_used": override_used,
                "min_interval_passed": True,
            },
            tags=["inner_impulse"],
            proactive_goal=goal,
            suggested_style="warm",
        )
        return [candidate]
