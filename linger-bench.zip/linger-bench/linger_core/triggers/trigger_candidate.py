from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from linger_core.shared.ids import generate_id


class TriggerSourceType(str, Enum):
    FOLLOWUP = "followup"
    WORLD_EVENT = "world_event"
    UNRESOLVED_EVENT = "unresolved_event"
    RECONNECT = "reconnect"
    RELATIONSHIP_PING = "relationship_ping"
    DIGEST_OPENER = "digest_opener"
    INNER_IMPULSE = "inner_impulse"


@dataclass
class TriggerCandidate:
    candidate_id: str
    source_type: TriggerSourceType
    source_id: str
    reason: str
    created_at_real: datetime
    created_at_world: datetime

    priority: float = 0.5
    user_relevance: float = 0.5
    confidence: float = 0.5

    related_event_id: Optional[str] = None
    related_world_event_id: Optional[str] = None
    related_followup_hook_id: Optional[str] = None
    related_npc_id: Optional[str] = None

    payload: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)

    proactive_goal: str = ""
    suggested_style: str = "warm"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "source_type": self.source_type.value,
            "source_id": self.source_id,
            "reason": self.reason[:200],
            "priority": self.priority,
            "user_relevance": self.user_relevance,
            "confidence": self.confidence,
            "proactive_goal": self.proactive_goal,
            "suggested_style": self.suggested_style,
            "related_event_id": self.related_event_id,
            "related_world_event_id": self.related_world_event_id,
            "related_followup_hook_id": self.related_followup_hook_id,
            "related_npc_id": self.related_npc_id,
            "tags": self.tags,
        }


def make_candidate_id() -> str:
    return f"tc_{generate_id()[:12]}"
