from typing import TYPE_CHECKING, List

from linger_core.triggers.trigger_candidate import (
    TriggerCandidate,
    TriggerSourceType,
    make_candidate_id,
)
from linger_core.triggers.trigger_registry import TriggerSource

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


class RelationshipTriggerSource(TriggerSource):
    MIN_INTERACTIONS_FOR_PING = 5
    MIN_IDLE_FOR_DIGEST_OPENER = 60.0

    def source_type(self) -> str:
        return "relationship_ping"

    def collect(self, view: "RuntimeStateView") -> List[TriggerCandidate]:
        candidates: List[TriggerCandidate] = []
        real_now = view.clock.real_now_time()
        world_now = view.clock.world_now_time()

        snapshot = view.relationship.snapshot

        if snapshot.total_interactions < self.MIN_INTERACTIONS_FOR_PING:
            return candidates

        if snapshot.initiative_affinity >= 0.5 and snapshot.trust_level >= 0.4:
            candidate = TriggerCandidate(
                candidate_id=make_candidate_id(),
                source_type=TriggerSourceType.RELATIONSHIP_PING,
                source_id=f"rp_{view.session.session_id}",
                reason=f"relationship_ping: stage={snapshot.relationship_stage} warmth={snapshot.warmth:.2f}",
                created_at_real=real_now,
                created_at_world=world_now,
                priority=0.3,
                user_relevance=0.5,
                confidence=0.4,
                payload={
                    "relationship_stage": snapshot.relationship_stage,
                    "warmth": snapshot.warmth,
                    "trust_level": snapshot.trust_level,
                    "initiative_affinity": snapshot.initiative_affinity,
                },
                tags=["relationship_ping"],
                proactive_goal="gentle_check_in",
                suggested_style="gentle",
            )
            candidates.append(candidate)

        idle_seconds = view.session.idle_seconds_at_freeze
        if idle_seconds >= self.MIN_IDLE_FOR_DIGEST_OPENER:
            latest = view.memory.long_term.latest_digest_bundle()
            if latest is not None and hasattr(latest, "recommended_openers"):
                openers = latest.recommended_openers
                if openers:
                    candidate = TriggerCandidate(
                        candidate_id=make_candidate_id(),
                        source_type=TriggerSourceType.DIGEST_OPENER,
                        source_id=f"do_{view.session.session_id}",
                        reason=f"digest_opener: idle={idle_seconds:.0f}s",
                        created_at_real=real_now,
                        created_at_world=world_now,
                        priority=0.35,
                        user_relevance=0.6,
                        confidence=0.4,
                        payload={
                            "opener": openers[0] if openers else "",
                            "idle_seconds": idle_seconds,
                        },
                        tags=["digest_opener"],
                        proactive_goal="light_plan_reminder",
                        suggested_style="warm",
                    )
                    candidates.append(candidate)

        return candidates
