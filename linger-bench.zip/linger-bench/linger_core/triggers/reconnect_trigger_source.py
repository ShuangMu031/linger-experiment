from typing import TYPE_CHECKING, List

from linger_core.shared.enums import SessionStatus
from linger_core.triggers.trigger_candidate import (
    TriggerCandidate,
    TriggerSourceType,
    make_candidate_id,
)
from linger_core.triggers.trigger_registry import TriggerSource

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


class ReconnectTriggerSource(TriggerSource):
    MIN_IDLE_SECONDS = 30.0

    def source_type(self) -> str:
        return "reconnect"

    def collect(self, view: "RuntimeStateView") -> List[TriggerCandidate]:
        candidates: List[TriggerCandidate] = []

        if view.session.status != SessionStatus.IDLE:
            return candidates

        idle_seconds = view.session.idle_seconds_at_freeze
        if idle_seconds < self.MIN_IDLE_SECONDS:
            return candidates

        if view.session.last_user_end_signal:
            return candidates

        real_now = view.clock.real_now_time()
        world_now = view.clock.world_now_time()
        last_active_at = view.session.last_active_at

        candidate = TriggerCandidate(
            candidate_id=make_candidate_id(),
            source_type=TriggerSourceType.RECONNECT,
            source_id=f"reconnect_{view.session.session_id}",
            reason=f"user idle for {idle_seconds:.0f}s",
            created_at_real=real_now,
            created_at_world=world_now,
            priority=0.5,
            user_relevance=0.8,
            confidence=0.6,
            payload={
                "idle_seconds": idle_seconds,
                "last_active_at": last_active_at.isoformat() if last_active_at else None,
            },
            tags=["reconnect"],
            proactive_goal="reconnect",
            suggested_style="warm",
        )
        candidates.append(candidate)

        return candidates
