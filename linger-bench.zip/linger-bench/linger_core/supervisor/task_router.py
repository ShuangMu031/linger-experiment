import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from linger_core.core.contracts.module_contract import ModuleContract, ModuleInput
from linger_core.shared.enums import EmotionType


@dataclass
class RoutingDecision:
    modules_to_run: List[str] = field(default_factory=list)
    skip_reasons: Dict[str, str] = field(default_factory=dict)
    routing_confidence: float = 0.0
    routing_signals: Dict[str, Any] = field(default_factory=dict)


@dataclass
class InputSignals:
    is_emotional: bool = False
    is_question: bool = False
    has_event_clue: bool = False
    is_short_response: bool = False
    detected_emotion: Optional[str] = None
    emotion_intensity: float = 0.0
    has_pending_plans: bool = False
    has_pending_followups: bool = False
    is_returning_session: bool = False
    idle_seconds: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_emotional": self.is_emotional,
            "is_question": self.is_question,
            "has_event_clue": self.has_event_clue,
            "is_short_response": self.is_short_response,
            "detected_emotion": self.detected_emotion,
            "emotion_intensity": self.emotion_intensity,
            "has_pending_plans": self.has_pending_plans,
            "has_pending_followups": self.has_pending_followups,
            "is_returning_session": self.is_returning_session,
            "idle_seconds": self.idle_seconds,
        }


class TaskRouter:
    def __init__(self, modules: Optional[Dict[str, ModuleContract]] = None):
        self._modules: Dict[str, ModuleContract] = modules or {}

    def register(self, module: ModuleContract) -> None:
        self._modules[module.name()] = module

    def route(self, event_type: str, user_message: str, state: Any, recent_context: Any = None) -> RoutingDecision:
        signals = self._extract_signals(event_type, user_message, state)

        if recent_context:
            self._enrich_signals_with_context(signals, recent_context)

        to_run = []
        skip_reasons = {}

        for name, module in self._modules.items():
            decision = self._should_run(module, event_type, signals, state)
            if decision:
                to_run.append(name)
            else:
                skip_reasons[name] = decision.reason if decision else "not applicable"

        confidence = self._calc_routing_confidence(signals, to_run)

        return RoutingDecision(
            modules_to_run=to_run,
            skip_reasons=skip_reasons,
            routing_confidence=confidence,
            routing_signals=signals.to_dict(),
        )

    def _extract_signals(self, event_type: str, user_message: str, state: Any) -> InputSignals:
        msg = user_message.lower()

        is_emotional = bool(re.search(
            r'(难过|伤心|开心|高兴|生气|害怕|焦虑|紧张|烦躁|无聊|郁闷|失望|痛苦|愤怒|想你了|好想|好烦|好累|好开心|好难过|太好了|太烦了|哈哈|呜呜|嘤嘤|啊啊|哇|难受|委屈|心痛|不开心|慌|心慌|不安|恐惧|烦死|火大|受不了)',
            msg
        ))
        is_question = bool(re.search(r'[？?]', msg) or re.search(r'(吗|呢|什么|怎么|为什么|哪里|谁|几)', msg))
        has_event_clue = bool(re.search(r'(昨天|今天|明天|刚才|刚刚|之前|以后|后来|去了|来了|发生了|遇到了)', msg))
        is_short_response = len(user_message.strip()) <= 4

        detected_emotion = None
        emotion_intensity = 0.0
        if is_emotional:
            emotion_map = {
                "sad": ["难过", "伤心", "悲伤", "哭", "呜呜", "好惨"],
                "angry": ["生气", "愤怒", "烦", "讨厌", "气死", "可恶"],
                "anxious": ["焦虑", "担心", "害怕", "紧张", "不安", "恐惧"],
                "happy": ["开心", "高兴", "快乐", "幸福", "哈哈", "太好了", "棒"],
            }
            for emo, keywords in emotion_map.items():
                if any(kw in msg for kw in keywords):
                    detected_emotion = emo
                    emotion_intensity = 0.7
                    break
            if detected_emotion is None:
                detected_emotion = "emotional_unknown"
                emotion_intensity = 0.4

        has_pending_plans = len(state.plan_state.active_plans) > 0
        has_pending_followups = len(state.plan_state.pending_followups) > 0
        idle_seconds = state.session.idle_seconds(real_now=state.clock.real_now_time())
        is_returning_session = idle_seconds > 300

        return InputSignals(
            is_emotional=is_emotional,
            is_question=is_question,
            has_event_clue=has_event_clue,
            is_short_response=is_short_response,
            detected_emotion=detected_emotion,
            emotion_intensity=emotion_intensity,
            has_pending_plans=has_pending_plans,
            has_pending_followups=has_pending_followups,
            is_returning_session=is_returning_session,
            idle_seconds=idle_seconds,
        )

    def _should_run(self, module: ModuleContract, event_type: str, signals: InputSignals, state: Any) -> Optional["_RunDecision"]:
        name = module.name()

        if not module.can_handle(event_type):
            return None

        if name == "input_interpreter":
            return _RunDecision(True, "always runs for user input")

        if name == "emotion_insight_stub":
            if signals.is_emotional:
                return _RunDecision(True, "emotional input detected, high priority")
            current = state.emotion_state.current_emotion
            if current in (EmotionType.SAD, EmotionType.ANGRY, EmotionType.ANXIOUS):
                return _RunDecision(True, "user in negative emotional state, must check")
            if signals.is_short_response and current != EmotionType.NEUTRAL:
                return _RunDecision(True, "short response during non-neutral state, check emotion")
            if not signals.is_emotional and current == EmotionType.NEUTRAL:
                return _RunDecision(False, "no emotional signal and neutral state, skip emotion module")
            return _RunDecision(True, "non-neutral state present, run emotion check")

        if name == "context_check_stub":
            if signals.has_pending_plans or signals.has_pending_followups:
                return _RunDecision(True, "pending items exist, must check context")
            if signals.is_returning_session:
                return _RunDecision(True, "returning session, check context")
            if signals.has_event_clue:
                return _RunDecision(True, "event narrative detected, check context")
            return _RunDecision(True, "default: always check context for completeness")

        return _RunDecision(True, "default run")

    def _calc_routing_confidence(self, signals: InputSignals, to_run: List[str]) -> float:
        if not to_run:
            return 0.0
        signal_strength = sum([
            signals.is_emotional,
            signals.is_question,
            signals.has_event_clue,
            signals.has_pending_plans,
            signals.is_returning_session,
        ])
        base = 0.5 + min(signal_strength * 0.1, 0.4)
        if signals.is_emotional and "emotion_insight_stub" in to_run:
            base = min(base + 0.1, 1.0)
        return base

    def get_module(self, name: str) -> Optional[ModuleContract]:
        return self._modules.get(name)

    def list_modules(self) -> List[str]:
        return list(self._modules.keys())

    def _enrich_signals_with_context(self, signals: InputSignals, recent_context: Any) -> None:
        if hasattr(recent_context, "recent_unfinished_threads") and recent_context.recent_unfinished_threads:
            signals.has_pending_plans = True
        if hasattr(recent_context, "recent_comfort_count") and recent_context.recent_comfort_count >= 2:
            signals.emotion_intensity = min(signals.emotion_intensity + 0.1, 1.0)
        if hasattr(recent_context, "last_assistant_had_followup") and recent_context.last_assistant_had_followup:
            signals.has_pending_followups = True


@dataclass
class _RunDecision:
    should_run: bool
    reason: str

    def __bool__(self) -> bool:
        return self.should_run
