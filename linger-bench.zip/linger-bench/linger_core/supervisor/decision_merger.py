from typing import Any, Dict, List, Optional

from linger_core.core.contracts.module_contract import ModuleOutput
from linger_core.shared.enums import EmotionType
from linger_core.supervisor.action_plan import ActionPlan
from linger_core.supervisor.speak_rhythm import SpeakRhythmController


NEGATIVE_EMOTIONS = {EmotionType.SAD, EmotionType.ANGRY, EmotionType.ANXIOUS}


class DecisionMerger:
    def __init__(self):
        self._rhythm = SpeakRhythmController()

    def merge(self, outputs: List[ModuleOutput], state: Any, recent_context: Any = None, event_context: Any = None, is_event_continuation: bool = False, matched_event_id: str = "", startup_context: Optional[Dict[str, Any]] = None, world_context: Optional[Dict[str, Any]] = None) -> ActionPlan:
        if not outputs:
            return ActionPlan(
                primary_goal="wait",
                response_strategy="passive",
                reasoning_summary="no modules produced output",
            )

        emotion_priority = self._assess_emotion_priority(outputs, state)
        primary_goal = self._determine_primary_goal(outputs, emotion_priority)
        secondary_goals = self._collect_secondary_goals(outputs)
        response_strategy = self._determine_strategy(outputs, emotion_priority)
        should_comfort = self._check_comfort(outputs, emotion_priority)
        should_ask = self._check_question(outputs, emotion_priority)
        should_avoid = self._collect_avoids(outputs)
        state_writes = self._collect_state_writes(outputs)
        allow_drift = self._should_allow_drift(outputs, state)
        expression_style = self._determine_style(outputs, emotion_priority)
        confidence = self._weighted_confidence(outputs, emotion_priority)
        reasoning = self._build_reasoning(outputs, emotion_priority)

        if recent_context:
            should_comfort = self._adjust_comfort_with_context(should_comfort, recent_context)
            reasoning = self._enrich_reasoning_with_context(reasoning, recent_context)

        if event_context:
            should_comfort = self._adjust_with_event_context(should_comfort, event_context)
            expression_style = self._adjust_style_with_event_context(expression_style, event_context)
            reasoning = self._enrich_reasoning_with_event_context(reasoning, event_context)

        if is_event_continuation:
            if primary_goal not in ("comfort", "emotional_support"):
                primary_goal = "event_continuation"
            if response_strategy == "respond":
                response_strategy = "comfort"
            elif response_strategy == "inquire":
                response_strategy = "comfort_inquire"
            reasoning += f" | [event_continuation: matched={matched_event_id}]"

        if hasattr(state, 'profile_state') and state.profile_state:
            profile_style = state.profile_state.preferred_style
            if profile_style and profile_style != "balanced":
                if expression_style == "neutral":
                    expression_style = profile_style
            relationship_stage = state.profile_state.relationship_stage
            if relationship_stage in ("stranger", "acquaintance"):
                if expression_style in ("warm_gentle", "warm"):
                    expression_style = "polite_warm"
            risk_flags = state.profile_state.risk_flags
            if risk_flags:
                reasoning += f" | [profile_risk: {','.join(risk_flags[:3])}]"
                if "high_volatility" in risk_flags or "low_trust" in risk_flags:
                    should_comfort = True

        if startup_context:
            sc_style = startup_context.get("recommended_style")
            if sc_style and sc_style != "balanced" and expression_style == "neutral":
                expression_style = sc_style
            sc_openers = startup_context.get("recommended_openers", [])
            if sc_openers:
                reasoning += f" | [startup_opener: {sc_openers[0][:30]}]"
            sc_risk = startup_context.get("risk_flags", [])
            if sc_risk:
                reasoning += f" | [startup_risk: {','.join(sc_risk[:3])}]"
            sc_unresolved = startup_context.get("unresolved_topics", [])
            if sc_unresolved:
                reasoning += f" | [startup_unresolved: {len(sc_unresolved)} topics]"
            sc_relationship = startup_context.get("relationship_trend", "stable")
            if sc_relationship == "cooling":
                should_comfort = True

        if world_context:
            wc_time = world_context.get("time", {})
            wc_place = world_context.get("place", {})
            wc_ambient = world_context.get("ambient", {})
            wc_npcs = world_context.get("npcs", [])
            wc_events = world_context.get("recent_events", "")

            if wc_time.get("time_of_day") == "night":
                if expression_style == "neutral":
                    expression_style = "quiet_warm"
                reasoning += " | [world: nighttime, quieter tone]"

            if wc_ambient.get("mood") in ("melancholy", "tense"):
                should_comfort = True
                reasoning += f" | [world_ambient: {wc_ambient['mood']}]"

            if wc_npcs:
                npc_names = [n.get("name", "") for n in wc_npcs if n.get("name")]
                if npc_names:
                    reasoning += f" | [world_npcs: {','.join(npc_names[:3])}]"

            if wc_events:
                reasoning += f" | [world_events: {wc_events[:60]}]"

            wc_weather = wc_time.get("weather", "")
            if wc_weather in ("rainy", "stormy"):
                if expression_style == "neutral":
                    expression_style = "warm"
                reasoning += f" | [world_weather: {wc_weather}]"

        is_emotional = emotion_priority["has_emotional_input"]
        is_question = any(
            o.module_name == "input_interpreter" and o.state_impacts.get("is_question")
            for o in outputs
        )
        speak_perm = self._rhythm.evaluate(
            emotion_priority=emotion_priority["level"],
            current_emotion=state.emotion_state.current_emotion,
            current_intensity=state.emotion_state.intensity,
            is_question=is_question,
            is_emotional=is_emotional,
            has_pending_plans=len(state.plan_state.active_plans) > 0,
            idle_seconds=state.session.idle_seconds(real_now=state.clock.real_now_time()),
            last_speaker=state.session.last_speaker,
            waiting_for_user_reply=state.session.waiting_for_user_reply,
            consecutive_assistant_turns=state.session.consecutive_assistant_turns,
            last_user_end_signal=state.session.last_user_end_signal,
            assistant_messages_since_user=state.session.assistant_messages_since_user,
            assistant_proactive_streak=state.session.assistant_proactive_streak,
        )

        return ActionPlan(
            primary_goal=primary_goal,
            secondary_goals=secondary_goals,
            response_strategy=response_strategy,
            should_ask_question=should_ask,
            should_comfort=should_comfort,
            should_avoid=should_avoid,
            state_writes=state_writes,
            allow_drift=allow_drift,
            expression_style=expression_style,
            confidence=confidence,
            reasoning_summary=reasoning,
            module_outputs={o.module_name: o.judgment for o in outputs},
            can_speak=speak_perm.can_speak,
            should_pause=speak_perm.should_pause,
            speak_mode=speak_perm.speak_mode,
            allow_followup=speak_perm.allow_followup,
            pause_required=speak_perm.pause_required,
            max_sentences=speak_perm.max_sentences,
            followup_hook=speak_perm.followup_hook,
            emotion_priority=emotion_priority["level"],
        )

    def _assess_emotion_priority(self, outputs: List[ModuleOutput], state: Any) -> Dict[str, Any]:
        current_emotion = state.emotion_state.current_emotion
        current_intensity = state.emotion_state.intensity

        has_emotional_input = False
        input_emotion_type = None
        input_needs_comfort = False

        for o in outputs:
            if o.module_name in ("emotion_insight_stub", "emotion_insight_module"):
                if o.state_impacts.get("needs_comfort") or o.state_impacts.get("needs_support"):
                    input_needs_comfort = True
                    input_emotion_type = o.state_impacts.get("emotion") or o.state_impacts.get("primary_emotion")
                if o.confidence > 0.3 and ("detected_" in o.judgment or o.state_impacts.get("primary_emotion")):
                    has_emotional_input = True
            if o.module_name == "input_interpreter":
                if o.state_impacts.get("is_emotional"):
                    has_emotional_input = True

        in_negative_state = current_emotion in NEGATIVE_EMOTIONS
        emotion_escalation = has_emotional_input and in_negative_state

        if emotion_escalation:
            priority_level = "critical"
        elif has_emotional_input and input_needs_comfort:
            priority_level = "high"
        elif in_negative_state:
            priority_level = "elevated"
        elif has_emotional_input:
            priority_level = "moderate"
        else:
            priority_level = "low"

        return {
            "level": priority_level,
            "has_emotional_input": has_emotional_input,
            "input_needs_comfort": input_needs_comfort,
            "input_emotion_type": input_emotion_type,
            "in_negative_state": in_negative_state,
            "current_emotion": current_emotion.value,
            "current_intensity": current_intensity,
            "emotion_escalation": emotion_escalation,
        }

    def _determine_primary_goal(self, outputs: List[ModuleOutput], ep: Dict[str, Any]) -> str:
        if ep["level"] in ("critical", "high"):
            for o in outputs:
                if o.module_name in ("emotion_insight_stub", "emotion_insight_module"):
                    if o.state_impacts.get("needs_comfort") or o.state_impacts.get("needs_support"):
                        return "comfort"
            return "emotional_support"

        for o in outputs:
            if o.confidence >= 0.7 and o.suggested_actions:
                top = o.suggested_actions[0]
                if isinstance(top, dict):
                    action = top.get("action", o.judgment)
                    if ep["level"] == "elevated" and action not in ("comfort", "emotional_support"):
                        return "emotional_awareness"
                    return action

        if ep["level"] == "elevated":
            return "emotional_awareness"

        return outputs[0].judgment if outputs else "respond"

    def _determine_strategy(self, outputs: List[ModuleOutput], ep: Dict[str, Any]) -> str:
        if ep["level"] in ("critical", "high"):
            return "comfort"

        if ep["level"] == "elevated":
            has_question = any(
                o.module_name == "input_interpreter" and o.state_impacts.get("is_question")
                for o in outputs
            )
            if has_question:
                return "comfort_inquire"
            return "comfort"

        has_question = False
        has_comfort_signal = False
        for o in outputs:
            if "comfort" in o.judgment.lower() or "安抚" in o.judgment:
                has_comfort_signal = True
            if "question" in o.judgment.lower() or "提问" in o.judgment:
                has_question = True
            for action in o.suggested_actions:
                if isinstance(action, dict):
                    if action.get("action") == "comfort":
                        has_comfort_signal = True
                    if action.get("action") == "ask_question":
                        has_question = True

        if has_comfort_signal and has_question:
            return "comfort_inquire"
        if has_comfort_signal:
            return "comfort"
        if has_question:
            return "inquire"
        return "respond"

    def _check_comfort(self, outputs: List[ModuleOutput], ep: Dict[str, Any]) -> bool:
        if ep["level"] in ("critical", "high", "elevated"):
            return True
        for o in outputs:
            for action in o.suggested_actions:
                if isinstance(action, dict) and action.get("action") == "comfort":
                    return True
        return False

    def _check_question(self, outputs: List[ModuleOutput], ep: Dict[str, Any]) -> bool:
        for o in outputs:
            for action in o.suggested_actions:
                if isinstance(action, dict) and action.get("action") == "ask_question":
                    return True
        return False

    def _collect_secondary_goals(self, outputs: List[ModuleOutput]) -> List[str]:
        goals = []
        for o in outputs:
            for action in o.suggested_actions[1:]:
                if isinstance(action, dict):
                    goals.append(action.get("action", str(action)))
        return goals

    def _collect_avoids(self, outputs: List[ModuleOutput]) -> List[str]:
        avoids = []
        for o in outputs:
            for action in o.avoid_actions:
                if isinstance(action, dict):
                    avoids.append(action.get("action", str(action)))
                else:
                    avoids.append(str(action))
        return avoids

    def _collect_state_writes(self, outputs: List[ModuleOutput]) -> List[Dict[str, Any]]:
        writes = []
        for o in outputs:
            if o.state_impacts:
                writes.append(o.state_impacts)
        return writes

    def _should_allow_drift(self, outputs: List[ModuleOutput], state: Any) -> bool:
        if state.emotion_state.current_emotion in NEGATIVE_EMOTIONS:
            return False
        for o in outputs:
            if o.state_impacts.get("is_emotional"):
                return False
        return True

    def _determine_style(self, outputs: List[ModuleOutput], ep: Dict[str, Any]) -> str:
        if ep["level"] in ("critical", "high"):
            return "warm_gentle"
        if ep["level"] == "elevated":
            return "warm"
        for o in outputs:
            if "emotional" in o.judgment.lower() or "情绪" in o.judgment:
                return "warm"
        return "neutral"

    def _weighted_confidence(self, outputs: List[ModuleOutput], ep: Dict[str, Any]) -> float:
        if not outputs:
            return 0.0
        base = sum(o.confidence for o in outputs) / len(outputs)
        if ep["level"] in ("critical", "high"):
            base = min(base + 0.15, 1.0)
        elif ep["level"] == "elevated":
            base = min(base + 0.08, 1.0)
        return base

    def _build_reasoning(self, outputs: List[ModuleOutput], ep: Dict[str, Any]) -> str:
        parts = [f"[emotion_priority={ep['level']}]"]
        if ep["emotion_escalation"]:
            parts.append("ESCALATION: emotional_input + negative_state")
        if ep["input_needs_comfort"]:
            parts.append(f"needs_comfort=True(emotion={ep['input_emotion_type']})")
        for o in outputs:
            parts.append(f"[{o.module_name}] {o.judgment} (conf={o.confidence:.2f}): {o.reason}")
        return " | ".join(parts)

    def _adjust_comfort_with_context(self, should_comfort: bool, ctx: Any) -> bool:
        if hasattr(ctx, "recent_comfort_count") and ctx.recent_comfort_count >= 2:
            return False
        return should_comfort

    def _enrich_reasoning_with_context(self, reasoning: str, ctx: Any) -> str:
        parts = [reasoning]
        if hasattr(ctx, "turn_count") and ctx.turn_count > 0:
            parts.append(f"[memory: {ctx.turn_count} recent turns]")
        if hasattr(ctx, "recent_comfort_count") and ctx.recent_comfort_count >= 2:
            parts.append("[context: already comforted recently, skip repeat comfort]")
        if hasattr(ctx, "last_assistant_speak_mode") and ctx.last_assistant_speak_mode:
            parts.append(f"[last_speak_mode={ctx.last_assistant_speak_mode}]")
        if hasattr(ctx, "last_assistant_had_followup") and ctx.last_assistant_had_followup:
            parts.append("[context: last assistant output had followup]")
        return " | ".join(parts)

    def _adjust_with_event_context(self, should_comfort: bool, ctx: Any) -> bool:
        if hasattr(ctx, "has_unresolved") and ctx.has_unresolved:
            should_comfort = True
        if hasattr(ctx, "has_high_emotion") and ctx.has_high_emotion:
            should_comfort = True
        return should_comfort

    def _adjust_style_with_event_context(self, style: str, ctx: Any) -> str:
        if hasattr(ctx, "has_high_emotion") and ctx.has_high_emotion:
            if style not in ("warm_gentle", "warm"):
                return "warm"
        if hasattr(ctx, "has_unresolved") and ctx.has_unresolved:
            if style == "neutral":
                return "warm"
        return style

    def _enrich_reasoning_with_event_context(self, reasoning: str, ctx: Any) -> str:
        parts = [reasoning]
        if hasattr(ctx, "active_event_count") and ctx.active_event_count > 0:
            parts.append(f"[event_memory: {ctx.active_event_count} active events]")
        if hasattr(ctx, "has_unresolved") and ctx.has_unresolved:
            parts.append("[event: has unresolved events]")
        if hasattr(ctx, "has_high_emotion") and ctx.has_high_emotion:
            parts.append("[event: has high emotion events]")
        if hasattr(ctx, "top_event_title") and ctx.top_event_title:
            parts.append(f"[event_top: {ctx.top_event_title}]")
        if hasattr(ctx, "should_follow_up") and ctx.should_follow_up:
            hints = getattr(ctx, "follow_up_hints", [])
            if hints:
                parts.append(f"[event_followup: {'; '.join(hints[:2])}]")
        return " | ".join(parts)
