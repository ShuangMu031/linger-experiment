from typing import Any, Dict, List, Optional

from linger_core.core.contracts.module_contract import ModuleContract, ModuleInput, ModuleOutput
from linger_core.core.observability.trace_store import TraceStore
from linger_core.supervisor.task_router import TaskRouter
from linger_core.supervisor.decision_merger import DecisionMerger
from linger_core.supervisor.action_plan import ActionPlan


class SupervisorKernel:
    def __init__(
        self,
        trace_store: Optional[TraceStore] = None,
    ):
        self._router = TaskRouter()
        self._merger = DecisionMerger()
        self._trace_store = trace_store

    def register_module(self, module: ModuleContract) -> None:
        self._router.register(module)

    def process(
        self,
        state: Any,
        user_message: str,
        event_type: str = "USER_INPUT",
        context: Optional[Dict[str, Any]] = None,
        event_context: Any = None,
        context_bundle: Any = None,
        trace_id: str = "",
    ) -> ActionPlan:
        if context_bundle is None:
            raise ValueError("SupervisorKernel requires ContextBundle in cycle8 baseline")

        recent_context = context_bundle.recent_context
        startup_context = context_bundle.startup_context
        world_context = context_bundle.world_context

        if self._trace_store:
            self._trace_store.add_step({"step": "supervisor_receive", "message": user_message[:100]})

        if self._trace_store:
            self._trace_store.add_step({
                "step": "memory_recall_from_bundle",
                "turn_count": getattr(recent_context, 'turn_count', 0),
            })

        is_event_continuation = False
        matched_event_id = ""
        if event_context:
            is_event_continuation = getattr(event_context, "continuation_likely", False)
            matched_event_id = getattr(event_context, "matched_event_id", "")

        if self._trace_store:
            self._trace_store.add_step({
                "step": "event_context_check",
                "is_event_continuation": is_event_continuation,
                "matched_event_id": matched_event_id,
                "has_unresolved": getattr(event_context, "has_unresolved", False) if event_context else False,
                "has_high_emotion": getattr(event_context, "has_high_emotion", False) if event_context else False,
            })

        routing = self._router.route(event_type, user_message, state, recent_context=recent_context)

        if self._trace_store:
            self._trace_store.add_step({
                "step": "task_routing",
                "modules_to_run": routing.modules_to_run,
                "skipped": list(routing.skip_reasons.keys()),
            })

        module_input = ModuleInput(
            user_message=user_message,
            event_type=event_type,
            context=context or {},
        )

        if self._trace_store and trace_id:
            self._trace_store.set_input_understanding(trace_id, {
                "message": user_message[:200],
                "event_type": event_type,
                "modules_to_run": routing.modules_to_run,
            })

        outputs: List[ModuleOutput] = []
        for module_name in routing.modules_to_run:
            module = self._router.get_module(module_name)
            if module is None:
                continue

            if self._trace_store:
                self._trace_store.add_step({"step": "module_start", "module": module_name})

            try:
                output = module.process(state, module_input)
                outputs.append(output)

                if self._trace_store:
                    self._trace_store.add_step({
                        "step": "module_done",
                        "module": module_name,
                        "judgment": output.judgment,
                        "confidence": output.confidence,
                    })
                    if trace_id:
                        self._trace_store.add_module_judgment(trace_id, module_name, {
                            "judgment": output.judgment,
                            "confidence": output.confidence,
                            "reason": output.reason,
                            "suggested_actions": output.suggested_actions,
                        })
            except Exception as e:
                if self._trace_store:
                    self._trace_store.add_step({
                        "step": "module_error",
                        "module": module_name,
                        "error": str(e),
                    })

        plan = self._merger.merge(
            outputs, state,
            recent_context=recent_context,
            event_context=event_context,
            is_event_continuation=is_event_continuation,
            matched_event_id=matched_event_id,
            startup_context=startup_context,
            world_context=world_context,
        )

        if self._trace_store:
            self._trace_store.add_step({
                "step": "decision_merged",
                "primary_goal": plan.primary_goal,
                "strategy": plan.response_strategy,
                "confidence": plan.confidence,
            })
            if trace_id:
                self._trace_store.set_supervisor_decision(trace_id, {
                    "primary_goal": plan.primary_goal,
                    "strategy": plan.response_strategy,
                    "confidence": plan.confidence,
                    "reasoning": plan.reasoning_summary,
                })

        return plan

    @property
    def router(self) -> TaskRouter:
        return self._router

    @property
    def merger(self) -> DecisionMerger:
        return self._merger
