from dataclasses import dataclass, field
from typing import List, Optional

from linger_core.config.proactive_config import ProactiveConfig
from linger_core.core.state.runtime_state import RuntimeState
from linger_core.triggers.trigger_candidate import TriggerCandidate, TriggerSourceType


@dataclass
class GuardDecision:
    allowed: bool
    suppressed_reason: str = ""
    adjusted_priority: float = 0.0
    adjusted_confidence: float = 0.0

    def to_dict(self) -> dict:
        return {
            "allowed": self.allowed,
            "suppressed_reason": self.suppressed_reason,
            "adjusted_priority": self.adjusted_priority,
            "adjusted_confidence": self.adjusted_confidence,
        }


class ProactiveGuard:
    def __init__(self, config: Optional[ProactiveConfig] = None) -> None:
        self._config = config or ProactiveConfig()

    @property
    def config(self) -> ProactiveConfig:
        return self._config

    def evaluate(
        self, candidate: TriggerCandidate, state: RuntimeState
    ) -> GuardDecision:
        reasons: List[str] = []
        cfg = self._config

        if state.session.last_user_end_signal:
            reasons.append("user_end_signal")

        if state.session.consecutive_assistant_turns >= cfg.max_consecutive_proactive:
            reasons.append("consecutive_assistant_limit")

        if state.session.assistant_proactive_streak >= cfg.max_proactive_streak:
            reasons.append("proactive_streak_limit")

        seconds_since = state.session.seconds_since_assistant_message(
            real_now=state.clock.real_now_time()
        )
        if seconds_since < cfg.min_seconds_since_assistant and seconds_since > 0:
            reasons.append("too_soon_after_assistant")

        if state.session.waiting_for_user_reply:
            if candidate.source_type != TriggerSourceType.RECONNECT:
                reasons.append("waiting_for_user_reply")

        snapshot = state.relationship_tracker.snapshot
        if snapshot.trust_level < cfg.min_trust_for_proactive:
            reasons.append("trust_too_low")

        if candidate.user_relevance < cfg.min_user_relevance:
            reasons.append("user_relevance_too_low")

        if candidate.source_type == TriggerSourceType.UNRESOLVED_EVENT:
            if candidate.related_event_id:
                try:
                    evt = state.event_memory.get(candidate.related_event_id)
                    if evt and evt.recall_priority < cfg.min_recall_priority:
                        reasons.append("recall_priority_too_low")
                except Exception:
                    pass

        if candidate.source_type == TriggerSourceType.WORLD_EVENT:
            if candidate.user_relevance < cfg.world_event_min_user_relevance:
                reasons.append("world_event_low_relevance")

        if state.session.recent_proactive_count >= cfg.max_recent_proactive_per_window:
            reasons.append("proactive_rate_limit")

        if reasons:
            return GuardDecision(
                allowed=False,
                suppressed_reason="; ".join(reasons),
                adjusted_priority=candidate.priority,
                adjusted_confidence=candidate.confidence,
            )

        adjusted_priority = candidate.priority
        adjusted_confidence = candidate.confidence

        if snapshot.relationship_stage == "stranger":
            adjusted_priority *= 0.5
            adjusted_confidence *= 0.6
        elif snapshot.relationship_stage == "acquaintance":
            adjusted_priority *= 0.7
            adjusted_confidence *= 0.8

        if state.session.consecutive_assistant_turns >= 1:
            adjusted_priority *= 0.7

        return GuardDecision(
            allowed=True,
            adjusted_priority=adjusted_priority,
            adjusted_confidence=adjusted_confidence,
        )
