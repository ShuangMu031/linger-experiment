from typing import Any

from linger_core.core.contracts.module_contract import ModuleContract, ModuleInput, ModuleOutput
from linger_core.shared.enums import EmotionType


EMOTION_KEYWORDS = {
    EmotionType.HAPPY: ["开心", "高兴", "快乐", "幸福", "哈哈", "太好了", "棒", "嘻嘻", "耶"],
    EmotionType.SAD: ["难过", "伤心", "悲伤", "哭", "呜呜", "好惨", "难受", "心痛", "委屈", "不开心"],
    EmotionType.ANGRY: ["生气", "愤怒", "烦", "讨厌", "气死", "可恶", "火大", "受不了", "烦死"],
    EmotionType.ANXIOUS: ["焦虑", "担心", "害怕", "紧张", "不安", "恐惧", "慌", "心慌", "忐忑"],
    EmotionType.SURPRISED: ["哇", "天哪", "不会吧", "震惊", "意外", "什么情况"],
    EmotionType.CALM: ["嗯", "好的", "还行", "一般", "平静", "无所谓"],
}

INTENSITY_MODIFIERS = {
    "好": 0.15,
    "太": 0.2,
    "很": 0.15,
    "超": 0.2,
    "特别": 0.2,
    "非常": 0.25,
    "极其": 0.3,
}


# cycle9 will replace this stub with LLM-backed module.
class EmotionInsightStub(ModuleContract):
    def name(self) -> str:
        return "emotion_insight_stub"

    def can_handle(self, event_type: str) -> bool:
        return event_type in ("USER_INPUT",)

    def process(self, state: Any, module_input: ModuleInput) -> ModuleOutput:
        msg = module_input.user_message
        current_emotion = state.emotion_state.current_emotion
        current_intensity = state.emotion_state.intensity

        detected_emotion, emotion_confidence = self._detect_emotion(msg)
        needs_comfort = self._needs_comfort(detected_emotion, emotion_confidence)

        suggested = []
        if needs_comfort:
            suggested.append({"action": "comfort", "priority": "high", "target_emotion": detected_emotion.value})
        if emotion_confidence >= 0.4:
            suggested.append({
                "action": "update_emotion",
                "emotion": detected_emotion.value,
                "intensity": min(current_intensity + 0.2, 1.0),
            })

        avoid = []
        if detected_emotion in (EmotionType.SAD, EmotionType.ANGRY, EmotionType.ANXIOUS):
            avoid.append({"action": "ignore_emotion"})
            avoid.append({"action": "be_dismissive"})

        return ModuleOutput(
            module_name=self.name(),
            input_summary=msg[:100],
            judgment=f"detected_{detected_emotion.value}",
            confidence=emotion_confidence,
            reason=f"current={current_emotion.value}/{current_intensity:.2f}, detected={detected_emotion.value}/{emotion_confidence:.2f}, needs_comfort={needs_comfort}",
            suggested_actions=suggested,
            avoid_actions=avoid,
            state_impacts={
                "emotion": detected_emotion.value,
                "intensity_delta": 0.2 if emotion_confidence >= 0.4 else 0.0,
                "needs_comfort": needs_comfort,
            },
        )

    def _detect_emotion(self, msg: str):
        msg_lower = msg.lower()
        best_emotion = EmotionType.NEUTRAL
        best_score = 0.0

        for emotion, keywords in EMOTION_KEYWORDS.items():
            score = sum(1 for kw in keywords if kw in msg_lower)
            if score > best_score:
                best_score = score
                best_emotion = emotion

        if best_score == 0:
            return EmotionType.NEUTRAL, 0.2

        base_confidence = 0.5 + min(best_score * 0.15, 0.35)

        intensity_boost = 0.0
        for modifier, boost in INTENSITY_MODIFIERS.items():
            if modifier in msg_lower:
                intensity_boost = max(intensity_boost, boost)

        confidence = min(base_confidence + intensity_boost, 0.95)
        return best_emotion, confidence

    def _needs_comfort(self, emotion: EmotionType, confidence: float) -> bool:
        return emotion in (EmotionType.SAD, EmotionType.ANGRY, EmotionType.ANXIOUS) and confidence >= 0.4
