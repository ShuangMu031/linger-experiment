"""EmotionInsight 模块 — Plutnik 8 维 0-100 输出（spec §4.3 / §5）。

下游约定（兼容旧 7 维消费方）：
- state_impacts 同时含旧字段（emotion / primary_emotion / intensity 0.0-1.0）
  和新字段（dimensions / dominant_dimension）。
- 旧字段值通过 _DIM_TO_LEGACY 映射回旧 7 维 EmotionType 字符串值
  （joy→happy / sadness→sad / anger→angry / fear→anxious / surprise→surprised；
  trust / anticipation / disgust → neutral）。
"""
import json
from dataclasses import dataclass
from typing import Any, Dict, Optional

from linger_core.core.contracts.module_contract import (
    ModuleContract,
    ModuleInput,
    ModuleOutput,
)
from linger_core.core.emotion.emotion_dimensions import (
    EmotionDimension,
    EmotionVector,
)
from linger_core.llm.json_utils import parse_json_object_safely


_DIM_TO_LEGACY: Dict[EmotionDimension, str] = {
    EmotionDimension.JOY: "happy",
    EmotionDimension.SADNESS: "sad",
    EmotionDimension.ANGER: "angry",
    EmotionDimension.FEAR: "anxious",
    EmotionDimension.SURPRISE: "surprised",
    EmotionDimension.TRUST: "neutral",
    EmotionDimension.ANTICIPATION: "neutral",
    EmotionDimension.DISGUST: "neutral",
}


@dataclass
class EmotionInsight8d:
    dimensions: EmotionVector
    dominant: EmotionDimension
    needs_support: bool
    risk_level: str
    short_reason: str


# 旧 7 维 dataclass 保留（向下兼容外部 import；新流程不再构造）
@dataclass
class EmotionInsight:
    primary_emotion: str = "neutral"
    intensity: float = 0.0
    needs_support: bool = False
    risk_level: str = "low"
    short_reason: str = ""


class EmotionInsightModule(ModuleContract):
    def __init__(
        self,
        llm_provider=None,
        prompt_registry=None,
        llm_enabled: bool = False,
        llm_router=None,
    ) -> None:
        self._llm_provider = llm_provider
        self._prompt_registry = prompt_registry
        self._llm_enabled = llm_enabled
        self._llm_router = llm_router

    def name(self) -> str:
        return "emotion_insight_module"

    def can_handle(self, event_type: str) -> bool:
        return event_type in ("USER_INPUT", "BACKGROUND_TICK")

    def process(self, state: Any, module_input: ModuleInput) -> ModuleOutput:
        if self._llm_enabled and self._llm_provider and self._prompt_registry:
            return self._process_with_llm(state, module_input)
        return self._process_stub(state, module_input)

    def _process_with_llm(
        self, state: Any, module_input: ModuleInput,
    ) -> ModuleOutput:
        try:
            from linger_core.llm.base import LLMMessage, LLMRequest

            template = self._prompt_registry.get("emotion_insight")
            request = LLMRequest(
                messages=[
                    LLMMessage(role="system", content=template.system),
                    LLMMessage(role="user", content=template.user.format(
                        user_text=module_input.user_message,
                    )),
                ],
                response_format="json",
                metadata=dict(template.metadata_dict()),
            )

            response = self._call_llm(request)
            if not response.success:
                return self._process_stub(
                    state, module_input,
                    fallback_reason="llm_failed",
                    llm_error=response.error,
                )

            parsed, json_parse_mode = parse_json_object_safely(response.content)
            if json_parse_mode == "failed":
                return self._process_stub(
                    state, module_input,
                    fallback_reason="json_parse_failed",
                    json_parse_mode="failed",
                )

            insight = self._validate_insight_8d(parsed)
            return self._build_module_output(insight, module_input, json_parse_mode)

        except json.JSONDecodeError as e:
            return self._process_stub(
                state, module_input,
                fallback_reason="json_decode_error",
                llm_error=str(e)[:300],
            )
        except Exception as e:
            return self._process_stub(
                state, module_input,
                fallback_reason=f"exception:{type(e).__name__}",
                llm_error=str(e)[:300],
            )

    @staticmethod
    def _validate_insight_8d(parsed: dict) -> EmotionInsight8d:
        from linger_core.llm.safe_parse import (
            safe_bool,
            safe_enum,
            safe_str,
        )

        raw_dims = parsed.get("dimensions") if isinstance(parsed, dict) else None
        if not isinstance(raw_dims, dict):
            raw_dims = {}
        vector = EmotionVector.from_dict(raw_dims)

        valid_dims = tuple(d.value for d in EmotionDimension)
        raw_dominant = parsed.get("dominant", "") if isinstance(parsed, dict) else ""
        dominant_str = safe_enum(raw_dominant, valid_dims, default="")
        dominant = (EmotionDimension(dominant_str)
                    if dominant_str else vector.dominant())

        return EmotionInsight8d(
            dimensions=vector,
            dominant=dominant,
            needs_support=safe_bool(parsed.get("needs_support", False)),
            risk_level=safe_enum(
                parsed.get("risk_level", "low"),
                ("low", "medium", "high"),
                default="low",
            ),
            short_reason=safe_str(parsed.get("short_reason", ""), max_length=200),
        )

    @staticmethod
    def _build_module_output(
        insight: EmotionInsight8d,
        module_input: ModuleInput,
        json_parse_mode: str,
    ) -> ModuleOutput:
        dom_value = getattr(insight.dimensions, insight.dominant.value)
        intensity = dom_value / 100.0
        legacy_emotion = _DIM_TO_LEGACY.get(insight.dominant, "neutral")

        state_impacts = {
            # 新字段（InnerLifeUpdateModule / EmotionRouter 消费）
            "dimensions": insight.dimensions.to_dict(),
            "dominant_dimension": insight.dominant.value,
            # 旧字段（task_router / decision_merger / event_rules 等仍依赖）
            "emotion": legacy_emotion,
            "primary_emotion": legacy_emotion,
            "intensity": intensity,
            "intensity_delta": intensity * 0.2 if insight.needs_support else 0.0,
            "needs_support": insight.needs_support,
            "needs_comfort": insight.needs_support,
            "risk_level": insight.risk_level,
            "json_parse_mode": json_parse_mode,
            "llm_success": True,
        }

        return ModuleOutput(
            module_name="emotion_insight_module",
            input_summary=module_input.user_message[:80],
            judgment=legacy_emotion,
            confidence=intensity,
            reason=insight.short_reason,
            suggested_actions=["comfort"] if insight.needs_support else [],
            avoid_actions=[],
            state_impacts=state_impacts,
        )

    def _process_stub(
        self,
        state: Any,
        module_input: ModuleInput,
        fallback_reason: str = "no_llm",
        llm_error: str = "",
        json_parse_mode: str = "",
    ) -> ModuleOutput:
        impacts: dict = {"fallback_reason": fallback_reason}
        if llm_error:
            impacts["llm_error"] = llm_error
        if json_parse_mode:
            impacts["json_parse_mode"] = json_parse_mode
        return ModuleOutput(
            module_name=self.name(),
            input_summary=module_input.user_message[:80],
            judgment="emotional_unknown",
            confidence=0.3,
            reason="[stub] emotion insight not available",
            suggested_actions=[],
            avoid_actions=[],
            state_impacts=impacts,
        )

    def _call_llm(self, request):
        if self._llm_router is not None:
            from linger_core.llm.task_type import LLMTaskType
            return self._llm_router.generate(LLMTaskType.EMOTION_INSIGHT, request)

        if self._llm_provider is not None:
            return self._llm_provider.generate(request)

        from linger_core.llm.base import LLMResponse
        return LLMResponse(content="", success=False,
                           error="no llm provider or router")
