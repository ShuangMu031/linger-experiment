"""InnerLifeUpdateModule — InnerLifeState 的唯一合法写者（spec §4.3 / §7.3）。

事件类型路由：
- USER_INPUT       → 接收 EmotionInsight8d → router.route → 写 mood_baseline /
                     attention_focus / impulse_pressure
- BACKGROUND_TICK  → apply_decay（前慢后快）+ 更新 circadian_phase
- PROACTIVE_SENT   → release_impulse（清零 + 更新 last_proactive_at）

约定：
- module_input.context["emotion_insight_8d"] 形如：
    {
      "dimensions": {"joy": 0-100, ...},
      "dominant_dimension": "...",
      "event_id": "...",          # optional
      "summary": "...",           # optional
    }
- module_input.context["real_now"] 可选 datetime；缺则 datetime.now()

写边界：本模块在 grep guard 白名单内（test_inner_life_writeback_guard.py），
其他文件不得调用 InnerLifeState 的写方法。
"""
from datetime import datetime
from typing import Any, Dict, Optional

from linger_core.core.contracts.module_contract import (
    ModuleContract,
    ModuleInput,
    ModuleOutput,
)
from linger_core.core.emotion.decay_curve import (
    DEFAULT_DECAY_PARAMS,
    DecayParams,
)
from linger_core.core.emotion.emotion_dimensions import (
    EmotionDimension,
    EmotionVector,
)
from linger_core.core.emotion.emotion_router import EmotionRouter, RouteContext
from linger_core.core.state.inner_life_state import CircadianPhase


_DEFAULT_DRIFT_COEFF: float = 0.3


def _phase_from_hour(hour: int) -> CircadianPhase:
    if 5 <= hour < 8:
        return CircadianPhase.EARLY_MORNING
    if 8 <= hour < 12:
        return CircadianPhase.MORNING
    if 12 <= hour < 17:
        return CircadianPhase.AFTERNOON
    if 17 <= hour < 20:
        return CircadianPhase.EVENING
    if 20 <= hour < 24:
        return CircadianPhase.NIGHT
    return CircadianPhase.LATE_NIGHT  # 0-5


class InnerLifeUpdateModule(ModuleContract):
    def __init__(
        self,
        router: Optional[EmotionRouter] = None,
        decay_params: DecayParams = DEFAULT_DECAY_PARAMS,
        drift_coeff: float = _DEFAULT_DRIFT_COEFF,
    ) -> None:
        self._router = router or EmotionRouter()
        self._decay_params = decay_params
        self._drift_coeff = drift_coeff

    def name(self) -> str:
        return "inner_life_update_module"

    def can_handle(self, event_type: str) -> bool:
        return event_type in ("USER_INPUT", "BACKGROUND_TICK", "PROACTIVE_SENT")

    def process(self, state: Any, module_input: ModuleInput) -> ModuleOutput:
        evt = module_input.event_type
        ctx = module_input.context or {}
        real_now: datetime = ctx.get("real_now") or datetime.now()

        if evt == "USER_INPUT":
            return self._handle_user_input(state, ctx, real_now)
        if evt == "BACKGROUND_TICK":
            return self._handle_background_tick(state, ctx, real_now)
        if evt == "PROACTIVE_SENT":
            return self._handle_proactive_sent(state, real_now)

        return self._noop(reason=f"unsupported event_type {evt}")

    # ─── USER_INPUT ─────────────────────────────────────────

    def _handle_user_input(
        self,
        state: Any,
        ctx: Dict[str, Any],
        real_now: datetime,
    ) -> ModuleOutput:
        insight = ctx.get("emotion_insight_8d")
        if not isinstance(insight, dict):
            return self._noop(reason="no emotion_insight_8d in context")

        raw_dims = insight.get("dimensions") or {}
        instant = EmotionVector.from_dict(raw_dims)

        event_id = insight.get("event_id") or ""
        summary = insight.get("summary") or ""

        decision = self._router.route(
            instant=instant,
            context=RouteContext(
                event_id=event_id or None,
                summary=summary,
                real_now=real_now,
            ),
        )

        # 1) mood drift
        state.inner_life_state.apply_mood_drift(instant, self._drift_coeff)

        # 2) attention writes
        for focus in decision.attention_writes:
            state.inner_life_state.add_attention(focus)

        # 3) impulse 累积（emotion_router 是其中一个均等权因子）
        if decision.impulse_factor > 0:
            state.inner_life_state.accumulate_impulse(
                {"emotion_router": decision.impulse_factor}
            )

        return ModuleOutput(
            module_name=self.name(),
            input_summary=summary[:80],
            judgment="applied",
            confidence=1.0,
            reason=f"router triggered {len(decision.triggered_dimensions)} dim(s)",
            suggested_actions=[],
            avoid_actions=[],
            state_impacts={
                "triggered_dimensions": [d.value for d in decision.triggered_dimensions],
                "actions_dispatched": list(decision.actions_to_dispatch),
                "attention_writes": [
                    {"event_id": a.event_id,
                     "dominant_emotion": a.dominant_emotion.value,
                     "intensity": a.intensity}
                    for a in decision.attention_writes
                ],
                "impulse_factor": decision.impulse_factor,
                "trace_tags": list(decision.trace_tags),
            },
        )

    # ─── BACKGROUND_TICK ────────────────────────────────────

    def _handle_background_tick(
        self,
        state: Any,
        ctx: Dict[str, Any],
        real_now: datetime,
    ) -> ModuleOutput:
        last_decay = state.inner_life_state.last_decay_at
        delta_seconds = max(0.0, (real_now - last_decay).total_seconds())

        if delta_seconds > 0:
            state.inner_life_state.apply_decay(
                delta_seconds=delta_seconds,
                params=self._decay_params,
            )

        # 更新 circadian_phase（不触发写边界检查 — 直接赋值字段，
        # 但为保持单一写者纪律，仍走 InnerLifeState 内部 setter 形式）
        new_phase = _phase_from_hour(real_now.hour)
        if state.inner_life_state.circadian_phase != new_phase:
            state.inner_life_state.circadian_phase = new_phase
            state.inner_life_state.touch(real_now)

        return ModuleOutput(
            module_name=self.name(),
            input_summary="",
            judgment="ticked",
            confidence=1.0,
            reason=f"decay {delta_seconds:.0f}s, phase={new_phase.value}",
            state_impacts={
                "decay_seconds": delta_seconds,
                "circadian_phase": new_phase.value,
            },
        )

    # ─── PROACTIVE_SENT ─────────────────────────────────────

    def _handle_proactive_sent(
        self,
        state: Any,
        real_now: datetime,
    ) -> ModuleOutput:
        state.inner_life_state.release_impulse(real_now)
        return ModuleOutput(
            module_name=self.name(),
            input_summary="",
            judgment="released",
            confidence=1.0,
            reason="proactive message sent — impulse cleared",
            state_impacts={
                "impulse_pressure_after": 0,
                "last_proactive_at": real_now.isoformat(),
            },
        )

    # ─── helpers ────────────────────────────────────────────

    def _noop(self, reason: str) -> ModuleOutput:
        return ModuleOutput(
            module_name=self.name(),
            input_summary="",
            judgment="noop",
            confidence=0.0,
            reason=reason,
            state_impacts={},
        )
