from typing import Any

from linger_core.core.contracts.module_contract import ModuleContract, ModuleInput, ModuleOutput


# cycle9 will replace this stub with LLM-backed module.
class ContextCheckStub(ModuleContract):
    def name(self) -> str:
        return "context_check_stub"

    def can_handle(self, event_type: str) -> bool:
        return event_type in ("USER_INPUT", "BACKGROUND_TICK")

    def process(self, state: Any, module_input: ModuleInput) -> ModuleOutput:
        has_pending_plans = len(state.plan_state.active_plans) > 0
        has_pending_followups = len(state.plan_state.pending_followups) > 0
        session_idle = state.session.idle_seconds(real_now=state.clock.real_now_time())
        is_returning = session_idle > 300

        judgment = self._build_judgment(has_pending_plans, has_pending_followups, is_returning)
        confidence = self._calc_confidence(has_pending_plans, has_pending_followups, is_returning)

        suggested = []
        if has_pending_plans:
            suggested.append({"action": "check_plans", "count": len(state.plan_state.active_plans)})
        if is_returning:
            suggested.append({"action": "welcome_back", "idle_seconds": session_idle})

        return ModuleOutput(
            module_name=self.name(),
            input_summary=f"plans={has_pending_plans}, followups={has_pending_followups}, idle={session_idle:.0f}s",
            judgment=judgment,
            confidence=confidence,
            reason=f"active_plans={len(state.plan_state.active_plans)}, pending_followups={len(state.plan_state.pending_followups)}, idle={session_idle:.0f}s, returning={is_returning}",
            suggested_actions=suggested,
            avoid_actions=[],
            state_impacts={
                "has_pending_plans": has_pending_plans,
                "has_pending_followups": has_pending_followups,
                "is_returning_session": is_returning,
            },
        )

    def _build_judgment(self, has_plans: bool, has_pending: bool, is_returning: bool) -> str:
        if is_returning and has_plans:
            return "returning_with_plans"
        if is_returning:
            return "returning_session"
        if has_plans or has_pending:
            return "has_pending_context"
        return "clean_context"

    def _calc_confidence(self, has_plans: bool, has_pending: bool, is_returning: bool) -> float:
        if has_plans or has_pending or is_returning:
            return 0.8
        return 0.5
