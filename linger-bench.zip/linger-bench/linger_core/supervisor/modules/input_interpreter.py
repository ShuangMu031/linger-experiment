import re
from typing import Any

from linger_core.core.contracts.module_contract import ModuleContract, ModuleInput, ModuleOutput


class InputInterpreter(ModuleContract):
    def name(self) -> str:
        return "input_interpreter"

    def can_handle(self, event_type: str) -> bool:
        return event_type in ("USER_INPUT", "SYSTEM_START")

    def process(self, state: Any, module_input: ModuleInput) -> ModuleOutput:
        msg = module_input.user_message.lower()

        is_emotional = self._detect_emotional(msg)
        is_question = self._detect_question(msg)
        is_statement = self._detect_statement(msg)
        has_event_clue = self._detect_event_clue(msg)

        judgment = self._build_judgment(is_emotional, is_question, is_statement, has_event_clue)
        confidence = self._calc_confidence(is_emotional, is_question, is_statement, has_event_clue)

        suggested = []
        if is_emotional:
            suggested.append({"action": "comfort", "priority": "high"})
        if is_question:
            # 用户提问 → 她回答(respond),而非反过来提问(ask_question)。
            # "ask_question"(她主动提问)的语义不该由"用户提问"触发,否则
            # should_ask_question=True 会压过 prompt 的"别反问",导致她系统性反问。
            suggested.append({"action": "respond", "priority": "medium"})
        if has_event_clue:
            suggested.append({"action": "check_context", "priority": "medium"})

        avoid = []
        if is_emotional:
            avoid.append({"action": "ignore_emotion"})

        return ModuleOutput(
            module_name=self.name(),
            input_summary=module_input.user_message[:100],
            judgment=judgment,
            confidence=confidence,
            reason=f"emotional={is_emotional}, question={is_question}, statement={is_statement}, event_clue={has_event_clue}",
            suggested_actions=suggested,
            avoid_actions=avoid,
            state_impacts={
                "input_type": judgment,
                "is_emotional": is_emotional,
                "is_question": is_question,
            },
        )

    def _detect_emotional(self, msg: str) -> bool:
        emotional_patterns = [
            r'(难过|伤心|开心|高兴|生气|害怕|焦虑|紧张|烦躁|无聊|郁闷|失望|痛苦|愤怒|难受|委屈|心痛|不开心|不安|恐惧|慌|心慌|烦死|火大|受不了)',
            r'(想你了|好想|好烦|好累|好开心|好难过|太好了|太烦了)',
            r'[!！]{2,}',
            r'(哈哈|呜呜|嘤嘤|啊啊|哇)',
        ]
        return any(re.search(p, msg) for p in emotional_patterns)

    def _detect_question(self, msg: str) -> bool:
        return bool(re.search(r'[？?]', msg) or re.search(r'(吗|呢|什么|怎么|为什么|哪里|谁|几)', msg))

    def _detect_statement(self, msg: str) -> bool:
        return not self._detect_question(msg) and not self._detect_emotional(msg)

    def _detect_event_clue(self, msg: str) -> bool:
        event_patterns = [
            r'(昨天|今天|明天|刚才|刚刚|之前|以后|后来)',
            r'(去了|来了|发生了|遇到了|看到了|听到了)',
            r'(他|她|他们|它)(说|做|走|跑|来|去)',
        ]
        return any(re.search(p, msg) for p in event_patterns)

    def _build_judgment(self, emotional: bool, question: bool, statement: bool, event: bool) -> str:
        if emotional and question:
            return "emotional_question"
        if emotional:
            return "emotional_expression"
        if question:
            return "factual_question"
        if event:
            return "event_narrative"
        return "casual_statement"

    def _calc_confidence(self, emotional: bool, question: bool, statement: bool, event: bool) -> float:
        signals = sum([emotional, question, event])
        if signals == 0:
            return 0.4
        if signals == 1:
            return 0.7
        return 0.85
