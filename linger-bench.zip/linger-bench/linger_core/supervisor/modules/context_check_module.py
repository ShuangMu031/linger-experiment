import json
from dataclasses import dataclass
from typing import Any, Optional

from linger_core.core.contracts.module_contract import ModuleContract, ModuleInput, ModuleOutput
from linger_core.llm.json_utils import parse_json_object_safely


@dataclass
class ContextCheckResult:
    needs_memory_recall: bool = False
    needs_event_recall: bool = False
    needs_world_context: bool = False
    needs_clarification: bool = False
    short_reason: str = ""


class ContextCheckModule(ModuleContract):
    def __init__(
        self,
        llm_provider=None,
        prompt_registry=None,
        llm_enabled: bool = False,
        llm_router=None,
    ) -> None:
        self._llm_provider = llm_provider
        self._prompt_registry = prompt_registry
        self._llm_enabled = llm_enabled
        self._llm_router = llm_router

    def name(self) -> str:
        return "context_check_module"

    def can_handle(self, event_type: str) -> bool:
        return event_type in ("USER_INPUT", "BACKGROUND_TICK")

    def process(self, state: Any, module_input: ModuleInput) -> ModuleOutput:
        if self._llm_enabled and self._llm_provider and self._prompt_registry:
            return self._process_with_llm(state, module_input)

        return self._process_stub(state, module_input)

    def _process_with_llm(self, state: Any, module_input: ModuleInput) -> ModuleOutput:
        try:
            from linger_core.llm.base import LLMMessage, LLMRequest

            pending_plans = len(state.plan_state.active_plans)
            pending_followups = len(state.plan_state.pending_followups)
            idle_seconds = state.session.idle_seconds(real_now=state.clock.real_now_time())

            template = self._prompt_registry.get("context_check")
            request = LLMRequest(
                messages=[
                    LLMMessage(role="system", content=template.system),
                    LLMMessage(role="user", content=template.user.format(
                        user_text=module_input.user_message,
                        pending_plans=pending_plans,
                        pending_followups=pending_followups,
                        idle_seconds=f"{idle_seconds:.0f}s",
                    )),
                ],
                response_format="json",
                metadata=dict(template.metadata_dict()),
            )

            response = self._call_llm(request)
            if not response.success:
                return self._process_stub(
                    state, module_input,
                    fallback_reason="llm_failed",
                    llm_error=response.error,
                )

            parsed, json_parse_mode = parse_json_object_safely(response.content)
            if json_parse_mode == "failed":
                return self._process_stub(
                    state, module_input,
                    fallback_reason="json_parse_failed",
                    json_parse_mode="failed",
                )

            result = self._validate_result(parsed)

            return ModuleOutput(
                module_name=self.name(),
                input_summary=module_input.user_message[:80],
                judgment="checked",
                confidence=0.5,
                reason=result.short_reason,
                suggested_actions=[],
                avoid_actions=[],
                state_impacts={
                    "needs_memory_recall": result.needs_memory_recall,
                    "needs_event_recall": result.needs_event_recall,
                    "needs_world_context": result.needs_world_context,
                    "needs_clarification": result.needs_clarification,
                    "should_inquire": result.needs_clarification,
                    "should_recall_context": result.needs_memory_recall or result.needs_event_recall,
                    "json_parse_mode": json_parse_mode,
                    "llm_success": True,
                },
            )

        except json.JSONDecodeError as e:
            return self._process_stub(
                state, module_input,
                fallback_reason="json_decode_error",
                llm_error=str(e)[:300],
            )
        except Exception as e:
            return self._process_stub(
                state, module_input,
                fallback_reason=f"exception:{type(e).__name__}",
                llm_error=str(e)[:300],
            )

    @staticmethod
    def _validate_result(parsed: dict) -> "ContextCheckResult":
        from linger_core.llm.safe_parse import safe_bool, safe_str

        return ContextCheckResult(
            needs_memory_recall=safe_bool(parsed.get("needs_memory_recall", False)),
            needs_event_recall=safe_bool(parsed.get("needs_event_recall", False)),
            needs_world_context=safe_bool(parsed.get("needs_world_context", False)),
            needs_clarification=safe_bool(parsed.get("needs_clarification", False)),
            short_reason=safe_str(parsed.get("short_reason", ""), max_length=120),
        )

    def _process_stub(
        self,
        state: Any,
        module_input: ModuleInput,
        fallback_reason: str = "no_llm",
        llm_error: str = "",
        json_parse_mode: str = "",
    ) -> ModuleOutput:
        impacts: dict = {
            "fallback_reason": fallback_reason,
        }
        if llm_error:
            impacts["llm_error"] = llm_error
        if json_parse_mode:
            impacts["json_parse_mode"] = json_parse_mode
        return ModuleOutput(
            module_name=self.name(),
            input_summary=module_input.user_message[:80],
            judgment="clean_context",
            confidence=0.5,
            reason="[stub] context check not available",
            suggested_actions=[],
            avoid_actions=[],
            state_impacts=impacts,
        )

    def _call_llm(self, request):
        if self._llm_router is not None:
            from linger_core.llm.task_type import LLMTaskType
            return self._llm_router.generate(LLMTaskType.CONTEXT_CHECK, request)

        if self._llm_provider is not None:
            return self._llm_provider.generate(request)

        from linger_core.llm.base import LLMResponse
        return LLMResponse(content="", success=False, error="no llm provider or router")
