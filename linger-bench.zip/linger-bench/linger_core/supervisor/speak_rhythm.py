from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from linger_core.shared.enums import EmotionType


NEGATIVE_EMOTIONS = {EmotionType.SAD, EmotionType.ANGRY, EmotionType.ANXIOUS}


@dataclass
class SpeakPermission:
    can_speak: bool = True
    should_pause: bool = False
    speak_mode: str = "normal"
    allow_followup: bool = False
    pause_required: bool = False
    max_sentences: int = 3
    followup_hook: str = ""
    reason: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "can_speak": self.can_speak,
            "should_pause": self.should_pause,
            "speak_mode": self.speak_mode,
            "allow_followup": self.allow_followup,
            "pause_required": self.pause_required,
            "max_sentences": self.max_sentences,
            "followup_hook": self.followup_hook,
            "reason": self.reason,
        }


class SpeakRhythmController:
    def evaluate(
        self,
        emotion_priority: str,
        current_emotion: EmotionType,
        current_intensity: float,
        is_question: bool,
        is_emotional: bool,
        has_pending_plans: bool,
        idle_seconds: float,
        last_speaker: str = "",
        waiting_for_user_reply: bool = False,
        consecutive_assistant_turns: int = 0,
        last_user_end_signal: bool = False,
        assistant_messages_since_user: int = 0,
        assistant_proactive_streak: int = 0,
    ) -> SpeakPermission:
        effective_turns = max(consecutive_assistant_turns, assistant_messages_since_user)

        if last_user_end_signal:
            return SpeakPermission(
                can_speak=False,
                should_pause=True,
                speak_mode="normal",
                allow_followup=False,
                pause_required=True,
                max_sentences=0,
                followup_hook="",
                reason="user sent end signal: stop speaking, wait for user to re-engage",
            )

        if effective_turns >= 2:
            return SpeakPermission(
                can_speak=True,
                should_pause=True,
                speak_mode="gentle_presence",
                allow_followup=False,
                pause_required=True,
                max_sentences=1,
                followup_hook="",
                reason=f"assistant_messages_since_user={effective_turns}: suppress further, give user space",
            )

        if assistant_proactive_streak >= 2:
            return SpeakPermission(
                can_speak=True,
                should_pause=True,
                speak_mode="gentle_presence",
                allow_followup=False,
                pause_required=True,
                max_sentences=1,
                followup_hook="",
                reason=f"assistant_proactive_streak={assistant_proactive_streak}: too many proactive messages, wait for user",
            )

        if waiting_for_user_reply and last_speaker == "assistant":
            return SpeakPermission(
                can_speak=True,
                should_pause=True,
                speak_mode="gentle_presence",
                allow_followup=False,
                pause_required=True,
                max_sentences=1,
                followup_hook="quiet_companion",
                reason="waiting for user reply after assistant spoke: minimal presence only",
            )

        if emotion_priority == "critical":
            return SpeakPermission(
                can_speak=True,
                should_pause=False,
                speak_mode="comfort_only",
                allow_followup=True,
                pause_required=True,
                max_sentences=2,
                followup_hook="gentle_check_in",
                reason="critical emotion: comfort first, then pause for user space",
            )

        if emotion_priority == "high":
            return SpeakPermission(
                can_speak=True,
                should_pause=False,
                speak_mode="comfort_first",
                allow_followup=True,
                pause_required=True,
                max_sentences=2,
                followup_hook="soft_followup",
                reason="high emotion: comfort, short response, then pause",
            )

        if emotion_priority == "elevated":
            if is_question:
                return SpeakPermission(
                    can_speak=True,
                    should_pause=False,
                    speak_mode="warm_respond",
                    allow_followup=True,
                    pause_required=False,
                    max_sentences=3,
                    followup_hook="warm_check",
                    reason="elevated emotion + question: answer warmly, allow followup",
                )
            return SpeakPermission(
                can_speak=True,
                should_pause=True,
                speak_mode="gentle_presence",
                allow_followup=True,
                pause_required=True,
                max_sentences=2,
                followup_hook="quiet_companion",
                reason="elevated emotion: gentle presence, pause to give space",
            )

        if is_emotional and not is_question:
            return SpeakPermission(
                can_speak=True,
                should_pause=False,
                speak_mode="warm_acknowledge",
                allow_followup=True,
                pause_required=False,
                max_sentences=3,
                followup_hook="light_followup",
                reason="emotional input: acknowledge warmly, allow followup",
            )

        if is_question:
            return SpeakPermission(
                can_speak=True,
                should_pause=False,
                speak_mode="normal",
                allow_followup=False,
                pause_required=False,
                max_sentences=4,
                followup_hook="",
                reason="factual question: answer normally",
            )

        if idle_seconds > 300:
            return SpeakPermission(
                can_speak=True,
                should_pause=False,
                speak_mode="welcome_back",
                allow_followup=True,
                pause_required=False,
                max_sentences=3,
                followup_hook="reconnect",
                reason="returning session: welcome back, allow followup",
            )

        if has_pending_plans:
            return SpeakPermission(
                can_speak=True,
                should_pause=False,
                speak_mode="normal",
                allow_followup=True,
                pause_required=False,
                max_sentences=3,
                followup_hook="plan_reminder",
                reason="pending plans: respond and allow plan followup",
            )

        return SpeakPermission(
            can_speak=True,
            should_pause=False,
            speak_mode="normal",
            allow_followup=False,
            pause_required=False,
            max_sentences=3,
            followup_hook="",
            reason="default: normal response",
        )
