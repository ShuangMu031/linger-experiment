from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from linger_core.shared.enums import EmotionType

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


@dataclass
class FollowupHook:
    hook_id: str
    hook_type: str
    source_turn_id: int
    created_at: datetime
    eligible_after: datetime
    expires_at: datetime
    max_attempts: int = 1
    attempts: int = 0
    status: str = "pending"
    reason: str = ""
    trigger_conditions: Dict[str, Any] = field(default_factory=dict)

    def is_eligible(self, world_now: datetime) -> bool:
        if self.status != "pending":
            return False
        if self.attempts >= self.max_attempts:
            return False
        if world_now < self.eligible_after:
            return False
        if world_now > self.expires_at:
            self.status = "expired"
            return False
        return True

    def mark_attempted(self) -> None:
        self.attempts += 1
        if self.attempts >= self.max_attempts:
            self.status = "completed"

    def mark_fired(self) -> None:
        self.status = "fired"
        self.attempts += 1

    def mark_cancelled(self, reason: str = "") -> None:
        self.status = "cancelled"
        if reason:
            self.reason = f"{self.reason}; cancelled: {reason}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "hook_id": self.hook_id,
            "hook_type": self.hook_type,
            "source_turn_id": self.source_turn_id,
            "created_at": self.created_at.isoformat(),
            "eligible_after": self.eligible_after.isoformat(),
            "expires_at": self.expires_at.isoformat(),
            "max_attempts": self.max_attempts,
            "attempts": self.attempts,
            "status": self.status,
            "reason": self.reason,
            "trigger_conditions": self.trigger_conditions,
        }


HOOK_TYPE_CONFIGS = {
    "gentle_check_in": {
        "delay_seconds": 30,
        "ttl_seconds": 120,
        "max_attempts": 1,
    },
    "soft_followup": {
        "delay_seconds": 20,
        "ttl_seconds": 90,
        "max_attempts": 1,
    },
    "warm_check": {
        "delay_seconds": 15,
        "ttl_seconds": 60,
        "max_attempts": 1,
    },
    "quiet_companion": {
        "delay_seconds": 45,
        "ttl_seconds": 150,
        "max_attempts": 1,
    },
    "light_followup": {
        "delay_seconds": 20,
        "ttl_seconds": 60,
        "max_attempts": 1,
    },
    "reconnect": {
        "delay_seconds": 10,
        "ttl_seconds": 180,
        "max_attempts": 2,
    },
    "plan_reminder": {
        "delay_seconds": 30,
        "ttl_seconds": 120,
        "max_attempts": 1,
    },
}


def create_followup_hook(
    hook_type: str,
    source_turn_id: int,
    world_now: datetime,
    reason: str = "",
    trigger_conditions: Optional[Dict[str, Any]] = None,
) -> Optional[FollowupHook]:
    config = HOOK_TYPE_CONFIGS.get(hook_type)
    if config is None:
        return None

    from linger_core.shared.ids import generate_session_id
    hook_id = f"fh_{generate_session_id()[:12]}"

    return FollowupHook(
        hook_id=hook_id,
        hook_type=hook_type,
        source_turn_id=source_turn_id,
        created_at=world_now,
        eligible_after=world_now + timedelta(seconds=config["delay_seconds"]),
        expires_at=world_now + timedelta(seconds=config["ttl_seconds"]),
        max_attempts=config["max_attempts"],
        reason=reason,
        trigger_conditions=trigger_conditions or {},
    )


def check_followup_conditions(
    hook: FollowupHook,
    view: "RuntimeStateView",
) -> bool:
    conditions = hook.trigger_conditions
    if not conditions:
        return True

    if conditions.get("require_idle_min_seconds"):
        if view.session.idle_seconds_at_freeze < conditions["require_idle_min_seconds"]:
            return False

    if conditions.get("require_emotion_not_escalated"):
        from linger_core.shared.enums import EmotionType
        current = view.emotion.current
        if current in (EmotionType.SAD, EmotionType.ANGRY, EmotionType.ANXIOUS):
            if view.emotion.intensity > 0.8:
                return False

    if conditions.get("require_no_user_end_signal"):
        if view.session.last_user_end_signal:
            return False

    if conditions.get("max_consecutive_assistant_turns"):
        if view.session.consecutive_assistant_turns >= conditions["max_consecutive_assistant_turns"]:
            return False

    return True
