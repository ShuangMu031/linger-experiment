from typing import Optional

from linger_core.supervisor.action_plan import ActionPlan
from linger_core.runtime.orchestrator.runtime_envelope import RuntimeEnvelope, EnvelopeSourceType
from linger_core.runtime.orchestrator.context_assembler import ContextBundle


class ProactivePlanner:
    def __init__(self) -> None:
        pass

    def process_candidate(
        self,
        envelope: RuntimeEnvelope,
        state,
        context_bundle: ContextBundle,
    ) -> ActionPlan:
        source_type = envelope.source_type

        goal = envelope.payload.get("proactive_goal")
        style = envelope.payload.get("suggested_style")
        confidence = envelope.payload.get("confidence")

        if source_type == EnvelopeSourceType.FOLLOWUP_CANDIDATE:
            return self._plan_followup(envelope, goal, style, confidence)
        elif source_type == EnvelopeSourceType.WORLD_EVENT_CANDIDATE:
            return self._plan_world_event(envelope, goal, style, confidence)
        elif source_type == EnvelopeSourceType.UNRESOLVED_EVENT_CANDIDATE:
            return self._plan_unresolved_event(envelope, goal, style, confidence)
        elif source_type == EnvelopeSourceType.RECONNECT_CANDIDATE:
            return self._plan_reconnect(envelope, goal, style, confidence)
        elif source_type == EnvelopeSourceType.RELATIONSHIP_PING_CANDIDATE:
            return self._plan_relationship_ping(envelope, goal, style, confidence)
        elif source_type == EnvelopeSourceType.DIGEST_OPENER_CANDIDATE:
            return self._plan_digest_opener(envelope, goal, style, confidence)
        else:
            return ActionPlan(
                primary_goal="wait",
                response_strategy="passive",
                reasoning_summary=f"unknown source_type: {source_type}",
                can_speak=False,
            )

    def _plan_followup(
        self,
        envelope: RuntimeEnvelope,
        goal: Optional[str] = None,
        style: Optional[str] = None,
        confidence: Optional[float] = None,
    ) -> ActionPlan:
        hook_type = envelope.payload.get("hook_type", "unknown")
        reason = envelope.text or "followup triggered"

        _style = style or "warm"
        if not style and hook_type in ("comfort_check", "emotion_followup"):
            _style = "gentle"
        elif not style and hook_type in ("topic_continue",):
            _style = "warm"

        return ActionPlan(
            primary_goal="proactive_followup",
            response_strategy="proactive",
            expression_style=_style,
            speak_mode="warm_respond",
            can_speak=True,
            should_pause=True,
            allow_followup=False,
            confidence=confidence if confidence is not None else 0.6,
            reasoning_summary=f"[proactive:followup] hook_type={hook_type} reason={reason[:80]}",
            emotion_priority="low",
        )

    def _plan_world_event(
        self,
        envelope: RuntimeEnvelope,
        goal: Optional[str] = None,
        style: Optional[str] = None,
        confidence: Optional[float] = None,
    ) -> ActionPlan:
        event_type = envelope.payload.get("event_type", "unknown")
        title = envelope.text or "world event"

        _style = style or "neutral"
        if not style and event_type in ("weather_change",):
            _style = "warm"
        elif not style and event_type in ("npc_encounter",):
            _style = "casual"

        return ActionPlan(
            primary_goal=goal or "world_event_notify",
            response_strategy="inform",
            expression_style=_style,
            speak_mode="warm_respond",
            can_speak=True,
            should_pause=True,
            allow_followup=False,
            confidence=confidence if confidence is not None else 0.5,
            reasoning_summary=f"[proactive:world_event] type={event_type} title={title[:60]}",
            emotion_priority="low",
        )

    def _plan_unresolved_event(
        self,
        envelope: RuntimeEnvelope,
        goal: Optional[str] = None,
        style: Optional[str] = None,
        confidence: Optional[float] = None,
    ) -> ActionPlan:
        return ActionPlan(
            primary_goal=goal or "unresolved_check",
            response_strategy="inquire",
            expression_style=style or "gentle",
            speak_mode="warm_respond",
            can_speak=True,
            should_pause=True,
            allow_followup=False,
            confidence=confidence if confidence is not None else 0.5,
            reasoning_summary=f"[proactive:unresolved] event={envelope.related_event_id or 'unknown'}",
            emotion_priority="low",
        )

    def _plan_reconnect(
        self,
        envelope: RuntimeEnvelope,
        goal: Optional[str] = None,
        style: Optional[str] = None,
        confidence: Optional[float] = None,
    ) -> ActionPlan:
        return ActionPlan(
            primary_goal=goal or "reconnect",
            response_strategy="warm_reconnect",
            expression_style=style or "warm",
            speak_mode="welcome_back",
            can_speak=True,
            should_pause=True,
            allow_followup=True,
            followup_hook="topic_continue",
            confidence=confidence if confidence is not None else 0.6,
            reasoning_summary="[proactive:reconnect] user returned after idle",
            emotion_priority="low",
        )

    def _plan_relationship_ping(
        self,
        envelope: RuntimeEnvelope,
        goal: Optional[str] = None,
        style: Optional[str] = None,
        confidence: Optional[float] = None,
    ) -> ActionPlan:
        return ActionPlan(
            primary_goal=goal or "relationship_maintain",
            response_strategy="gentle_presence",
            expression_style=style or "gentle",
            speak_mode="gentle_presence",
            can_speak=True,
            should_pause=True,
            allow_followup=False,
            confidence=confidence if confidence is not None else 0.4,
            reasoning_summary="[proactive:relationship_ping] periodic check",
            emotion_priority="low",
        )

    def _plan_digest_opener(
        self,
        envelope: RuntimeEnvelope,
        goal: Optional[str] = None,
        style: Optional[str] = None,
        confidence: Optional[float] = None,
    ) -> ActionPlan:
        return ActionPlan(
            primary_goal=goal or "digest_opener",
            response_strategy="inform",
            expression_style=style or "warm",
            speak_mode="warm_respond",
            can_speak=True,
            should_pause=True,
            allow_followup=True,
            followup_hook="topic_continue",
            confidence=confidence if confidence is not None else 0.4,
            reasoning_summary="[proactive:digest_opener] new digest available",
            emotion_priority="low",
        )
