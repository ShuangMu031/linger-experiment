from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class ActionStep:
    step_id: str
    action_type: str
    target: str
    reason: str = ""
    status: str = "planned"
    result_summary: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step_id": self.step_id,
            "action_type": self.action_type,
            "target": self.target,
            "reason": self.reason,
            "status": self.status,
            "result_summary": self.result_summary,
        }


FROZEN_FIELDS: Tuple[str, ...] = (
    "primary_goal",
    "secondary_goals",
    "response_strategy",
    "should_ask_question",
    "should_comfort",
    "should_avoid",
    "state_writes",
    "allow_drift",
    "expression_style",
    "confidence",
    "reasoning_summary",
    "can_speak",
    "should_pause",
    "speak_mode",
    "allow_followup",
    "pause_required",
    "max_sentences",
    "followup_hook",
    "emotion_priority",
)


@dataclass
class ActionPlan:
    primary_goal: str = ""
    secondary_goals: List[str] = field(default_factory=list)
    response_strategy: str = ""
    should_ask_question: bool = False
    should_comfort: bool = False
    should_avoid: List[str] = field(default_factory=list)
    state_writes: List[Dict[str, Any]] = field(default_factory=list)
    allow_drift: bool = False
    expression_style: str = "neutral"
    confidence: float = 0.0
    reasoning_summary: str = ""
    can_speak: bool = True
    should_pause: bool = False
    speak_mode: str = "normal"
    allow_followup: bool = False
    pause_required: bool = False
    max_sentences: int = 3
    followup_hook: str = ""
    emotion_priority: str = "low"

    module_outputs: Dict[str, Any] = field(default_factory=dict)
    planned_steps: List[ActionStep] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "primary_goal": self.primary_goal,
            "secondary_goals": self.secondary_goals,
            "response_strategy": self.response_strategy,
            "should_ask_question": self.should_ask_question,
            "should_comfort": self.should_comfort,
            "should_avoid": self.should_avoid,
            "state_writes": self.state_writes,
            "allow_drift": self.allow_drift,
            "expression_style": self.expression_style,
            "confidence": self.confidence,
            "reasoning_summary": self.reasoning_summary,
            "can_speak": self.can_speak,
            "should_pause": self.should_pause,
            "speak_mode": self.speak_mode,
            "allow_followup": self.allow_followup,
            "pause_required": self.pause_required,
            "max_sentences": self.max_sentences,
            "followup_hook": self.followup_hook,
            "emotion_priority": self.emotion_priority,
        }

    def to_full_dict(self) -> Dict[str, Any]:
        d = self.to_dict()
        d["module_outputs"] = self.module_outputs
        d["planned_steps"] = [s.to_dict() for s in self.planned_steps]
        return d
