import re
from typing import List, Optional

from linger_core.tools.tool_types import ToolRequest


_TIME_PATTERNS = re.compile(
    r"几点|多久|过了|时间|第几|现在.*时|what time|how long|when|current time",
    re.IGNORECASE,
)

_MEMORY_PATTERNS = re.compile(
    r"你还记得|上次|之前|以前|回忆|记得|说过|聊过|remember|last time|before|recall|mentioned",
    re.IGNORECASE,
)

_WORLD_PATTERNS = re.compile(
    r"在哪里|周围|附近|天气|什么地|NPC|场景|世界状态|where|around|nearby|weather|scene",
    re.IGNORECASE,
)


class ToolRequestPlanner:
    def __init__(self) -> None:
        self._rules = [
            (_TIME_PATTERNS, "time_tool", {}),
            (_MEMORY_PATTERNS, "memory_search_tool", {"source": "all"}),
            (_WORLD_PATTERNS, "world_state_tool", {}),
        ]

    def plan(self, user_message: str) -> List[ToolRequest]:
        if not user_message or not user_message.strip():
            return []

        requests: List[ToolRequest] = []
        for pattern, tool_name, default_args in self._rules:
            if pattern.search(user_message):
                args = dict(default_args)
                if tool_name == "memory_search_tool":
                    args["query"] = user_message[:50]
                requests.append(ToolRequest(
                    tool_name=tool_name,
                    arguments=args,
                    requester="tool_request_planner",
                    reason=f"keyword match for {tool_name}",
                ))

        return requests
