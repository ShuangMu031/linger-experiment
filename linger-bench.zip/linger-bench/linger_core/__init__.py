"""
linger_core - Unified Timeline-based White-box Emotional World Interaction System

Architecture Principles:
  1. Single Decision Path: All responses go through SupervisorKernel -> DecisionMerger -> ResponseBuilder.
     No module may bypass this chain to produce output directly.
  2. Three-Layer Memory: short_term -> event_memory -> long_term/profile.
     New memory requirements must reuse existing layers, not create parallel systems.
  3. Rule Categories: lifecycle (expiry/decay/archive) / interaction (rhythm/followup) / world (tick/weather/npc).
     New rules must declare their category via BaseRule.category().
  4. World-Memory Bridge: WorldEventBridge is the only path from world events into EventMemory.
     World events do not create their own memory system.
  5. Trigger Constraint: Triggers produce candidates only. They never send messages directly.
"""

__version__ = "0.4.0a14"

