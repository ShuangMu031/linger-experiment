# CONTEXT_BUNDLE_SPEC — the_new_world v0.4.0a14

> **性质**：ContextBundle 的字段与构造规则冻结文档。  
> **适用范围**：ContextAssembler、SupervisorKernel、ProactivePlanner、ResponseBuilder。

---

## 1. ContextBundle 固化字段

| 字段 | 类型 | 来源 | 含义 |
|------|------|------|------|
| `recent_context` | `RecentContextBundle?` | ShortTermRecall | 最近的短期记忆上下文 |
| `event_context` | `EventContextBundle?` | EventRecall | 当前消息的事件匹配结果 |
| `profile_context` | `Dict?` | ProfileState.to_dict() | 用户画像快照 |
| `digest_context` | `Dict?` | DigestRecall | 最近的摘要信息 |
| `startup_context` | `Dict?` | StartupContextBuilder | 启动/回归时的长期记忆摘要 |
| `world_context` | `Dict?` | WorldSnapshotBuilder | 世界状态快照（场景、天气、NPC等） |
| `session_context` | `Dict` | SessionState | 会话状态：session_id、turn_id、idle_seconds、last_speaker 等 |
| `plan_context` | `Dict` | PlanState | 计划状态：active_plans、pending_followups、outbound_candidates |
| `assembly_errors` | `List[str]` | ContextAssembler | 上下文组装过程中的异常记录 |

---

## 2. 构造规则

```
ContextAssembler.build(state, envelope):
  1. recent_context = ShortTermRecall.recall(state.short_term_memory)
  2. event_context   = EventRecall.recall(state.event_memory, current_message=envelope.text)
                            （仅在 envelope.text 非空时执行）
  3. profile_context = state.profile_state.to_dict()
                            （仅在 state.profile_state 存在时）
  4. digest_context  = DigestRecall(state.digest_generator.get_all()).get_latest()
                            （异常时记为 assembly_errors）
  5. startup_context = StartupContextBuilder.build(state)
                            （仅在 profile_state.active_ltm_count > 0 时；异常时记为 assembly_errors）
  6. world_context   = WorldSnapshotBuilder.build(place_registry)
                            （仅在 world_snapshot_builder 存在时；异常时记为 assembly_errors）
  7. session_context = 从 state.session 提取
  8. plan_context    = 从 state.plan_state 提取
```

---

## 3. 传播路径

```
RuntimeOrchestrator.handle_envelope
  → ContextAssembler.build → ContextBundle
    → SupervisorKernel.process(context_bundle=context_bundle)
      → 优先使用 bundle 的 recent_context / startup_context / world_context
      → 避免重复调用 ShortTermRecall / StartupContextBuilder / WorldSnapshotBuilder
    → ResponseBuilder.build(recent_context=..., event_context=..., world_context=...)
    → ProactivePlanner.process_candidate(context_bundle=...)
```

---

## 4. 不可破坏规则

- ContextBundle 由 ContextAssembler 唯一构造
- SupervisorKernel 接收 context_bundle 后不得另建召回路径
- ResponseBuilder 只能消费 ContextBundle，不得修改它
- `assembly_errors` 用于调试，不得驱动流程分支
- `session_context` 和 `plan_context` 始终保持最新（每次 build 都从 state 提取）
