from dataclasses import dataclass, field
from typing import Any, Dict


@dataclass
class PromptContext:
    user_text: str = ""
    envelope_source: str = ""
    action_goal: str = ""
    response_strategy: str = ""
    persona_name: str = "沈鹿溪"
    recent_context_summary: str = ""
    event_context_summary: str = ""
    world_context_summary: str = ""
    relationship_summary: str = ""
    runtime_flags: Dict[str, Any] = field(default_factory=dict)
