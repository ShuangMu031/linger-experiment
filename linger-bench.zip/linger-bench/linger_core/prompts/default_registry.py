from .prompt_registry import PromptTemplate


def default_prompt_registry():
    from .response_prompt import create_response_prompt, create_proactive_prompt
    from .emotion_prompt import create_emotion_prompt
    from .context_check_prompt import create_context_check_prompt
    from .anchor_date_prompt import create_anchor_date_prompt
    from .prompt_registry import PromptRegistry

    reg = PromptRegistry()
    reg.register(create_response_prompt())
    reg.register(create_proactive_prompt())
    reg.register(create_emotion_prompt())
    reg.register(create_context_check_prompt())
    reg.register(create_anchor_date_prompt())
    return reg
