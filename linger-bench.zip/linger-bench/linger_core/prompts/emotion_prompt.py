from .prompt_registry import PromptTemplate


def create_emotion_prompt() -> PromptTemplate:
    return PromptTemplate(
        name="emotion_insight",
        system="""你是情绪分析模块。根据用户消息和近期上下文，按 Plutnik 八情绪
模型独立给每个维度 0-100 分。每个维度可以同时高分；不要只挑一个。

输出必须严格按以下 JSON 格式，不要输出其他内容：
{
  "dimensions": {
    "joy": 0-100,
    "sadness": 0-100,
    "anger": 0-100,
    "fear": 0-100,
    "trust": 0-100,
    "disgust": 0-100,
    "surprise": 0-100,
    "anticipation": 0-100
  },
  "dominant": "joy|sadness|anger|fear|trust|disgust|surprise|anticipation",
  "needs_support": true|false,
  "risk_level": "low|medium|high",
  "short_reason": "简短判断理由"
}""",
        developer="",
        user="{user_text}",
    )
