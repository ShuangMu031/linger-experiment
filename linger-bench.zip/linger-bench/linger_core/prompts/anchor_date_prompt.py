"""§5.1.2 anchor_date 抽取 prompt（spec §4.4）— cheap LLM。

输入：reference_date（基准时间）+ user_text
输出 JSON：{"anchor_date": "YYYY-MM-DD" 或 null, "reason": "≤30 字"}
"""
from .prompt_registry import PromptTemplate


def create_anchor_date_prompt() -> PromptTemplate:
    return PromptTemplate(
        name="anchor_date_extract",
        system="""你的任务：从一段对话中识别**未来时间点**并返回 ISO 8601 日期。

规则：
- 若文本中含未来时间表达（"五月""下周""周三""明天""15 号""三天后"等），返回该日期。
- 若有多个，返回**最近**的一个。
- 若是过去时间或无明确时间，返回 null。
- 解析时**以 reference_date 为基准**（年份相对、星期相对都参考它）。

只输出 JSON：{"anchor_date": "YYYY-MM-DD" 或 null, "reason": "≤30 字"}""",
        developer="",
        user="reference_date: {reference_date}\nuser_text: {user_text}",
    )
