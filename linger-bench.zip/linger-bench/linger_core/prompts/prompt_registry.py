import hashlib
from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class PromptTemplate:
    name: str
    system: str
    developer: str
    user: str
    version: str = "v1"

    @property
    def prompt_hash(self) -> str:
        material = f"{self.name}|{self.version}|{self.system}|{self.developer}|{self.user}"
        return hashlib.sha256(material.encode("utf-8")).hexdigest()[:16]

    def metadata_dict(self) -> Dict[str, str]:
        return {
            "_prompt_id": self.name,
            "_prompt_version": self.version,
            "_prompt_hash": self.prompt_hash,
        }


@dataclass
class PromptMetadata:
    name: str
    version: str
    prompt_hash: str


class PromptRegistry:
    def __init__(self) -> None:
        self._templates: Dict[str, PromptTemplate] = {}
        self._hashes: Dict[str, str] = {}

    def register(self, template: PromptTemplate) -> None:
        self._templates[template.name] = template
        self._hashes[template.name] = template.prompt_hash

    def get(self, name: str) -> PromptTemplate:
        if name not in self._templates:
            raise KeyError(f"Prompt template not found: {name}")
        return self._templates[name]

    def get_metadata(self, name: str) -> PromptMetadata:
        tmpl = self.get(name)
        return PromptMetadata(name=tmpl.name, version=tmpl.version, prompt_hash=tmpl.prompt_hash)

    def list_names(self) -> List[str]:
        return list(self._templates.keys())

    def manifest(self) -> List[Dict[str, str]]:
        return [
            {"name": n, "version": t.version, "hash": t.prompt_hash}
            for n, t in self._templates.items()
        ]
