from .prompt_registry import PromptTemplate


def create_context_check_prompt() -> PromptTemplate:
    return PromptTemplate(
        name="context_check",
        system="""你是上下文检查模块。根据用户消息、系统状态、近期上下文，判断当前需要什么。

输出必须严格按以下 JSON 格式：
{"needs_memory_recall": true|false, "needs_event_recall": true|false, "needs_world_context": true|false, "needs_clarification": true|false, "short_reason": "简短理由"}""",
        developer="",
        user="user_message: {user_text}\npending_plans: {pending_plans}\npending_followups: {pending_followups}\nidle_seconds: {idle_seconds}",
    )
