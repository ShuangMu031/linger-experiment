from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.core.state.base_state import BaseState


@dataclass
class ProfileState(BaseState):
    profile_id: str = ""
    active_ltm_count: int = 0
    high_confidence_count: int = 0
    dominant_emotion: str = "neutral"
    preferred_style: str = "balanced"
    top_topics: List[str] = field(default_factory=list)
    risk_flags: List[str] = field(default_factory=list)
    last_profile_build_at: Optional[datetime] = None
    last_digest_3d_at: Optional[datetime] = None
    last_digest_7d_at: Optional[datetime] = None
    relationship_stage: str = "stranger"
    familiarity: float = 0.3
    trust_level: float = 0.3
    warmth: float = 0.5
    preferred_distance: str = "moderate"
    ltm_category_counts: Dict[str, int] = field(default_factory=dict)

    def update_from_profile_snapshot(self, snapshot: Any) -> None:
        self.profile_id = snapshot.profile_id
        self.dominant_emotion = snapshot.dominant_emotion()
        self.preferred_style = snapshot.preferred_style()
        self.top_topics = snapshot.top_topics(3)
        self.risk_flags = list(snapshot.recent_risk_flags)
        self.last_profile_build_at = datetime.now()
        self.touch()

    def update_from_relationship(self, relationship: Any) -> None:
        self.relationship_stage = relationship.relationship_stage
        self.familiarity = relationship.familiarity
        self.trust_level = relationship.trust_level
        self.warmth = relationship.warmth
        self.preferred_distance = relationship.preferred_distance
        self.touch()

    def update_from_ltm_store(self, store: Any) -> None:
        from linger_core.shared.enums import LongTermMemoryCategory

        self.active_ltm_count = store.active_count
        self.high_confidence_count = len(store.get_high_confidence())
        self.ltm_category_counts = {}
        for cat in LongTermMemoryCategory:
            entries = store.get_by_category(cat)
            if entries:
                self.ltm_category_counts[cat.value] = len(entries)
        self.touch()

    def to_dict(self) -> Dict[str, Any]:
        base = super().to_dict()
        base.update({
            "profile_id": self.profile_id,
            "active_ltm_count": self.active_ltm_count,
            "high_confidence_count": self.high_confidence_count,
            "dominant_emotion": self.dominant_emotion,
            "preferred_style": self.preferred_style,
            "top_topics": self.top_topics,
            "risk_flags": self.risk_flags,
            "last_profile_build_at": self.last_profile_build_at.isoformat() if self.last_profile_build_at else None,
            "last_digest_3d_at": self.last_digest_3d_at.isoformat() if self.last_digest_3d_at else None,
            "last_digest_7d_at": self.last_digest_7d_at.isoformat() if self.last_digest_7d_at else None,
            "relationship_stage": self.relationship_stage,
            "familiarity": self.familiarity,
            "trust_level": self.trust_level,
            "warmth": self.warmth,
            "preferred_distance": self.preferred_distance,
            "ltm_category_counts": self.ltm_category_counts,
        })
        return base
