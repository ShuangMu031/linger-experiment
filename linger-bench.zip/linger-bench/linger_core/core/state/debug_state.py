from dataclasses import dataclass, field
from typing import List, Dict, Any

from linger_core.core.state.base_state import BaseState


@dataclass
class DebugState(BaseState):
    last_events: List[Dict[str, Any]] = field(default_factory=list)
    tick_history: List[Dict[str, Any]] = field(default_factory=list)
    errors: List[Dict[str, Any]] = field(default_factory=list)
    max_event_history: int = 100

    def record_event(self, event: Dict[str, Any]) -> None:
        self.last_events.append(event)
        if len(self.last_events) > self.max_event_history:
            self.last_events = self.last_events[-self.max_event_history:]
        self.touch()

    def record_tick(self, tick: Dict[str, Any]) -> None:
        self.tick_history.append(tick)
        if len(self.tick_history) > self.max_event_history:
            self.tick_history = self.tick_history[-self.max_event_history:]
        self.touch()

    def record_error(self, error: Dict[str, Any]) -> None:
        self.errors.append(error)
        self.touch()
