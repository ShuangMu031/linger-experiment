from dataclasses import dataclass, field
from typing import Dict, Any, Optional

from linger_core.core.clock.world_clock import WorldClock
from linger_core.core.state.session_state import SessionState
from linger_core.core.state.user_state import UserState
from linger_core.core.state.emotion_state import EmotionState
from linger_core.core.state.memory_state import MemoryState
from linger_core.core.state.plan_state import PlanState
from linger_core.core.state.debug_state import DebugState
from linger_core.config.default_config import DefaultConfig
from linger_core.config.time_config import TimeConfig
from linger_core.memory.short_term_memory import ShortTermMemory
from linger_core.memory.event_memory_store import EventMemoryStore
from linger_core.memory.long_term_memory_store import LongTermMemoryStore
from linger_core.memory.digest_generator import DigestGenerator
from linger_core.memory.relationship_tracker import RelationshipTracker
from linger_core.memory.profile_builder import ProfileBuilder
from linger_core.core.state.profile_state import ProfileState
from linger_core.core.state.inner_life_state import InnerLifeState
from linger_core.shared.enums import EventStatus
from linger_core.world.world_runtime_state import WorldRuntimeState
from linger_core.world.place_state import PlaceState
from linger_core.world.ambient_state import AmbientState
from linger_core.world.npc_registry import NpcRegistry
from linger_core.world.world_event_store import WorldEventStore
from linger_core.world.world_event_generator import WorldEventGenerator
from linger_core.world.world_event_recall import WorldEventRecall
from linger_core.world.world_snapshot_builder import WorldSnapshotBuilder
from linger_core.world.world_event_bridge import WorldEventBridge


@dataclass
class RuntimeState:
    clock: WorldClock = field(default_factory=WorldClock)
    session: SessionState = field(default_factory=SessionState)
    user_state: UserState = field(default_factory=UserState)
    emotion_state: EmotionState = field(default_factory=EmotionState)
    memory_state: MemoryState = field(default_factory=MemoryState)
    plan_state: PlanState = field(default_factory=PlanState)
    debug_state: DebugState = field(default_factory=DebugState)
    short_term_memory: ShortTermMemory = field(default_factory=ShortTermMemory)
    event_memory: EventMemoryStore = field(default_factory=EventMemoryStore)
    long_term_memory: LongTermMemoryStore = field(default_factory=LongTermMemoryStore)
    digest_generator: DigestGenerator = field(default_factory=DigestGenerator)
    relationship_tracker: RelationshipTracker = field(default_factory=RelationshipTracker)
    profile_builder: ProfileBuilder = field(default_factory=ProfileBuilder)
    profile_state: ProfileState = field(default_factory=ProfileState)
    inner_life_state: InnerLifeState = field(default_factory=InnerLifeState)
    world_runtime: WorldRuntimeState = field(default_factory=WorldRuntimeState)
    place_registry: Dict[str, PlaceState] = field(default_factory=dict)
    ambient_state: AmbientState = field(default_factory=AmbientState)
    npc_registry: NpcRegistry = field(default_factory=NpcRegistry)
    world_event_store: WorldEventStore = field(default_factory=WorldEventStore)
    world_event_generator: Optional[WorldEventGenerator] = None
    world_event_recall: Optional[WorldEventRecall] = None
    world_snapshot_builder: Optional[WorldSnapshotBuilder] = None
    world_event_bridge: Optional[WorldEventBridge] = None
    _config: DefaultConfig = field(default_factory=DefaultConfig)
    _time_config: TimeConfig = field(default_factory=TimeConfig)

    @property
    def config(self) -> DefaultConfig:
        return self._config

    @property
    def time_config(self) -> TimeConfig:
        return self._time_config

    def register_place(self, place: PlaceState) -> None:
        if place.place_id and place.place_id not in self.place_registry:
            self.place_registry[place.place_id] = place

    def remove_place(self, place_id: str) -> bool:
        if place_id in self.place_registry:
            place = self.place_registry[place_id]
            if place.linked_npc_ids:
                return False
            del self.place_registry[place_id]
            return True
        return False

    def get_place(self, place_id: str) -> Optional[PlaceState]:
        return self.place_registry.get(place_id)

    def snapshot(self) -> Dict[str, Any]:
        return {
            "clock": self.clock.snapshot(),
            "session": {
                "session_id": self.session.session_id,
                "conversation_id": self.session.conversation_id,
                "status": self.session.status.value,
                "idle_seconds": self.session.idle_seconds(),
                "is_user_present": self.session.is_user_present,
            },
            "emotion": {
                "current": self.emotion_state.current_emotion.value,
                "intensity": self.emotion_state.intensity,
            },
            "world": {
                "scene_id": self.world_runtime.current_scene_id,
                "place_id": self.world_runtime.current_place_id,
                "time_of_day": self.world_runtime.time_of_day.value,
                "day_index": self.world_runtime.day_index,
                "weather": self.world_runtime.weather,
                "ambient_mood": self.world_runtime.ambient_mood,
                "summary": self.world_runtime.last_world_summary,
                "last_tick_at": (
                    self.world_runtime.last_world_tick_at.isoformat()
                    if self.world_runtime.last_world_tick_at else None
                ),
                "world_events": {
                    "total": self.world_event_store.count,
                    "active": self.world_event_store.active_count,
                },
                "npcs": {
                    "total": self.npc_registry.count,
                    "ids": self.npc_registry.active_npc_ids,
                },
            },
            "plans_active": len(self.plan_state.active_plans),
            "event_memory": {
                "total": self.event_memory.count,
                "active": self.event_memory.active_count,
                "resolved": len(self.event_memory.get_by_status(EventStatus.RESOLVED)),
                "archived": len(self.event_memory.get_by_status(EventStatus.ARCHIVED)),
                "top_event_id": self.memory_state.top_event_id,
                "top_unresolved_score": max(
                    (e.unresolved_score for e in self.event_memory.get_unresolved()),
                    default=0.0,
                ),
            },
            "long_term_memory": {
                "total": self.long_term_memory.count,
                "active": self.long_term_memory.active_count,
                "high_confidence": len(self.long_term_memory.get_high_confidence()),
            },
            "inner_life": {
                "circadian_phase": self.inner_life_state.circadian_phase.value,
                "mood_baseline": self.inner_life_state.mood_baseline.to_dict(),
                "attention_count": len(self.inner_life_state.attention_focus),
                "impulse_pressure": self.inner_life_state.impulse_pressure,
            },
            "profile": {
                "profile_id": self.profile_state.profile_id,
                "dominant_emotion": self.profile_state.dominant_emotion,
                "preferred_style": self.profile_state.preferred_style,
                "relationship_stage": self.profile_state.relationship_stage,
                "familiarity": self.profile_state.familiarity,
                "trust_level": self.profile_state.trust_level,
                "warmth": self.profile_state.warmth,
                "risk_flags": self.profile_state.risk_flags,
            },
        }


def create_empty_runtime(
    config: Optional[DefaultConfig] = None,
    time_config: Optional[TimeConfig] = None,
) -> RuntimeState:
    tc = time_config or TimeConfig()
    cfg = config or DefaultConfig()
    clock = WorldClock(_time_config=tc)
    state = RuntimeState(clock=clock, _config=cfg, _time_config=tc)

    from linger_core.world.place_state import DEFAULT_PLACES
    for place in DEFAULT_PLACES:
        state.place_registry[place.place_id] = place
    state.npc_registry.initialize_defaults()

    state.world_event_generator = WorldEventGenerator(
        event_store=state.world_event_store,
        npc_registry=state.npc_registry,
    )
    state.world_event_recall = WorldEventRecall(
        event_store=state.world_event_store,
    )
    state.world_snapshot_builder = WorldSnapshotBuilder(
        world_runtime=state.world_runtime,
        npc_registry=state.npc_registry,
        event_recall=state.world_event_recall,
    )
    state.world_event_bridge = WorldEventBridge(
        world_store=state.world_event_store,
        event_store=state.event_memory,
        min_user_relevance=state.config.proactive.world_event_bridge_min_relevance,
        min_importance=state.config.proactive.world_event_bridge_min_importance,
    )

    return state
