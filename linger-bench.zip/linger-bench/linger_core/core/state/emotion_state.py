from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from linger_core.core.state.base_state import BaseState
from linger_core.shared.enums import EmotionType
from linger_core.shared.utils import clamp


@dataclass
class EmotionState(BaseState):
    current_emotion: EmotionType = EmotionType.NEUTRAL
    intensity: float = 0.5
    last_refresh_at: datetime = field(default_factory=datetime.now)
    decay_rate: float = 0.02

    def decay(self, delta_seconds: float) -> float:
        old_intensity = self.intensity
        self.intensity = clamp(
            self.intensity * (1.0 - self.decay_rate * delta_seconds / 60.0),
            low=0.05,
            high=1.0
        )
        self.touch()
        return old_intensity

    def set_emotion(self, emotion: EmotionType, intensity: float, real_now: Optional[datetime] = None) -> None:
        self.current_emotion = emotion
        self.intensity = clamp(intensity)
        self.last_refresh_at = real_now or datetime.now()
        self.touch()
