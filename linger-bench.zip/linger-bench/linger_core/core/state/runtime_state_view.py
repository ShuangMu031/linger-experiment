from dataclasses import dataclass

from linger_core.core.state.runtime_state import RuntimeState
from linger_core.core.state.views import (
    ClockView,
    ConfigView,
    EmotionView,
    MemoryView,
    PlanView,
    ProfileView,
    RelationshipView,
    SessionView,
    WorldView,
)
from linger_core.core.state.views.inner_life_view import InnerLifeView


@dataclass(frozen=True)
class RuntimeStateView:
    """RuntimeState 的只读快照（god-object 的读边界）。

    构造时一次性冻结所有需要的字段。一个 turn / tick 内只构造一次，
    沿调用链下传。任何业务函数（trigger / rule / supervisor 等）应只接 view，
    不接 RuntimeState。

    写仍只走 WritebackManager。
    """

    clock: ClockView
    session: SessionView
    emotion: EmotionView
    memory: MemoryView
    relationship: RelationshipView
    profile: ProfileView
    world: WorldView
    plan: PlanView
    config: ConfigView
    inner_life: InnerLifeView

    @classmethod
    def from_state(cls, state: RuntimeState) -> "RuntimeStateView":
        clock_view = ClockView.from_clock(state.clock)
        return cls(
            clock=clock_view,
            session=SessionView.from_session(
                state.session, real_now=clock_view.real_now
            ),
            emotion=EmotionView.from_emotion(state.emotion_state),
            memory=MemoryView.from_stores(
                short_term=state.short_term_memory,
                event_memory=state.event_memory,
                long_term=state.long_term_memory,
                digest=state.digest_generator,
                memory_state=state.memory_state,
            ),
            relationship=RelationshipView.from_tracker(state.relationship_tracker),
            profile=ProfileView.from_profile(state.profile_state),
            world=WorldView.from_world(
                runtime=state.world_runtime,
                npcs=state.npc_registry,
                events=state.world_event_store,
                ambient_state=state.ambient_state,
                snapshot_builder=state.world_snapshot_builder,
                place_registry=state.place_registry,
            ),
            plan=PlanView.from_plan_state(state.plan_state),
            config=ConfigView.from_configs(
                config=state.config,
                time_config=state.time_config,
            ),
            inner_life=InnerLifeView(state.inner_life_state),
        )
