from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, Dict, Any


@dataclass
class BaseState:
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    last_accessed_at: datetime = field(default_factory=datetime.now)
    expires_at: Optional[datetime] = None
    decay_rate: float = 0.0
    importance: float = 0.5

    def touch(self, real_now: Optional[datetime] = None) -> None:
        now = real_now or datetime.now()
        self.last_accessed_at = now
        self.updated_at = now

    def is_expired(self, world_now: Optional[datetime] = None) -> bool:
        if self.expires_at is None:
            return False
        now = world_now or datetime.now()
        return now > self.expires_at

    def to_dict(self) -> Dict[str, Any]:
        return {
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "last_accessed_at": self.last_accessed_at.isoformat(),
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "decay_rate": self.decay_rate,
            "importance": self.importance,
        }
