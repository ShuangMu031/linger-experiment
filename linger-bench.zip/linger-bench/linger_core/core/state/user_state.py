from dataclasses import dataclass, field
from typing import Optional, Dict, Any

from linger_core.core.state.base_state import BaseState


@dataclass
class UserState(BaseState):
    user_id: str = "default_user"
    profile_stub: Dict[str, Any] = field(default_factory=dict)
    recent_activity_summary: str = ""

    def update_activity(self, summary: str) -> None:
        self.recent_activity_summary = summary
        self.touch()
