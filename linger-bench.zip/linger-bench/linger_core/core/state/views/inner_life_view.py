"""InnerLifeView — read-only 接口，遵守 §4.1 RuntimeStateView 纪律。

view 不暴露任何写方法。trigger / orchestrator / rules / foreground 通过此 view 读 InnerLife。
"""
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from linger_core.core.emotion.emotion_dimensions import EmotionVector
from linger_core.core.state.inner_life_state import (
    CircadianPhase,
    InnerLifeState,
)


# 与 InnerImpulseConfig 默认值对齐（spec §4.7）；view 只做粗略诊断
_PRESSURE_THRESHOLD: int = 70
_MIN_INTERVAL_SECONDS: int = 7200


class InnerLifeView:
    def __init__(self, state: InnerLifeState) -> None:
        self._state = state

    def baseline_emotion(self) -> EmotionVector:
        return self._state.mood_baseline

    def attention_focus(self) -> List[Dict[str, Any]]:
        return [
            {
                "event_id": a.event_id,
                "summary": a.summary,
                "dominant_emotion": a.dominant_emotion.value,
                "intensity": a.intensity,
                "set_at": a.set_at.isoformat(),
            }
            for a in self._state.attention_focus
        ]

    def impulse_pressure(self) -> int:
        return self._state.impulse_pressure

    def circadian_phase(self) -> CircadianPhase:
        return self._state.circadian_phase

    def last_proactive_at(self) -> Optional[datetime]:
        return self._state.last_proactive_at

    def can_proactive_now(self, real_now: datetime) -> Tuple[bool, str]:
        if self._state.impulse_pressure < _PRESSURE_THRESHOLD:
            return False, (
                f"pressure {self._state.impulse_pressure} below threshold "
                f"{_PRESSURE_THRESHOLD}"
            )
        if self._state.last_proactive_at is not None:
            delta_s = (real_now - self._state.last_proactive_at).total_seconds()
            if delta_s < _MIN_INTERVAL_SECONDS:
                return False, (
                    f"throttle: interval {delta_s:.0f}s below minimum "
                    f"{_MIN_INTERVAL_SECONDS}s"
                )
        return True, "ok"

    def snapshot(self) -> Dict[str, Any]:
        return {
            "circadian_phase": self._state.circadian_phase.value,
            "mood_baseline": self._state.mood_baseline.to_dict(),
            "attention_focus": self.attention_focus(),
            "impulse_pressure": self._state.impulse_pressure,
            "last_proactive_at": (
                self._state.last_proactive_at.isoformat()
                if self._state.last_proactive_at else None
            ),
            "silence_since": self._state.silence_since.isoformat(),
        }
