from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from linger_core.core.state.session_state import SessionState
from linger_core.shared.enums import SessionStatus


@dataclass(frozen=True)
class SessionView:
    """SessionState 的只读快照。idle_seconds 是冻结时刻的预计算值。"""

    session_id: str
    conversation_id: str
    status: SessionStatus
    is_user_present: bool
    last_active_at: Optional[datetime]
    last_user_end_signal: bool
    idle_seconds_at_freeze: float
    consecutive_assistant_turns: int
    last_speaker: str
    waiting_for_user_reply: bool
    assistant_messages_since_user: int
    assistant_proactive_streak: int

    @classmethod
    def from_session(cls, session: SessionState, real_now: datetime) -> "SessionView":
        return cls(
            session_id=session.session_id,
            conversation_id=session.conversation_id,
            status=session.status,
            is_user_present=session.is_user_present,
            last_active_at=session.last_active_at,
            last_user_end_signal=session.last_user_end_signal,
            idle_seconds_at_freeze=session.idle_seconds(real_now=real_now),
            consecutive_assistant_turns=session.consecutive_assistant_turns,
            last_speaker=session.last_speaker,
            waiting_for_user_reply=session.waiting_for_user_reply,
            assistant_messages_since_user=session.assistant_messages_since_user,
            assistant_proactive_streak=session.assistant_proactive_streak,
        )
