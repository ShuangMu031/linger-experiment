"""MemoryView：short-term / event / long-term 三层记忆的只读快照。

`_xxx_store_ref` / `_xxx_ref` 字段是 escape hatch — 见同目录 world_view.py 模块顶部注释统一约定。
"""

from dataclasses import dataclass
from typing import Optional, Tuple

from linger_core.core.state.memory_state import MemoryState
from linger_core.memory.digest_bundle import DigestBundle
from linger_core.memory.digest_generator import DigestGenerator
from linger_core.memory.event_memory_entry import EventMemoryEntry
from linger_core.memory.event_memory_store import EventMemoryStore
from linger_core.memory.long_term_memory_entry import LongTermMemoryEntry
from linger_core.memory.long_term_memory_store import LongTermMemoryStore
from linger_core.memory.memory_entry import MemoryEntry
from linger_core.memory.short_term_memory import ShortTermMemory
from linger_core.shared.enums import EventStatus


@dataclass(frozen=True)
class ShortTermMemoryView:
    _latest_user: Tuple[MemoryEntry, ...]
    count: int
    _store_ref: ShortTermMemory

    def latest_user(self, n: int = 2) -> Tuple[MemoryEntry, ...]:
        return self._latest_user[-n:] if n > 0 else ()

    @classmethod
    def from_store(cls, stm: ShortTermMemory) -> "ShortTermMemoryView":
        latest = tuple(stm.get_latest_user(n=10))
        return cls(_latest_user=latest, count=stm.count, _store_ref=stm)


@dataclass(frozen=True)
class EventMemoryView:
    _active: Tuple[EventMemoryEntry, ...]
    _by_status: dict
    _unresolved: Tuple[EventMemoryEntry, ...]
    top_event_id: Optional[str]
    top_unresolved_score: float
    count: int
    active_count: int
    _store_ref: EventMemoryStore

    def active(self) -> Tuple[EventMemoryEntry, ...]:
        return self._active

    def by_status(self, status: EventStatus) -> Tuple[EventMemoryEntry, ...]:
        return self._by_status.get(status, ())

    def unresolved(self) -> Tuple[EventMemoryEntry, ...]:
        return self._unresolved

    @classmethod
    def from_store(
        cls, store: EventMemoryStore, mem_state: MemoryState
    ) -> "EventMemoryView":
        from types import MappingProxyType

        active = tuple(store.get_active())
        unresolved = tuple(store.get_unresolved())
        by_status = MappingProxyType(
            {
                status: tuple(store.get_by_status(status))
                for status in EventStatus
            }
        )
        top_unresolved = max(
            (e.unresolved_score for e in unresolved),
            default=0.0,
        )
        return cls(
            _active=active,
            _by_status=by_status,
            _unresolved=unresolved,
            top_event_id=mem_state.top_event_id,
            top_unresolved_score=top_unresolved,
            count=store.count,
            active_count=store.active_count,
            _store_ref=store,
        )


@dataclass(frozen=True)
class LongTermMemoryView:
    _high_confidence: Tuple[LongTermMemoryEntry, ...]
    count: int
    active_count: int
    high_confidence_count: int
    _latest_digest: Optional[DigestBundle]
    _digest_generator_ref: DigestGenerator
    _store_ref: LongTermMemoryStore   # ← 新增 escape hatch

    def high_confidence(self) -> Tuple[LongTermMemoryEntry, ...]:
        return self._high_confidence

    def latest_digest_bundle(self) -> Optional[DigestBundle]:
        return self._latest_digest

    @classmethod
    def from_stores(
        cls, ltm: LongTermMemoryStore, digest: DigestGenerator
    ) -> "LongTermMemoryView":
        high = tuple(ltm.get_high_confidence())
        digests = digest.get_all() if hasattr(digest, "get_all") else []
        latest = digests[-1] if digests else None
        return cls(
            _high_confidence=high,
            count=ltm.count,
            active_count=ltm.active_count,
            high_confidence_count=len(high),
            _latest_digest=latest,
            _digest_generator_ref=digest,
            _store_ref=ltm,
        )


@dataclass(frozen=True)
class MemoryView:
    short_term: ShortTermMemoryView
    events: EventMemoryView
    long_term: LongTermMemoryView

    @classmethod
    def from_stores(
        cls,
        short_term: ShortTermMemory,
        event_memory: EventMemoryStore,
        long_term: LongTermMemoryStore,
        digest: DigestGenerator,
        memory_state: MemoryState,
    ) -> "MemoryView":
        return cls(
            short_term=ShortTermMemoryView.from_store(short_term),
            events=EventMemoryView.from_store(event_memory, memory_state),
            long_term=LongTermMemoryView.from_stores(long_term, digest),
        )
