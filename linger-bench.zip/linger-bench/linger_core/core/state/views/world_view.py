"""WorldView：world_runtime / npcs / events / ambient_state 的只读快照。

Escape hatch 约定（适用于本模块所有 `_xxx_ref` / `_xxx_store_ref` 字段）：
- `_xxx_ref` / `_xxx_store_ref` 是底层对象的 **reference**，不是 snapshot——读它会反映 live state。
- 仅用于 (a) 参数化查询（如 `get_by_status(...)`）、(b) `to_dict()` pass-through、(c) post-write 在同一 rule 内读最新值。
- **不允许通过 ref 写入** state（除非该方法已是已知 mutating method、并且该 rule 本身就负责写）。
- 字段名 `_` 前缀提示"绕过冻结语义"——用前先想清楚是不是真的需要。
"""
from dataclasses import dataclass
from datetime import datetime
from typing import Mapping, Optional, Tuple

from linger_core.shared.enums import TimeOfDay
from linger_core.world.ambient_state import AmbientState
from linger_core.world.npc_registry import NpcRegistry
from linger_core.world.place_state import PlaceState
from linger_core.world.world_event_entry import WorldEventEntry
from linger_core.world.world_event_store import WorldEventStore
from linger_core.world.world_runtime_state import WorldRuntimeState
from linger_core.world.world_snapshot_builder import WorldSnapshotBuilder


@dataclass(frozen=True)
class AmbientStateView:
    """AmbientState 的只读快照（业务层 mood/energy/social_density 的真实来源）。"""

    mood: str
    energy_level: float
    social_density: float
    novelty: float
    pressure_level: float
    last_changed_at: Optional[datetime]

    @classmethod
    def from_ambient(cls, ambient: AmbientState) -> "AmbientStateView":
        return cls(
            mood=ambient.ambient_mood,
            energy_level=ambient.energy_level,
            social_density=ambient.social_density,
            novelty=ambient.novelty,
            pressure_level=ambient.pressure_level,
            last_changed_at=ambient.last_changed_at,
        )


@dataclass(frozen=True)
class WorldView:
    scene_id: Optional[str]
    place_id: Optional[str]
    time_of_day: TimeOfDay
    day_index: int
    weather: str
    ambient_mood: str               # ← from WorldRuntimeState（保留，兼容旧 view 字段）
    summary: str
    last_tick_at: Optional[datetime]
    last_time_change_at: Optional[datetime]
    last_weather_change_at: Optional[datetime]

    ambient: AmbientStateView       # ← 新增子 view（业务层用这个）

    _npc_ids: Tuple[str, ...]
    npcs_count: int
    _events_active: Tuple[WorldEventEntry, ...]
    events_count: int
    events_active_count: int

    _snapshot_builder_ref: Optional[WorldSnapshotBuilder]
    _place_registry_ref: Mapping[str, PlaceState]
    _events_store_ref: WorldEventStore        # ← 新增 escape hatch
    _npc_registry_ref: NpcRegistry            # ← 新增 escape hatch

    def npcs(self) -> Tuple[str, ...]:
        return self._npc_ids

    def world_events_active(self) -> Tuple[WorldEventEntry, ...]:
        return self._events_active

    @classmethod
    def from_world(
        cls,
        runtime: WorldRuntimeState,
        npcs: NpcRegistry,
        events: WorldEventStore,
        ambient_state: Optional[AmbientState] = None,
        snapshot_builder: Optional[WorldSnapshotBuilder] = None,
        place_registry: Optional[Mapping[str, PlaceState]] = None,
    ) -> "WorldView":
        ambient = ambient_state if ambient_state is not None else AmbientState()
        return cls(
            scene_id=runtime.current_scene_id,
            place_id=runtime.current_place_id,
            time_of_day=runtime.time_of_day,
            day_index=runtime.day_index,
            weather=runtime.weather,
            ambient_mood=runtime.ambient_mood,
            summary=runtime.last_world_summary,
            last_tick_at=runtime.last_world_tick_at,
            last_time_change_at=runtime.last_time_change_at,
            last_weather_change_at=runtime.last_weather_change_at,
            ambient=AmbientStateView.from_ambient(ambient),
            _npc_ids=tuple(npcs.active_npc_ids),
            npcs_count=npcs.count,
            _events_active=tuple(events.get_active()),
            events_count=events.count,
            events_active_count=events.active_count,
            _snapshot_builder_ref=snapshot_builder,
            _place_registry_ref=place_registry if place_registry is not None else {},
            _events_store_ref=events,
            _npc_registry_ref=npcs,
        )
