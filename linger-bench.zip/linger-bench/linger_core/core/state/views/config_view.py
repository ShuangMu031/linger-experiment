from dataclasses import dataclass

from linger_core.config.default_config import DefaultConfig
from linger_core.config.time_config import TimeConfig


@dataclass(frozen=True)
class ConfigView:
    """配置视图。

    底层 DefaultConfig / TimeConfig 是 reference 而非快照——配置在
    启动后不修改，是"真正全局只读"的工程假设。view 自身 frozen=True
    防止替换字段；底层配置实例不深拷贝。
    """

    config: DefaultConfig
    time: TimeConfig

    @classmethod
    def from_configs(
        cls, config: DefaultConfig, time_config: TimeConfig
    ) -> "ConfigView":
        return cls(config=config, time=time_config)
