from dataclasses import dataclass
from datetime import datetime

from linger_core.core.clock.world_clock import WorldClock


@dataclass(frozen=True)
class ClockView:
    """Real / world clock 的只读快照。构造时冻结，全程不变。"""

    real_now: datetime
    world_now: datetime
    turn_id: int

    def real_now_time(self) -> datetime:
        return self.real_now

    def world_now_time(self) -> datetime:
        return self.world_now

    @classmethod
    def from_clock(cls, clock: WorldClock) -> "ClockView":
        return cls(
            real_now=clock.real_now_time(),
            world_now=clock.world_now_time(),
            turn_id=clock.logical.turn_id,
        )
