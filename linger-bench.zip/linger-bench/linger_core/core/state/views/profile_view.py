"""ProfileView：ProfileState 的只读快照。

`_state_ref: ProfileState` 是 escape hatch — 见同目录 world_view.py 模块顶部注释统一约定。
"""

from dataclasses import dataclass
from typing import Optional, Tuple

from linger_core.core.state.profile_state import ProfileState


@dataclass(frozen=True)
class ProfileView:
    profile_id: str
    dominant_emotion: Optional[str]
    preferred_style: Optional[str]
    risk_flags: Tuple[str, ...]
    active_ltm_count: int
    _state_ref: ProfileState   # reference for to_dict() pass-through; not for general mutation

    @classmethod
    def from_profile(cls, profile: ProfileState) -> "ProfileView":
        return cls(
            profile_id=profile.profile_id,
            dominant_emotion=profile.dominant_emotion,
            preferred_style=profile.preferred_style,
            risk_flags=tuple(profile.risk_flags),
            active_ltm_count=profile.active_ltm_count,
            _state_ref=profile,
        )
