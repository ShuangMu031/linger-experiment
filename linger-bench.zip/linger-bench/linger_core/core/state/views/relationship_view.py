from dataclasses import dataclass

from linger_core.memory.relationship_snapshot import RelationshipSnapshot
from linger_core.memory.relationship_tracker import RelationshipTracker


@dataclass(frozen=True)
class RelationshipView:
    """RelationshipTracker 快照视图。

    标量字段 (familiarity / trust_level / warmth) 构造时复制为冻结值。
    snapshot 字段持有原 snapshot 引用而非深拷贝 (类似 ConfigView 的 reference 折衷)：
    依赖 WritebackManager 是唯一写边界这个工程假设。
    如果未来发现 snapshot 被业务层修改造成问题，再加深拷贝。
    """

    familiarity: float
    trust_level: float
    warmth: float
    snapshot: RelationshipSnapshot   # reference, not deep copy

    @classmethod
    def from_tracker(cls, tracker: RelationshipTracker) -> "RelationshipView":
        snap = tracker.snapshot
        return cls(
            familiarity=snap.familiarity,
            trust_level=snap.trust_level,
            warmth=snap.warmth,
            snapshot=snap,
        )
