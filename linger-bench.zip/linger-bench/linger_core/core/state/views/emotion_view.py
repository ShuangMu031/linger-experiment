from dataclasses import dataclass

from linger_core.core.state.emotion_state import EmotionState
from linger_core.shared.enums import EmotionType


@dataclass(frozen=True)
class EmotionView:
    """EmotionState 的只读快照。"""

    current: EmotionType
    intensity: float

    @classmethod
    def from_emotion(cls, emotion: EmotionState) -> "EmotionView":
        return cls(
            current=emotion.current_emotion,
            intensity=emotion.intensity,
        )
