from dataclasses import dataclass
from datetime import datetime
from typing import Tuple

from linger_core.core.state.plan_state import Plan, PlanState
from linger_core.supervisor.followup_hook import FollowupHook


@dataclass(frozen=True)
class PlanView:
    """PlanView：PlanState 的只读视图。

    active_plans 在构造时冻结；check_eligible_followups 是需要外部时间参数的纯函数查询。

    `_plan_state_ref: PlanState` 是 escape hatch — 见同目录 world_view.py 模块顶部注释统一约定。
    """

    _active: Tuple[Plan, ...]
    _plan_state_ref: PlanState   # private reference for parametric queries
    pending_followups_count: int
    outbound_candidates_count: int

    def active_plans(self) -> Tuple[Plan, ...]:
        return self._active

    def check_eligible_followups(self, world_now: datetime) -> Tuple[FollowupHook, ...]:
        return tuple(self._plan_state_ref.check_eligible_followups(world_now))

    @classmethod
    def from_plan_state(cls, plan_state: PlanState) -> "PlanView":
        return cls(
            _active=tuple(plan_state.active_plans),
            _plan_state_ref=plan_state,
            pending_followups_count=len(plan_state.pending_followups),
            outbound_candidates_count=len(plan_state.outbound_candidates),
        )
