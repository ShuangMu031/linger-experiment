from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, List, Optional

from linger_core.core.state.base_state import BaseState
from linger_core.shared.enums import MemoryType


@dataclass
class MemoryRef:
    ref_id: str
    memory_type: MemoryType
    summary: str = ""
    created_at: Optional[str] = None


@dataclass
class MemoryState(BaseState):
    episodic_refs: List[MemoryRef] = field(default_factory=list)
    long_term_refs: List[MemoryRef] = field(default_factory=list)
    active_event_ids: List[str] = field(default_factory=list)
    unresolved_event_ids: List[str] = field(default_factory=list)
    resolved_event_ids: List[str] = field(default_factory=list)
    last_event_extract_at: Optional[datetime] = None
    last_event_recall_at: Optional[datetime] = None
    top_event_id: str = ""
    top_unresolved_event_id: str = ""
    event_summary_hint: str = ""

    def add_episodic(self, ref: MemoryRef) -> None:
        self.episodic_refs.append(ref)
        self.touch()

    def add_long_term(self, ref: MemoryRef) -> None:
        self.long_term_refs.append(ref)
        self.touch()

    def sync_from_event_store(self, store: Any) -> None:
        from linger_core.shared.enums import EventStatus

        self.active_event_ids = [e.event_id for e in store.get_active()]
        self.unresolved_event_ids = [e.event_id for e in store.get_unresolved()]
        self.resolved_event_ids = [e.event_id for e in store.get_by_status(EventStatus.RESOLVED)]

        active = store.get_active()
        if active:
            active.sort(key=lambda e: e.recall_priority, reverse=True)
            self.top_event_id = active[0].event_id
        else:
            self.top_event_id = ""

        unresolved = store.get_unresolved()
        if unresolved:
            unresolved.sort(key=lambda e: e.unresolved_score, reverse=True)
            self.top_unresolved_event_id = unresolved[0].event_id
        else:
            self.top_unresolved_event_id = ""

        if active:
            top = active[0]
            display = top.display_title or top.title[:20]
            self.event_summary_hint = f"[{top.event_type.value}] {display}"
        else:
            self.event_summary_hint = ""

        self.touch()
