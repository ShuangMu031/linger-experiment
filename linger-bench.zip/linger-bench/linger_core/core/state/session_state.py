from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional

from linger_core.core.state.base_state import BaseState
from linger_core.shared.enums import SessionStatus
from linger_core.shared.ids import generate_session_id

DEFAULT_SESSION_ID = "default"
DEFAULT_CONVERSATION_ID = "default"
DEFAULT_PROACTIVE_WINDOW_SECONDS = 300.0


@dataclass
class SessionState(BaseState):
    session_id: str = field(default_factory=lambda: DEFAULT_SESSION_ID)
    conversation_id: str = field(default_factory=lambda: DEFAULT_CONVERSATION_ID)
    started_at: datetime = field(default_factory=datetime.now)
    last_active_at: datetime = field(default_factory=datetime.now)
    is_user_present: bool = True
    status: SessionStatus = SessionStatus.ACTIVE
    last_speaker: str = ""
    consecutive_assistant_turns: int = 0
    assistant_messages_since_user: int = 0
    assistant_proactive_streak: int = 0
    waiting_for_user_reply: bool = False
    last_assistant_message_at: Optional[datetime] = None
    last_user_end_signal: bool = False
    recent_proactive_count: int = 0
    recent_proactive_window_started_at: datetime = field(default_factory=datetime.now)
    last_event_turn_id: int = 0
    last_user_topic_key: str = ""
    last_resolved_event_id: str = ""

    def mark_active(self, real_now: Optional[datetime] = None) -> None:
        self.last_active_at = real_now or datetime.now()
        self.is_user_present = True
        self.status = SessionStatus.ACTIVE
        self.touch()

    def mark_idle(self) -> None:
        self.is_user_present = False
        self.status = SessionStatus.IDLE
        self.touch()

    def close(self) -> None:
        self.status = SessionStatus.CLOSED
        self.is_user_present = False
        self.touch()

    def mark_assistant_proactive_sent(
        self,
        now: Optional[datetime] = None,
        proactive_window_seconds: float = DEFAULT_PROACTIVE_WINDOW_SECONDS,
    ) -> None:
        now = now or datetime.now()
        self.last_speaker = "assistant"
        self.last_assistant_message_at = now
        self.consecutive_assistant_turns += 1
        self.assistant_proactive_streak += 1
        self.assistant_messages_since_user += 1

        if (now - self.recent_proactive_window_started_at).total_seconds() > proactive_window_seconds:
            self.recent_proactive_count = 0
            self.recent_proactive_window_started_at = now
        self.recent_proactive_count += 1

        self.touch()

    def idle_seconds(self, real_now: Optional[datetime] = None) -> float:
        now = real_now or datetime.now()
        return (now - self.last_active_at).total_seconds()

    def seconds_since_assistant_message(self, real_now: Optional[datetime] = None) -> float:
        if self.last_assistant_message_at is None:
            return 0.0
        now = real_now or datetime.now()
        return (now - self.last_assistant_message_at).total_seconds()
