from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Any, TYPE_CHECKING

from linger_core.core.state.base_state import BaseState
from linger_core.supervisor.followup_hook import FollowupHook

if TYPE_CHECKING:
    from linger_core.triggers.trigger_candidate import TriggerCandidate


@dataclass
class Plan:
    plan_id: str
    description: str
    created_at: datetime = field(default_factory=datetime.now)
    expires_at: Optional[datetime] = None
    status: str = "active"
    _clock: Any = field(default=None, repr=False)

    def is_expired(self, world_now: Optional[datetime] = None) -> bool:
        if self.expires_at is None:
            return False
        now = world_now or datetime.now()
        return now > self.expires_at


@dataclass
class PlanState(BaseState):
    active_plans: List[Plan] = field(default_factory=list)
    pending_followups: List[FollowupHook] = field(default_factory=list)
    outbound_candidates: List[TriggerCandidate] = field(default_factory=list)

    def add_plan(self, plan: Plan) -> None:
        self.active_plans.append(plan)
        self.touch()

    def check_expired_plans(self, world_now: Optional[datetime] = None) -> List[Plan]:
        expired = [p for p in self.active_plans if p.is_expired(world_now)]
        self.active_plans = [p for p in self.active_plans if not p.is_expired(world_now)]
        if expired:
            self.touch()
        return expired

    def add_followup(self, hook: FollowupHook) -> None:
        self.pending_followups.append(hook)
        self.touch()

    def check_eligible_followups(self, world_now: datetime) -> List[FollowupHook]:
        eligible = []
        remaining = []
        for hook in self.pending_followups:
            if hook.is_eligible(world_now):
                eligible.append(hook)
            elif hook.status == "pending":
                remaining.append(hook)
            elif hook.status == "expired":
                pass
            else:
                remaining.append(hook)
        self.pending_followups = remaining
        if eligible:
            self.touch()
        return eligible

    def cancel_followups_for_turn(self, turn_id: int, reason: str = "user_responded") -> None:
        for hook in self.pending_followups:
            if hook.source_turn_id == turn_id and hook.status == "pending":
                hook.mark_cancelled(reason)
        self.pending_followups = [
            h for h in self.pending_followups if h.status == "pending"
        ]
        self.touch()

    def add_outbound_candidate(self, candidate: TriggerCandidate) -> None:
        self.outbound_candidates.append(candidate)
        self.touch()

    def drain_outbound_candidates(self) -> List[TriggerCandidate]:
        candidates = list(self.outbound_candidates)
        self.outbound_candidates.clear()
        if candidates:
            self.touch()
        return candidates
