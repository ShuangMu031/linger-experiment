"""InnerLifeState — 沈鹿溪的内在驱动数据结构（Phase 0 §4.3 / 工程债 #8）。

四个核心字段（spec §4.2）：
- circadian_phase     ：作息阶段（清晨/上午/午后/傍晚/夜/深夜）
- mood_baseline       ：基线情绪（8 维 0-100，慢变量）
- attention_focus     ：最近"在想"的一两件事（LRU ≤ 2 条）
- impulse_pressure    ：累积的"想说点什么"压力（0-100）

写边界（spec §7）：以下方法只能由 InnerLifeUpdateModule 调用，
trigger / orchestrator / rules / foreground 一律 view-only。
"""
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import List, Optional

from linger_core.core.emotion.decay_curve import (
    DEFAULT_DECAY_PARAMS,
    DecayParams,
    apply_decay,
)
from linger_core.core.emotion.emotion_dimensions import (
    NEUTRAL_VALUE,
    EmotionDimension,
    EmotionVector,
)
from linger_core.core.state.base_state import BaseState
from linger_core.shared.utils import clamp


class CircadianPhase(str, Enum):
    EARLY_MORNING = "清晨"
    MORNING = "上午"
    AFTERNOON = "午后"
    EVENING = "傍晚"
    NIGHT = "夜"
    LATE_NIGHT = "深夜"


@dataclass
class AttentionFocus:
    event_id: str
    summary: str
    dominant_emotion: EmotionDimension
    intensity: int
    set_at: datetime = field(default_factory=datetime.now)


_ATTENTION_LRU_CAPACITY: int = 2
_IMPULSE_FACTOR_GAIN: float = 10.0  # 单因子 1.0 → +10 分；均等权


def _replace_vector_dim(vec: EmotionVector, dim: str, value: int) -> EmotionVector:
    kwargs = vec.to_dict()
    kwargs[dim] = max(0, min(100, value))
    return EmotionVector(**kwargs)


@dataclass
class InnerLifeState(BaseState):
    circadian_phase: CircadianPhase = CircadianPhase.MORNING
    mood_baseline: EmotionVector = field(default_factory=EmotionVector.neutral)
    attention_focus: List[AttentionFocus] = field(default_factory=list)
    impulse_pressure: int = 0
    last_proactive_at: Optional[datetime] = None
    last_decay_at: datetime = field(default_factory=datetime.now)
    silence_since: datetime = field(default_factory=datetime.now)

    # ─── 写方法（仅 InnerLifeUpdateModule 可调）─────────────────────

    def apply_mood_drift(self, instant: EmotionVector, drift_coeff: float) -> None:
        """把 mood_baseline 朝 instant 线性漂移。

        new[dim] = baseline[dim] + (instant[dim] - baseline[dim]) * drift_coeff
        clamp 到 [0, 100]。drift_coeff=0 不变；=1.0 直接变成 instant。
        """
        coeff = max(0.0, min(1.0, drift_coeff))
        new_vec = self.mood_baseline
        for dim in EmotionDimension:
            base_v = getattr(new_vec, dim.value)
            instant_v = getattr(instant, dim.value)
            drifted = base_v + (instant_v - base_v) * coeff
            new_vec = _replace_vector_dim(new_vec, dim.value, int(round(drifted)))
        self.mood_baseline = new_vec
        self.touch()

    def apply_decay(
        self,
        delta_seconds: float,
        params: DecayParams = DEFAULT_DECAY_PARAMS,
    ) -> None:
        """各维向 NEUTRAL_VALUE 衰减一段时间。"""
        new_vec = self.mood_baseline
        for dim in EmotionDimension:
            cur = getattr(new_vec, dim.value)
            new_v = apply_decay(cur, delta_seconds=delta_seconds,
                                target=NEUTRAL_VALUE, params=params)
            new_vec = _replace_vector_dim(new_vec, dim.value, new_v)
        self.mood_baseline = new_vec
        self.last_decay_at = datetime.now()
        self.touch()

    def add_attention(self, focus: AttentionFocus) -> None:
        """添加 attention，超过容量 LRU 替换（最早的挤掉）。"""
        self.attention_focus.append(focus)
        if len(self.attention_focus) > _ATTENTION_LRU_CAPACITY:
            self.attention_focus = self.attention_focus[-_ATTENTION_LRU_CAPACITY:]
        self.touch()

    def accumulate_impulse(self, factors: dict) -> None:
        """累积 impulse_pressure（均等权累加，v1）。

        factors 是 {因子名: 因子值[0.0-1.0]}，各因子均等权乘以 _IMPULSE_FACTOR_GAIN
        累加进 impulse_pressure，clamp 到 [0, 100]。
        """
        total = sum(float(v) for v in factors.values())
        delta = int(round(total * _IMPULSE_FACTOR_GAIN))
        self.impulse_pressure = int(clamp(self.impulse_pressure + delta, low=0, high=100))
        self.touch()

    def release_impulse(self, real_now: datetime) -> None:
        """主动消息发出后清零 impulse + 更新 last_proactive_at + 重置 silence_since。"""
        self.impulse_pressure = 0
        self.last_proactive_at = real_now
        self.silence_since = real_now
        self.touch(real_now)
