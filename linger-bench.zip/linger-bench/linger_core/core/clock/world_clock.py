from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, Any, Optional

from linger_core.core.clock.time_types import RealTime, WorldTime, LogicalTime
from linger_core.config.time_config import TimeConfig


TIME_SOURCE_RULE = """
时间来源规范（周期三收口版）：

=== 走 real_now 的逻辑 ===
- 日志时间戳（event_logger, change_log）
- trace 时间戳（trace_store）
- 系统启动/结束记录
- 开发调试输出
- session 活跃判断（mark_active）
- 用户空闲计算（idle_seconds）
- 用户端时间差计算（delta_since_last_event, idle_since_user）
- last_assistant_message_at（用户感知的回复间隔）
- 持久化保存时间戳（repository saved_at）

=== 走 world_now 的逻辑 ===
- 世界推进、世界状态更新
- 计划到期判断（Plan.is_expired）
- 记忆过期判断（ShortTermMemory.expire_entries, MemoryEntry.is_expired）
- 关系冷却
- 情绪衰减计算
- followup hook 的 eligible_after / expires_at 判断
- 会话断开感判断
- 回来时的"欢迎回来"判断
- MemoryEntry.created_at_world / expires_at_world
- FollowupEntryExtensionRule 延寿判断
- ShortTermMemoryExpiryRule 过期判断

=== 关键调用点检查清单 ===
1. SessionState.idle_seconds() → real_now ✅
2. SessionState.seconds_since_assistant_message() → real_now ✅
3. Plan.is_expired() → world_now ✅
4. ShortTermMemory.expire_entries() → world_now ✅
5. MemoryEntry.is_expired() → world_now ✅
6. FollowupHook.is_eligible() → world_now ✅
7. BackgroundLoop._check_followups() → world_now ✅
8. ForegroundLoop 创建 followup → world_now ✅
9. ForegroundLoop 写入 memory → real_now + world_now 双写 ✅
10. trace_store 时间戳 → real_now ✅
11. event_logger 时间戳 → real_now ✅
12. FollowupEntryExtensionRule → world_now ✅
13. ShortTermMemoryExpiryRule → world_now ✅
14. ActiveThreadBoostRule → 不涉及时间判断 ✅
15. ShortTermMemoryRepository.save() → 不涉及时间判断 ✅

=== 禁止事项 ===
- 禁止在业务逻辑中直接调用 datetime.now()，必须通过 clock.real_now_time() 或 clock.world_now_time()
- 禁止在过期/到期判断中使用 real_now 替代 world_now
- 禁止在用户感知间隔计算中使用 world_now 替代 real_now
- 测试代码中的 datetime.now() 可以保留（测试不经过 clock）
"""


@dataclass
class WorldClock:
    real_now: datetime = field(default_factory=datetime.now)
    world_now: datetime = field(default_factory=datetime.now)
    logical: LogicalTime = field(default_factory=LogicalTime)
    last_user_event_at: Optional[datetime] = None
    last_background_tick_at: Optional[datetime] = None
    startup_at: datetime = field(default_factory=datetime.now)
    _time_config: TimeConfig = field(default_factory=TimeConfig)
    _world_base: Optional[datetime] = None

    def __post_init__(self):
        if self._world_base is None:
            self._world_base = self.startup_at

    def now(self) -> datetime:
        return self.world_now

    def world_now_time(self) -> datetime:
        return self.world_now

    def real_now_time(self) -> datetime:
        return self.real_now

    def real_time(self) -> RealTime:
        return RealTime.now()

    def advance(self, delta: timedelta) -> None:
        self.real_now = datetime.now()
        world_delta = timedelta(seconds=delta.total_seconds() * self._time_config.world_time_multiplier)
        self.world_now = self.world_now + world_delta

    def mark_user_event(self) -> None:
        now = datetime.now()
        self.real_now = now
        self.last_user_event_at = now
        self.logical = self.logical.next_turn()

    def mark_assistant_event(self) -> None:
        now = datetime.now()
        self.real_now = now
        self.logical = self.logical.next_turn()

    def mark_background_tick(self) -> None:
        now = datetime.now()
        self.real_now = now
        self.last_background_tick_at = now
        self.logical = self.logical.next_tick()

    def delta_since_last_event(self) -> timedelta:
        last = self.last_user_event_at or self.last_background_tick_at or self.startup_at
        return datetime.now() - last

    def delta_since_last_tick(self) -> timedelta:
        if self.last_background_tick_at is not None:
            return datetime.now() - self.last_background_tick_at
        return datetime.now() - self.startup_at

    def idle_since_user(self) -> timedelta:
        if self.last_user_event_at is None:
            return datetime.now() - self.startup_at
        return datetime.now() - self.last_user_event_at

    def snapshot(self) -> Dict[str, Any]:
        return {
            "real_now": self.real_now.isoformat(),
            "world_now": self.world_now.isoformat(),
            "turn_id": self.logical.turn_id,
            "tick_id": self.logical.tick_id,
            "last_user_event_at": self.last_user_event_at.isoformat() if self.last_user_event_at else None,
            "last_background_tick_at": self.last_background_tick_at.isoformat() if self.last_background_tick_at else None,
            "startup_at": self.startup_at.isoformat(),
            "idle_seconds": self.idle_since_user().total_seconds(),
        }
