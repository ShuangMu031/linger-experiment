from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional


@dataclass(frozen=True)
class RealTime:
    timestamp: datetime

    @staticmethod
    def now() -> "RealTime":
        return RealTime(timestamp=datetime.now())

    def isoformat(self) -> str:
        return self.timestamp.isoformat()


@dataclass(frozen=True)
class WorldTime:
    timestamp: datetime
    multiplier: float = 1.0

    @staticmethod
    def from_real(real: datetime, multiplier: float = 1.0, base: Optional[datetime] = None) -> "WorldTime":
        if base is None:
            return WorldTime(timestamp=real, multiplier=multiplier)
        delta = real - base
        world_delta = timedelta(seconds=delta.total_seconds() * multiplier)
        return WorldTime(timestamp=base + world_delta, multiplier=multiplier)

    def isoformat(self) -> str:
        return self.timestamp.isoformat()


@dataclass(frozen=True)
class LogicalTime:
    turn_id: int = 0
    tick_id: int = 0

    def next_turn(self) -> "LogicalTime":
        return LogicalTime(turn_id=self.turn_id + 1, tick_id=self.tick_id)

    def next_tick(self) -> "LogicalTime":
        return LogicalTime(turn_id=self.turn_id, tick_id=self.tick_id + 1)
