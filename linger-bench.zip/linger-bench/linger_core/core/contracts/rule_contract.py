from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class RuleOutput:
    rule_name: str
    target: str
    changes: List[Dict[str, Any]]
    applied: bool = True


class RuleContract(ABC):
    @abstractmethod
    def name(self) -> str:
        pass

    @abstractmethod
    def applies_to(self, state: Any) -> bool:
        pass

    @abstractmethod
    def apply(self, state: Any, delta_seconds: float) -> RuleOutput:
        pass

    @abstractmethod
    def priority(self) -> int:
        pass
