from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class StateReadContract(ABC):
    @abstractmethod
    def get(self, path: str, default: Any = None) -> Any:
        pass

    @abstractmethod
    def snapshot(self) -> Dict[str, Any]:
        pass


class StateWriteContract(ABC):
    @abstractmethod
    def set(self, path: str, value: Any) -> None:
        pass

    @abstractmethod
    def touch(self, path: str) -> None:
        pass


class StateContract(StateReadContract, StateWriteContract):
    @abstractmethod
    def get(self, path: str, default: Any = None) -> Any:
        pass

    @abstractmethod
    def set(self, path: str, value: Any) -> None:
        pass

    @abstractmethod
    def touch(self, path: str) -> None:
        pass

    @abstractmethod
    def snapshot(self) -> Dict[str, Any]:
        pass
