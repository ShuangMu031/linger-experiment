from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ModuleInput:
    user_message: str
    event_type: str
    context: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ModuleOutput:
    module_name: str
    input_summary: str = ""
    judgment: str = ""
    confidence: float = 0.0
    reason: str = ""
    suggested_actions: List[Dict[str, Any]] = field(default_factory=list)
    avoid_actions: List[Dict[str, Any]] = field(default_factory=list)
    state_impacts: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


class ModuleContract(ABC):
    @abstractmethod
    def name(self) -> str:
        pass

    @abstractmethod
    def process(self, state: Any, module_input: ModuleInput) -> ModuleOutput:
        pass

    @abstractmethod
    def can_handle(self, event_type: str) -> bool:
        pass
