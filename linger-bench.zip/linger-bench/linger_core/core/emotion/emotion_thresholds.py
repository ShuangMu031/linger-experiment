"""8 维情绪阈值表（spec §4.5）。

每条 `EmotionThreshold` 描述：当某维分数 ≥ threshold 时，触发哪些动作 +
向 impulse_pressure 贡献多少累积因子。

v1 阈值参考 v0.5 §5.2.2 草案，跑数据后再调。"""
from dataclasses import dataclass, field
from typing import Tuple

from linger_core.core.emotion.emotion_dimensions import EmotionDimension


@dataclass(frozen=True)
class EmotionThreshold:
    dimension: EmotionDimension
    threshold: int
    actions: Tuple[str, ...] = field(default_factory=tuple)
    accumulate_impulse_factor: float = 0.0


THRESHOLDS_V1: Tuple[EmotionThreshold, ...] = (
    EmotionThreshold(EmotionDimension.JOY, 70,
                     ("drift_mood", "trace_tag"), 0.3),
    EmotionThreshold(EmotionDimension.SADNESS, 60,
                     ("comfort", "drift_mood"), 0.5),
    EmotionThreshold(EmotionDimension.SADNESS, 80,
                     ("write_attention", "drift_mood"), 0.7),
    EmotionThreshold(EmotionDimension.ANGER, 50,
                     ("redline_check", "trace_tag"), 0.2),
    EmotionThreshold(EmotionDimension.FEAR, 60,
                     ("comfort", "drift_mood"), 0.4),
    EmotionThreshold(EmotionDimension.FEAR, 75,
                     ("write_attention",), 0.6),
    EmotionThreshold(EmotionDimension.DISGUST, 50,
                     ("boundary_check",), 0.1),
    EmotionThreshold(EmotionDimension.SURPRISE, 60,
                     ("event_memory_candidate",), 0.3),
    EmotionThreshold(EmotionDimension.ANTICIPATION, 50,
                     ("event_memory_candidate",), 0.2),
)
