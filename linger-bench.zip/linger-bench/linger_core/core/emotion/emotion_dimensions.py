from dataclasses import dataclass, fields
from enum import Enum
from typing import Any, Dict, Final


class EmotionDimension(str, Enum):
    JOY = "joy"
    SADNESS = "sadness"
    ANGER = "anger"
    FEAR = "fear"
    TRUST = "trust"
    DISGUST = "disgust"
    SURPRISE = "surprise"
    ANTICIPATION = "anticipation"


NEUTRAL_VALUE: Final[int] = 30


def _coerce_int(value: Any) -> int:
    if value is None or isinstance(value, bool):
        return int(value) if isinstance(value, bool) else 0
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(round(value))
    if isinstance(value, str):
        try:
            return int(round(float(value)))
        except (ValueError, TypeError):
            return 0
    return 0


def _clamp_dim(value: Any) -> int:
    n = _coerce_int(value)
    if n < 0:
        return 0
    if n > 100:
        return 100
    return n


@dataclass(frozen=True)
class EmotionVector:
    joy: int = 0
    sadness: int = 0
    anger: int = 0
    fear: int = 0
    trust: int = 0
    disgust: int = 0
    surprise: int = 0
    anticipation: int = 0

    def dominant(self) -> EmotionDimension:
        # 按 EmotionDimension 枚举声明顺序遍历，并列时返回最早的
        best_dim = EmotionDimension.JOY
        best_val = -1
        for dim in EmotionDimension:
            val = getattr(self, dim.value)
            if val > best_val:
                best_dim = dim
                best_val = val
        return best_dim

    def to_dict(self) -> Dict[str, int]:
        return {f.name: getattr(self, f.name) for f in fields(self)}

    @classmethod
    def neutral(cls) -> "EmotionVector":
        return cls(
            joy=NEUTRAL_VALUE,
            sadness=NEUTRAL_VALUE,
            anger=NEUTRAL_VALUE,
            fear=NEUTRAL_VALUE,
            trust=NEUTRAL_VALUE,
            disgust=NEUTRAL_VALUE,
            surprise=NEUTRAL_VALUE,
            anticipation=NEUTRAL_VALUE,
        )

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "EmotionVector":
        if not isinstance(d, dict):
            return cls()
        kwargs = {}
        for f in fields(cls):
            kwargs[f.name] = _clamp_dim(d.get(f.name, 0))
        return cls(**kwargs)
