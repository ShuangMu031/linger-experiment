"""前慢后快衰减曲线 — 参数化纯函数模块。

形态约定（v1）：
- 前段（delta_seconds <= half_life）：线性慢衰，t=half_life 时累计衰减 30%
- 后段（delta_seconds > half_life）：指数加速，趋向 100%
- floor_value 限制衰减下限，避免值穿透到目标以下

具体参数（half_life / late_acceleration / floor_value）后期可调。
单测只验证形态（前慢后快、加速参数生效、floor 生效），不锁死数值。
"""
import math
from dataclasses import dataclass


@dataclass(frozen=True)
class DecayParams:
    half_life_seconds: float = 3600.0
    late_acceleration: float = 2.0
    floor_value: int = 0


DEFAULT_DECAY_PARAMS = DecayParams()


_FRONT_DECAY_AT_HALF: float = 0.30  # t=half_life 时累计衰减 30%


def apply_decay(
    current: int,
    delta_seconds: float,
    target: int = 0,
    params: DecayParams = DEFAULT_DECAY_PARAMS,
) -> int:
    """把 current 朝 target 方向衰减一段时间，返回新的 int 值。"""
    if delta_seconds <= 0 or current == target:
        return current

    distance = current - target
    half = params.half_life_seconds

    if delta_seconds <= half:
        # 前段：线性，t=half 时衰减 30%
        ratio = (delta_seconds / half) * _FRONT_DECAY_AT_HALF
    else:
        # 后段：t > half 后指数加速
        excess_units = (delta_seconds - half) / half
        late = 1.0 - math.exp(-params.late_acceleration * excess_units)
        ratio = _FRONT_DECAY_AT_HALF + (1.0 - _FRONT_DECAY_AT_HALF) * late

    new_distance = distance * (1.0 - ratio)
    new_value = target + new_distance

    # floor 仅在 current 高于 target 时约束（向下衰减场景）
    if current > target and new_value < params.floor_value:
        new_value = float(params.floor_value)

    return int(round(new_value))
