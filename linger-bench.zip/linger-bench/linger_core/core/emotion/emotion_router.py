"""EmotionRouter — 8 维分数 → 派发决策的纯规则路由器（spec §4.6）。

输入：EmotionVector（瞬时 8 维 0-100）+ RouteContext（event_id / summary / real_now）
输出：RouterDecision（triggered_dimensions / actions / attention_writes /
                     mood_drift_input / impulse_factor / trace_tags）

router 不写任何 state — 写动作由调用方（InnerLifeUpdateModule）按
RouterDecision 派发。
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Tuple

from linger_core.core.emotion.emotion_dimensions import (
    EmotionDimension,
    EmotionVector,
)
from linger_core.core.emotion.emotion_thresholds import (
    THRESHOLDS_V1,
    EmotionThreshold,
)
from linger_core.core.state.inner_life_state import AttentionFocus


@dataclass(frozen=True)
class RouteContext:
    event_id: Optional[str] = None
    summary: str = ""
    real_now: Optional[datetime] = None


@dataclass(frozen=True)
class RouterDecision:
    triggered_dimensions: List[EmotionDimension] = field(default_factory=list)
    actions_to_dispatch: List[str] = field(default_factory=list)
    attention_writes: List[AttentionFocus] = field(default_factory=list)
    mood_drift_input: EmotionVector = field(default_factory=EmotionVector)
    impulse_factor: float = 0.0
    trace_tags: List[str] = field(default_factory=list)


class EmotionRouter:
    def __init__(
        self,
        thresholds: Tuple[EmotionThreshold, ...] = THRESHOLDS_V1,
    ) -> None:
        self._thresholds = thresholds

    def route(
        self,
        instant: EmotionVector,
        context: RouteContext,
    ) -> RouterDecision:
        triggered_seen: set = set()
        triggered: List[EmotionDimension] = []
        actions_seen: set = set()
        actions: List[str] = []
        attention_writes: List[AttentionFocus] = []
        impulse_factor: float = 0.0
        trace_tags: List[str] = []

        now = context.real_now or datetime.now()

        for thr in self._thresholds:
            value = getattr(instant, thr.dimension.value)
            if value < thr.threshold:
                continue

            if thr.dimension not in triggered_seen:
                triggered.append(thr.dimension)
                triggered_seen.add(thr.dimension)

            for a in thr.actions:
                if a not in actions_seen:
                    actions.append(a)
                    actions_seen.add(a)

            impulse_factor += thr.accumulate_impulse_factor
            trace_tags.append(
                f"emotion_router:{thr.dimension.value}:{thr.threshold}"
            )

            if "write_attention" in thr.actions and context.event_id:
                attention_writes.append(
                    AttentionFocus(
                        event_id=context.event_id,
                        summary=context.summary,
                        dominant_emotion=thr.dimension,
                        intensity=value,
                        set_at=now,
                    )
                )

        return RouterDecision(
            triggered_dimensions=triggered,
            actions_to_dispatch=actions,
            attention_writes=attention_writes,
            mood_drift_input=instant,
            impulse_factor=impulse_factor,
            trace_tags=trace_tags,
        )
