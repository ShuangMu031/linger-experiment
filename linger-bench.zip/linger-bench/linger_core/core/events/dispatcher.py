from typing import Callable, Dict, List, Optional

from linger_core.core.events.event_types import EventType
from linger_core.core.events.system_event import SystemEvent
from linger_core.shared.exceptions import EventDispatchError


EventHandler = Callable[[SystemEvent], None]


class EventDispatcher:
    def __init__(self):
        self._handlers: Dict[EventType, List[EventHandler]] = {}
        self._global_handlers: List[EventHandler] = []

    def register(self, event_type: EventType, handler: EventHandler) -> None:
        if event_type not in self._handlers:
            self._handlers[event_type] = []
        self._handlers[event_type].append(handler)

    def register_global(self, handler: EventHandler) -> None:
        self._global_handlers.append(handler)

    def dispatch(self, event: SystemEvent) -> None:
        for handler in self._global_handlers:
            try:
                handler(event)
            except Exception as e:
                raise EventDispatchError(
                    f"Global handler failed for event {event.event_id}: {e}"
                )

        handlers = self._handlers.get(event.event_type, [])
        for handler in handlers:
            try:
                handler(event)
            except Exception as e:
                raise EventDispatchError(
                    f"Handler failed for event {event.event_type.name}: {e}"
                )

    def has_handlers(self, event_type: EventType) -> bool:
        return bool(self._handlers.get(event_type, []))
