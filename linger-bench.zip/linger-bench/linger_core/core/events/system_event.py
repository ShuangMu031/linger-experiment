from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, Optional

from linger_core.core.events.event_types import EventType
from linger_core.shared.ids import generate_event_id


@dataclass
class SystemEvent:
    event_id: str = field(default_factory=generate_event_id)
    event_type: EventType = EventType.SYSTEM_START
    created_at: datetime = field(default_factory=datetime.now)
    payload: Dict[str, Any] = field(default_factory=dict)
    source: str = "system"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "event_type": self.event_type.name,
            "created_at": self.created_at.isoformat(),
            "payload": self.payload,
            "source": self.source,
        }
