from enum import Enum, auto


class EventType(Enum):
    SYSTEM_START = auto()
    USER_INPUT = auto()
    BACKGROUND_TICK = auto()
