from datetime import timedelta
from typing import TYPE_CHECKING, Any

from linger_core.core.timeline.rules.base_rule import BaseRule
from linger_core.core.contracts.rule_contract import RuleOutput
from linger_core.core.state.runtime_state import RuntimeState
from linger_core.shared.enums import LongTermMemoryStatus

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


LTM_COOLING_THRESHOLD_SECONDS = 86400 * 7
LTM_ARCHIVE_THRESHOLD_SECONDS = 86400 * 30
LTM_LOW_CONFIDENCE_THRESHOLD = 0.2


class LongTermCoolingRule(BaseRule):

    def name(self) -> str:
        return "ltm_cooling"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        return isinstance(state, RuntimeState) and view.memory.long_term.active_count > 0

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        now = view.clock.real_now_time()
        cooled_count = 0

        for entry in view.memory.long_term._store_ref.get_active():
            if entry.decay_policy == "never":
                continue
            if entry.last_seen_real is None:
                continue
            elapsed = (now - entry.last_seen_real).total_seconds()
            if elapsed >= LTM_COOLING_THRESHOLD_SECONDS:
                entry.cool_down(delta=0.05)
                cooled_count += 1

        return RuleOutput(
            rule_name=self.name(),
            target="long_term_memory",
            changes=[{
                "field": "long_term_memory.cooling",
                "cooled_count": cooled_count,
            }],
        )

    def priority(self) -> int:
        return 22

    def category(self) -> str:
        return "lifecycle"


class LongTermArchiveRule(BaseRule):

    def name(self) -> str:
        return "ltm_archive"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        return isinstance(state, RuntimeState) and view.memory.long_term.active_count > 0

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        archived_count = state.long_term_memory.archive_low_confidence(
            min_confidence=LTM_LOW_CONFIDENCE_THRESHOLD
        )

        return RuleOutput(
            rule_name=self.name(),
            target="long_term_memory",
            changes=[{
                "field": "long_term_memory.archive",
                "archived_count": archived_count,
            }],
        )

    def priority(self) -> int:
        return 20

    def category(self) -> str:
        return "lifecycle"


class LongTermRefreshRule(BaseRule):

    def name(self) -> str:
        return "ltm_refresh"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        return isinstance(state, RuntimeState) and view.memory.long_term.active_count > 0

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        from linger_core.shared.enums import LongTermMemoryStatus
        cooled = view.memory.long_term._store_ref.get_by_status(LongTermMemoryStatus.COOLED)
        refreshed_count = 0

        for entry in cooled:
            if entry.confirm_count >= 2:
                entry.refresh(delta=0.15)
                refreshed_count += 1

        return RuleOutput(
            rule_name=self.name(),
            target="long_term_memory",
            changes=[{
                "field": "long_term_memory.refresh",
                "refreshed_count": refreshed_count,
            }],
        )

    def priority(self) -> int:
        return 21

    def category(self) -> str:
        return "interaction"
