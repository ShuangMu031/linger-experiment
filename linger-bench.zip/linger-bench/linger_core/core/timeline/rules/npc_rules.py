import random
from typing import TYPE_CHECKING, Any, Dict, List, Tuple

from linger_core.core.timeline.rules.base_rule import BaseRule
from linger_core.core.contracts.rule_contract import RuleOutput
from linger_core.core.state.runtime_state import RuntimeState
from linger_core.shared.enums import TimeOfDay, NpcActivity

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


# 键沿用 npc_id / place_id（内部键不变）。现实含义：
# npc_ling=林安安, npc_chen=赵一鸣, npc_yue=苏棠；home=合租屋, cafe=密室店, street=东郊记忆, park=绿道, office=工作室。
NPC_SCHEDULE: Dict[str, Dict[TimeOfDay, List[Tuple[NpcActivity, str, float]]]] = {
    "npc_ling": {
        TimeOfDay.MORNING: [
            (NpcActivity.IDLE, "home", 0.7),
            (NpcActivity.WANDERING, "park", 0.3),
        ],
        TimeOfDay.AFTERNOON: [
            (NpcActivity.SOCIALIZING, "cafe", 0.6),
            (NpcActivity.WANDERING, "street", 0.3),
            (NpcActivity.IDLE, "home", 0.1),
        ],
        TimeOfDay.EVENING: [
            (NpcActivity.IDLE, "home", 0.6),
            (NpcActivity.SOCIALIZING, "cafe", 0.4),
        ],
        TimeOfDay.NIGHT: [
            (NpcActivity.RESTING, "home", 0.9),
            (NpcActivity.IDLE, "home", 0.1),
        ],
    },
    "npc_chen": {
        TimeOfDay.MORNING: [
            (NpcActivity.WORKING, "cafe", 0.85),
            (NpcActivity.IDLE, "home", 0.15),
        ],
        TimeOfDay.AFTERNOON: [
            (NpcActivity.WORKING, "cafe", 0.8),
            (NpcActivity.WANDERING, "street", 0.2),
        ],
        TimeOfDay.EVENING: [
            (NpcActivity.IDLE, "street", 0.5),
            (NpcActivity.SOCIALIZING, "cafe", 0.3),
            (NpcActivity.RESTING, "home", 0.2),
        ],
        TimeOfDay.NIGHT: [
            (NpcActivity.RESTING, "home", 0.9),
            (NpcActivity.IDLE, "home", 0.1),
        ],
    },
    "npc_yue": {
        TimeOfDay.MORNING: [
            (NpcActivity.IDLE, "home", 0.6),
            (NpcActivity.WANDERING, "park", 0.4),
        ],
        TimeOfDay.AFTERNOON: [
            (NpcActivity.WANDERING, "park", 0.5),
            (NpcActivity.SOCIALIZING, "cafe", 0.3),
            (NpcActivity.WANDERING, "street", 0.2),
        ],
        TimeOfDay.EVENING: [
            (NpcActivity.SOCIALIZING, "cafe", 0.5),
            (NpcActivity.IDLE, "home", 0.3),
            (NpcActivity.WANDERING, "street", 0.2),
        ],
        TimeOfDay.NIGHT: [
            (NpcActivity.RESTING, "home", 0.85),
            (NpcActivity.IDLE, "home", 0.15),
        ],
    },
}

NPC_MOOD_POOL: Dict[str, List[str]] = {
    "npc_ling": ["friendly", "warm", "curious", "cheerful", "gentle"],
    "npc_chen": ["calm", "steady", "thoughtful", "quiet", "content"],
    "npc_yue": ["cheerful", "lively", "excited", "caring", "playful"],
}

ENERGY_DELTA_BY_ACTIVITY = {
    NpcActivity.RESTING: 0.15,
    NpcActivity.IDLE: 0.05,
    NpcActivity.WORKING: -0.05,
    NpcActivity.SOCIALIZING: -0.03,
    NpcActivity.WANDERING: -0.02,
    NpcActivity.EATING: 0.10,
}


def _pick_schedule(options: List[Tuple[NpcActivity, str, float]]) -> Tuple[NpcActivity, str]:
    r = random.random()
    cumulative = 0.0
    for activity, place, weight in options:
        cumulative += weight
        if r <= cumulative:
            return activity, place
    return options[-1][0], options[-1][1]


class NpcScheduleRule(BaseRule):

    def name(self) -> str:
        return "npc_schedule_update"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        return isinstance(state, RuntimeState) and view.world.npcs_count > 0

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        world_now = view.clock.world_now_time()
        time_of_day = view.world.time_of_day
        changes = []

        for npc in view.world._npc_registry_ref.get_all():
            schedule = NPC_SCHEDULE.get(npc.npc_id)
            if not schedule:
                continue

            options = schedule.get(time_of_day)
            if not options:
                continue

            new_activity, new_place = _pick_schedule(options)
            old_activity = npc.current_activity
            old_place = npc.current_place_id

            if old_activity != new_activity or old_place != new_place:
                npc.set_activity(new_activity, world_now=world_now)
                npc.set_place(new_place, world_now=world_now)

                if old_place != new_place:
                    old_place_obj = view.world._place_registry_ref.get(old_place)
                    new_place_obj = view.world._place_registry_ref.get(new_place)
                    if old_place_obj:
                        old_place_obj.remove_npc(npc.npc_id)
                    if new_place_obj:
                        new_place_obj.add_npc(npc.npc_id)

                if state.world_event_generator:
                    event = state.world_event_generator.check_npc_changes(
                        npc_id=npc.npc_id,
                        old_activity=old_activity.value,
                        new_activity=new_activity.value,
                        old_place=old_place,
                        new_place=new_place,
                        world_now=world_now,
                    )
                    if event:
                        changes.append({
                            "field": "world_event.created",
                            "event_type": "npc_change",
                            "npc_id": npc.npc_id,
                            "event_id": event.world_event_id,
                        })

                changes.append({
                    "field": f"npc.{npc.npc_id}",
                    "activity": f"{old_activity.value} → {new_activity.value}",
                    "place": f"{old_place} → {new_place}",
                })

            energy_delta = ENERGY_DELTA_BY_ACTIVITY.get(npc.current_activity, 0.0)
            if time_of_day == TimeOfDay.NIGHT:
                energy_delta += 0.05
            elif time_of_day == TimeOfDay.MORNING:
                energy_delta += 0.10
            if energy_delta != 0:
                npc.update_energy(energy_delta)

            mood_pool = NPC_MOOD_POOL.get(npc.npc_id, ["neutral"])
            if random.random() < 0.15:
                new_mood = random.choice(mood_pool)
                if new_mood != npc.current_mood:
                    npc.set_mood(new_mood)
                    changes.append({
                        "field": f"npc.{npc.npc_id}.mood",
                        "before": npc.current_mood,
                        "after": new_mood,
                    })

        return RuleOutput(
            rule_name=self.name(),
            target="npc_registry",
            changes=changes,
            applied=len(changes) > 0,
        )

    def priority(self) -> int:
        return 43

    def category(self) -> str:
        return "world"
