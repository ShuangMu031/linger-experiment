from typing import TYPE_CHECKING, Any

from linger_core.core.timeline.rules.base_rule import BaseRule
from linger_core.core.contracts.rule_contract import RuleOutput
from linger_core.core.state.runtime_state import RuntimeState
from linger_core.shared.enums import SessionStatus

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


class SessionIdleRule(BaseRule):

    def name(self) -> str:
        return "session_idle_update"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        return isinstance(state, RuntimeState)

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        changes = []
        idle_seconds = view.session.idle_seconds_at_freeze
        idle_threshold = view.config.time.session_idle_threshold_seconds

        if view.session.is_user_present and idle_seconds > idle_threshold:
            state.session.mark_idle()
            changes.append({
                "field": "session.status",
                "before": SessionStatus.ACTIVE.value,
                "after": SessionStatus.IDLE.value,
            })
            changes.append({
                "field": "session.is_user_present",
                "before": True,
                "after": False,
            })

        changes.append({
            "field": "session.idle_seconds",
            "before": max(0, idle_seconds - delta_seconds),
            "after": idle_seconds,
        })

        return RuleOutput(
            rule_name=self.name(),
            target="session",
            changes=changes,
        )

    def priority(self) -> int:
        return 10

    def category(self) -> str:
        return "lifecycle"
