from typing import TYPE_CHECKING, Any

from linger_core.core.timeline.rules.base_rule import BaseRule
from linger_core.core.contracts.rule_contract import RuleOutput
from linger_core.core.state.runtime_state import RuntimeState

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


class ShortTermMemoryExpiryRule(BaseRule):

    def name(self) -> str:
        return "short_term_memory_expiry"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        return isinstance(state, RuntimeState) and view.memory.short_term._store_ref.active_count > 0

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        world_now = view.clock.world_now_time()
        before_count = view.memory.short_term._store_ref.active_count
        expired = state.short_term_memory.expire_entries(world_now)
        after_count = before_count - len(expired)

        return RuleOutput(
            rule_name=self.name(),
            target="short_term_memory",
            changes=[{
                "field": "short_term_memory.active_count",
                "before": before_count,
                "after": after_count,
                "expired_count": len(expired),
            }],
        )

    def priority(self) -> int:
        return 30

    def category(self) -> str:
        return "lifecycle"


class FollowupEntryExtensionRule(BaseRule):

    def name(self) -> str:
        return "followup_entry_extension"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        if not isinstance(state, RuntimeState):
            return False
        entries_with_followup = view.memory.short_term._store_ref.get_entries_with_followup()
        return len(entries_with_followup) > 0

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        from datetime import timedelta

        world_now = view.clock.world_now_time()
        extended = []
        entries = view.memory.short_term._store_ref.get_entries_with_followup()

        for entry in entries:
            if entry.is_active and entry.expires_at_world and entry.expires_at_world < world_now + timedelta(minutes=5):
                entry.expires_at_world = entry.expires_at_world + timedelta(minutes=10)
                entry.boost_importance(0.2)
                extended.append(entry.entry_id)

        return RuleOutput(
            rule_name=self.name(),
            target="short_term_memory",
            changes=[{
                "field": "followup_entries_extended",
                "count": len(extended),
                "entry_ids": extended,
            }],
        )

    def priority(self) -> int:
        return 25

    def category(self) -> str:
        return "interaction"


class ActiveThreadBoostRule(BaseRule):

    def name(self) -> str:
        return "active_thread_boost"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        if not isinstance(state, RuntimeState):
            return False
        return view.memory.short_term._store_ref.active_count > 0

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        recent = view.memory.short_term._store_ref.get_recent(n=4)
        boosted = []
        current_emotion = view.emotion.current.value

        for entry in recent:
            if not entry.is_active:
                continue
            if entry.emotion_snapshot and entry.emotion_snapshot.get("emotion") == current_emotion:
                entry.boost_importance(0.1)
                boosted.append(entry.entry_id)
            if "has_followup" in entry.tags:
                entry.boost_importance(0.05)
                if entry.entry_id not in boosted:
                    boosted.append(entry.entry_id)

        return RuleOutput(
            rule_name=self.name(),
            target="short_term_memory",
            changes=[{
                "field": "active_thread_boost",
                "count": len(boosted),
                "entry_ids": boosted,
            }],
        )

    def priority(self) -> int:
        return 20

    def category(self) -> str:
        return "interaction"
