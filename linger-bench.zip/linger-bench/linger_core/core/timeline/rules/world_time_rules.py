from datetime import datetime
from typing import TYPE_CHECKING, Any

from linger_core.core.timeline.rules.base_rule import BaseRule
from linger_core.core.contracts.rule_contract import RuleOutput
from linger_core.core.state.runtime_state import RuntimeState
from linger_core.shared.enums import TimeOfDay

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


TIME_CHANGE_MAP = {
    6: TimeOfDay.MORNING,
    12: TimeOfDay.AFTERNOON,
    18: TimeOfDay.EVENING,
    22: TimeOfDay.NIGHT,
}


class WorldTimeRule(BaseRule):

    def name(self) -> str:
        return "world_time_advance"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        return isinstance(state, RuntimeState)

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        world_now = view.clock.world_now_time()
        hour = world_now.hour

        new_time = view.world.time_of_day
        for threshold, tod in sorted(TIME_CHANGE_MAP.items()):
            if hour >= threshold:
                new_time = tod

        old_time = view.world.time_of_day
        changes = []

        if new_time != old_time:
            state.world_runtime.advance_time(new_time, world_now=world_now)
            changes.append({
                "field": "world_runtime.time_of_day",
                "before": old_time.value,
                "after": new_time.value,
            })

            if state.world_event_generator:
                event = state.world_event_generator.check_time_change(
                    old_time, new_time, world_now=world_now
                )
                if event:
                    changes.append({
                        "field": "world_event.created",
                        "event_type": "time_change",
                        "event_id": event.world_event_id,
                    })

        state.world_runtime.mark_world_tick(world_now=world_now)

        return RuleOutput(
            rule_name=self.name(),
            target="world_runtime",
            changes=changes,
            applied=len(changes) > 0,
        )

    def priority(self) -> int:
        return 42

    def category(self) -> str:
        return "world"
