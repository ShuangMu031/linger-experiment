from typing import TYPE_CHECKING, Any

from linger_core.core.timeline.rules.base_rule import BaseRule
from linger_core.core.contracts.rule_contract import RuleOutput
from linger_core.core.state.runtime_state import RuntimeState

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


class EmotionDecayRule(BaseRule):

    def name(self) -> str:
        return "emotion_decay"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        return isinstance(state, RuntimeState)

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        old_intensity = view.emotion.intensity
        state.emotion_state.decay(delta_seconds)
        new_intensity = state.emotion_state.intensity  # noqa: state-penetration (post-write read; decay() does not return new value)

        return RuleOutput(
            rule_name=self.name(),
            target="emotion_state",
            changes=[{
                "field": "emotion_state.intensity",
                "before": round(old_intensity, 4),
                "after": round(new_intensity, 4),
            }],
        )

    def priority(self) -> int:
        return 20

    def category(self) -> str:
        return "lifecycle"
