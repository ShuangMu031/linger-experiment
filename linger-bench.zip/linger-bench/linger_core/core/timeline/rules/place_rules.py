from typing import TYPE_CHECKING, Any

from linger_core.core.timeline.rules.base_rule import BaseRule
from linger_core.core.contracts.rule_contract import RuleOutput
from linger_core.core.state.runtime_state import RuntimeState
from linger_core.shared.enums import TimeOfDay

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


AMBIENT_TIME_MAP = {
    TimeOfDay.MORNING: {"mood": "fresh", "energy": 0.6, "social": 0.3, "pressure": 0.2},
    TimeOfDay.AFTERNOON: {"mood": "steady", "energy": 0.5, "social": 0.5, "pressure": 0.3},
    TimeOfDay.EVENING: {"mood": "warm", "energy": 0.4, "social": 0.4, "pressure": 0.2},
    TimeOfDay.NIGHT: {"mood": "quiet", "energy": 0.2, "social": 0.1, "pressure": 0.1},
}

WEATHER_AMBIENT_MAP = {
    "clear": {"mood_shift": 0.0, "energy_shift": 0.05, "comfort_shift": 0.0},
    "cloudy": {"mood_shift": -0.05, "energy_shift": -0.02, "comfort_shift": -0.05},
    "rainy": {"mood_shift": -0.1, "energy_shift": -0.05, "comfort_shift": -0.1},
    "stormy": {"mood_shift": -0.15, "energy_shift": -0.1, "comfort_shift": -0.2},
}


class PlaceAmbientRule(BaseRule):

    def name(self) -> str:
        return "place_ambient_update"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        return isinstance(state, RuntimeState)

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        world_now = view.clock.world_now_time()
        changes = []

        time_of_day = view.world.time_of_day
        ambient_config = AMBIENT_TIME_MAP.get(time_of_day, AMBIENT_TIME_MAP[TimeOfDay.AFTERNOON])

        old_mood = view.world.ambient.mood
        new_mood = ambient_config["mood"]

        weather = view.world.weather
        weather_shift = WEATHER_AMBIENT_MAP.get(weather, {})

        if weather == "rainy":
            new_mood = "melancholy"
        elif weather == "stormy":
            new_mood = "tense"

        if old_mood != new_mood:
            state.ambient_state.update_mood(new_mood, world_now=world_now)
            changes.append({
                "field": "ambient_state.mood",
                "before": old_mood,
                "after": new_mood,
            })

            if state.world_event_generator:
                event = state.world_event_generator.check_ambient_change(
                    old_mood, new_mood,
                    place_id=view.world.place_id,
                    world_now=world_now,
                )
                if event:
                    changes.append({
                        "field": "world_event.created",
                        "event_type": "ambient_change",
                        "event_id": event.world_event_id,
                    })

        state.ambient_state.update_energy(ambient_config["energy"] + weather_shift.get("energy_shift", 0.0))
        state.ambient_state.update_social_density(ambient_config["social"])

        current_place = view.world._place_registry_ref.get(view.world.place_id)
        if current_place:
            npc_count = len(view.world._npc_registry_ref.get_by_place(current_place.place_id))
            social = min(1.0, ambient_config["social"] + npc_count * 0.1)
            state.ambient_state.update_social_density(social)

            if weather_shift.get("comfort_shift", 0.0) != 0:
                current_place.update_comfort(current_place.comfort_level + weather_shift["comfort_shift"])

        return RuleOutput(
            rule_name=self.name(),
            target="ambient_state",
            changes=changes,
            applied=len(changes) > 0,
        )

    def priority(self) -> int:
        return 41

    def category(self) -> str:
        return "world"
