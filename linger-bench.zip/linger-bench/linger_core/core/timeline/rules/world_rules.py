from typing import TYPE_CHECKING, Any

from linger_core.core.timeline.rules.base_rule import BaseRule
from linger_core.core.contracts.rule_contract import RuleOutput
from linger_core.core.state.runtime_state import RuntimeState

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


class WorldTickRule(BaseRule):

    def name(self) -> str:
        return "world_tick"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        return isinstance(state, RuntimeState)

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        before = view.world.last_tick_at
        old_time = before.isoformat() if before else None
        world_now = view.clock.world_now_time()
        state.world_runtime.mark_world_tick(world_now=world_now)
        new_time = world_now.isoformat()

        return RuleOutput(
            rule_name=self.name(),
            target="world_runtime",
            changes=[{
                "field": "world_runtime.last_world_tick_at",
                "before": old_time,
                "after": new_time,
            }],
        )

    def priority(self) -> int:
        return 40

    def category(self) -> str:
        return "world"
