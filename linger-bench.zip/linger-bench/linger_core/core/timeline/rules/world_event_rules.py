from typing import TYPE_CHECKING, Any

from linger_core.core.timeline.rules.base_rule import BaseRule
from linger_core.core.contracts.rule_contract import RuleOutput
from linger_core.core.state.runtime_state import RuntimeState
from linger_core.shared.enums import WorldEventStatus

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


WORLD_EVENT_COOL_DELTA = 0.08
WORLD_EVENT_EXPIRE_THRESHOLD = 0.1


class WorldEventCoolRule(BaseRule):

    def name(self) -> str:
        return "world_event_cool"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        return isinstance(state, RuntimeState) and view.world.events_active_count > 0

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        cooled_count = state.world_event_store.cool_all(delta=WORLD_EVENT_COOL_DELTA)

        expired_count = 0
        for event in view.world._events_store_ref.all_events:
            if event.is_active() and event.importance < WORLD_EVENT_EXPIRE_THRESHOLD:
                event.expire()
                expired_count += 1

        return RuleOutput(
            rule_name=self.name(),
            target="world_event_store",
            changes=[{
                "field": "world_event.cool",
                "cooled_count": cooled_count,
                "expired_count": expired_count,
            }],
        )

    def priority(self) -> int:
        return 38

    def category(self) -> str:
        return "lifecycle"


class WorldEventArchiveRule(BaseRule):

    def name(self) -> str:
        return "world_event_archive"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        if not isinstance(state, RuntimeState):
            return False
        expired = [e for e in view.world._events_store_ref.all_events if e.status == WorldEventStatus.EXPIRED]
        return len(expired) > 0

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        archived_count = 0
        for event in view.world._events_store_ref.all_events:
            if event.status == WorldEventStatus.EXPIRED:
                event.archive()
                archived_count += 1

        return RuleOutput(
            rule_name=self.name(),
            target="world_event_store",
            changes=[{
                "field": "world_event.archive",
                "archived_count": archived_count,
            }],
        )

    def priority(self) -> int:
        return 36

    def category(self) -> str:
        return "lifecycle"
