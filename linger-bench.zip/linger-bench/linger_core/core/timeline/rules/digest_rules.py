from datetime import timedelta
from typing import TYPE_CHECKING, Any

from linger_core.core.timeline.rules.base_rule import BaseRule
from linger_core.core.contracts.rule_contract import RuleOutput
from linger_core.core.state.runtime_state import RuntimeState
from linger_core.shared.enums import DigestWindowType

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


DIGEST_3D_INTERVAL_SECONDS = 86400 * 3
DIGEST_7D_INTERVAL_SECONDS = 86400 * 7


class DigestGenerationRule(BaseRule):

    def name(self) -> str:
        return "digest_generation"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        return isinstance(state, RuntimeState) and view.memory.events.active_count > 0

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        from datetime import datetime
        now = datetime.now()
        generated = []

        last_3d = view.profile._state_ref.last_digest_3d_at
        if last_3d is None or (now - last_3d).total_seconds() >= DIGEST_3D_INTERVAL_SECONDS:
            bundle = view.memory.long_term._digest_generator_ref.generate(
                event_store=view.memory.events._store_ref,
                window_type=DigestWindowType.THREE_DAY,
                relationship=view.relationship.snapshot,
                real_now=now,
            )
            state.profile_state.last_digest_3d_at = now
            generated.append("3d")

        last_7d = view.profile._state_ref.last_digest_7d_at
        if last_7d is None or (now - last_7d).total_seconds() >= DIGEST_7D_INTERVAL_SECONDS:
            bundle = view.memory.long_term._digest_generator_ref.generate(
                event_store=view.memory.events._store_ref,
                window_type=DigestWindowType.SEVEN_DAY,
                relationship=view.relationship.snapshot,
                real_now=now,
            )
            state.profile_state.last_digest_7d_at = now
            generated.append("7d")

        return RuleOutput(
            rule_name=self.name(),
            target="digest",
            changes=[{
                "field": "digest.generation",
                "generated_types": generated,
            }],
            applied=len(generated) > 0,
        )

    def priority(self) -> int:
        return 18

    def category(self) -> str:
        return "interaction"


class DigestCleanupRule(BaseRule):

    def name(self) -> str:
        return "digest_cleanup"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        return isinstance(state, RuntimeState) and len(view.memory.long_term._digest_generator_ref.get_all()) > 10

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        from datetime import datetime
        now = datetime.now()
        all_bundles = view.memory.long_term._digest_generator_ref.get_all()
        expired_ids = []
        for b in all_bundles:
            if b.is_expired(now):
                expired_ids.append(b.digest_id)

        return RuleOutput(
            rule_name=self.name(),
            target="digest",
            changes=[{
                "field": "digest.cleanup",
                "expired_count": len(expired_ids),
                "expired_ids": expired_ids,
            }],
        )

    def priority(self) -> int:
        return 16

    def category(self) -> str:
        return "lifecycle"
