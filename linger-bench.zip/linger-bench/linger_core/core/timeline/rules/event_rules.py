from datetime import timedelta
from typing import TYPE_CHECKING, Any

from linger_core.core.timeline.rules.base_rule import BaseRule
from linger_core.core.contracts.rule_contract import RuleOutput
from linger_core.core.state.runtime_state import RuntimeState
from linger_core.shared.enums import EventStatus

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


COOLING_THRESHOLD_SECONDS = 1800
DECAY_THRESHOLD_SECONDS = 43200
ARCHIVE_THRESHOLD_SECONDS = 86400


class EventCoolingRule(BaseRule):

    def name(self) -> str:
        return "event_cooling"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        return isinstance(state, RuntimeState) and view.memory.events.active_count > 0

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        world_now = view.clock.world_now_time()
        before_open = len(view.memory.events.by_status(EventStatus.OPEN))
        cooled_count = 0

        for event in view.memory.events.by_status(EventStatus.OPEN):
            if event.last_seen_world is None:
                continue
            elapsed = (world_now - event.last_seen_world).total_seconds()
            if elapsed >= COOLING_THRESHOLD_SECONDS:
                event.cool_down(delta=0.05)
                cooled_count += 1

        after_open = len(view.memory.events.by_status(EventStatus.OPEN))

        return RuleOutput(
            rule_name=self.name(),
            target="event_memory",
            changes=[{
                "field": "event_memory.open_count",
                "before": before_open,
                "after": after_open,
                "cooled_count": cooled_count,
            }],
        )

    def priority(self) -> int:
        return 28

    def category(self) -> str:
        return "lifecycle"


class EventDecayRule(BaseRule):

    def name(self) -> str:
        return "event_decay"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        return isinstance(state, RuntimeState) and view.memory.events.active_count > 0

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        world_now = view.clock.world_now_time()
        decayed_count = 0

        for event in view.memory.events.active():
            if event.last_seen_world is None:
                continue
            elapsed = (world_now - event.last_seen_world).total_seconds()
            if elapsed >= DECAY_THRESHOLD_SECONDS:
                event.decay_priority(delta=0.02)
                decayed_count += 1

        return RuleOutput(
            rule_name=self.name(),
            target="event_memory",
            changes=[{
                "field": "event_memory.priority_decay",
                "decayed_count": decayed_count,
            }],
        )

    def priority(self) -> int:
        return 27

    def category(self) -> str:
        return "lifecycle"


class EventRefreshRule(BaseRule):

    def name(self) -> str:
        return "event_refresh"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        if not isinstance(state, RuntimeState):
            return False
        from linger_core.shared.enums import EmotionType, EventType
        negative = {EmotionType.SAD, EmotionType.ANGRY, EmotionType.ANXIOUS}
        if view.emotion.current not in negative:
            return False
        high_emotion_events = view.memory.events._store_ref.get_by_type(EventType.HIGH_EMOTION)
        return len(high_emotion_events) > 0

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        from linger_core.shared.enums import EventType

        high_emotion_events = view.memory.events._store_ref.get_by_type(EventType.HIGH_EMOTION)
        refreshed = []
        for event in high_emotion_events:
            if event.emotion_label == view.emotion.current.value:
                event.boost_priority(0.1)
                refreshed.append(event.event_id)

        return RuleOutput(
            rule_name=self.name(),
            target="event_memory",
            changes=[{
                "field": "event_memory.refresh",
                "refreshed_count": len(refreshed),
                "refreshed_ids": refreshed,
            }],
        )

    def priority(self) -> int:
        return 26

    def category(self) -> str:
        return "interaction"


class EventArchiveRule(BaseRule):

    def name(self) -> str:
        return "event_archive"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        if not isinstance(state, RuntimeState):
            return False
        from linger_core.shared.enums import EventStatus
        resolved = view.memory.events.by_status(EventStatus.RESOLVED)
        return len(resolved) > 0

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        world_now = view.clock.world_now_time()
        archived_count = 0

        for event in view.memory.events.by_status(EventStatus.RESOLVED):
            if event.last_seen_world is None:
                event.archive()
                archived_count += 1
                continue
            elapsed = (world_now - event.last_seen_world).total_seconds()
            if elapsed >= ARCHIVE_THRESHOLD_SECONDS:
                event.archive()
                archived_count += 1

        return RuleOutput(
            rule_name=self.name(),
            target="event_memory",
            changes=[{
                "field": "event_memory.archive",
                "archived_count": archived_count,
            }],
        )

    def priority(self) -> int:
        return 24

    def category(self) -> str:
        return "lifecycle"
