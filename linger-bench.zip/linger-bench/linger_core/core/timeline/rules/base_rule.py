from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Dict, List

from linger_core.core.contracts.rule_contract import RuleContract, RuleOutput

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


class BaseRule(RuleContract, ABC):
    @abstractmethod
    def name(self) -> str:
        pass

    @abstractmethod
    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        pass

    @abstractmethod
    def apply(self, state: Any, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        pass

    def priority(self) -> int:
        return 100

    def category(self) -> str:
        return "lifecycle"
