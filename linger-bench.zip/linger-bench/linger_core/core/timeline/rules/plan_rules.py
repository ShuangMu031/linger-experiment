from typing import TYPE_CHECKING, Any

from linger_core.core.timeline.rules.base_rule import BaseRule
from linger_core.core.contracts.rule_contract import RuleOutput
from linger_core.core.state.runtime_state import RuntimeState

if TYPE_CHECKING:
    from linger_core.core.state.runtime_state_view import RuntimeStateView


class PlanExpiryRule(BaseRule):

    def name(self) -> str:
        return "plan_expiry_check"

    def applies_to(self, state: Any, view: "RuntimeStateView") -> bool:
        return isinstance(state, RuntimeState) and len(view.plan.active_plans()) > 0

    def apply(self, state: RuntimeState, view: "RuntimeStateView", delta_seconds: float) -> RuleOutput:
        before_count = len(view.plan.active_plans())
        expired = state.plan_state.check_expired_plans(world_now=view.clock.world_now_time())
        after_count = before_count - len(expired)

        return RuleOutput(
            rule_name=self.name(),
            target="plan_state",
            changes=[{
                "field": "plan_state.active_count",
                "before": before_count,
                "after": after_count,
                "expired_count": len(expired),
            }],
        )

    def priority(self) -> int:
        return 50

    def category(self) -> str:
        return "lifecycle"
