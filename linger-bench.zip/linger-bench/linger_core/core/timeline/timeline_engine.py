from datetime import timedelta
from typing import Dict, List

from linger_core.core.state.runtime_state import RuntimeState
from linger_core.core.timeline.rules.base_rule import BaseRule
from linger_core.core.contracts.rule_contract import RuleOutput
from linger_core.core.timeline.rules.session_rules import SessionIdleRule
from linger_core.core.timeline.rules.emotion_rules import EmotionDecayRule
from linger_core.core.timeline.rules.memory_rules import ShortTermMemoryExpiryRule, FollowupEntryExtensionRule, ActiveThreadBoostRule
from linger_core.core.timeline.rules.event_rules import EventCoolingRule, EventDecayRule, EventRefreshRule, EventArchiveRule
from linger_core.core.timeline.rules.long_term_rules import LongTermCoolingRule, LongTermArchiveRule, LongTermRefreshRule
from linger_core.core.timeline.rules.digest_rules import DigestGenerationRule, DigestCleanupRule
from linger_core.core.timeline.rules.world_rules import WorldTickRule
from linger_core.core.timeline.rules.plan_rules import PlanExpiryRule
from linger_core.core.timeline.rules.world_time_rules import WorldTimeRule
from linger_core.core.timeline.rules.place_rules import PlaceAmbientRule
from linger_core.core.timeline.rules.npc_rules import NpcScheduleRule
from linger_core.core.timeline.rules.world_event_rules import WorldEventCoolRule, WorldEventArchiveRule
from linger_core.core.timeline.rules.world_event_generation_rule import WeatherTransitionRule, WorldEventGenerationRule


class TimelineEngine:
    def __init__(self, rules: List[BaseRule] = None):
        if rules is None:
            self._rules: List[BaseRule] = [
                SessionIdleRule(),
                EmotionDecayRule(),
                ShortTermMemoryExpiryRule(),
                FollowupEntryExtensionRule(),
                ActiveThreadBoostRule(),
                EventCoolingRule(),
                EventDecayRule(),
                EventRefreshRule(),
                EventArchiveRule(),
                LongTermCoolingRule(),
                LongTermArchiveRule(),
                LongTermRefreshRule(),
                DigestGenerationRule(),
                DigestCleanupRule(),
                WorldTickRule(),
                WorldTimeRule(),
                PlaceAmbientRule(),
                NpcScheduleRule(),
                WeatherTransitionRule(),
                WorldEventGenerationRule(),
                WorldEventCoolRule(),
                WorldEventArchiveRule(),
                PlanExpiryRule(),
            ]
        else:
            self._rules = rules
        self._rules.sort(key=lambda r: r.priority())

    def tick(self, state: RuntimeState, delta: timedelta) -> List[RuleOutput]:
        from linger_core.core.state.runtime_state_view import RuntimeStateView

        delta_seconds = delta.total_seconds()
        results: List[RuleOutput] = []

        view = RuntimeStateView.from_state(state)

        for rule in self._rules:
            if rule.applies_to(state, view):
                output = rule.apply(state, view, delta_seconds)
                results.append(output)

        return results

    def add_rule(self, rule: BaseRule) -> None:
        self._rules.append(rule)
        self._rules.sort(key=lambda r: r.priority())

    def remove_rule(self, rule_name: str) -> None:
        self._rules = [r for r in self._rules if r.name() != rule_name]

    def list_rules(self) -> List[str]:
        return [r.name() for r in self._rules]

    def list_rules_by_category(self) -> Dict[str, List[str]]:
        result: Dict[str, List[str]] = {}
        for rule in self._rules:
            cat = rule.category()
            if cat not in result:
                result[cat] = []
            result[cat].append(rule.name())
        return result
