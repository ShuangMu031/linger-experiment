"""C12 决策解释器 — 把一轮 ActionPlan 翻译成普通中文。

目标：让一个不懂这个项目内部结构的人也能看懂"她为什么这么回。"
不是 LLM 自然语言生成，是规则化的、可复现的、人类风格的拼装。

输入：TurnSnapshot
输出：一段中文（4–10 行），按"她想做什么 → 因为感觉到什么 → 决定怎么说 → 最终是否说"的逻辑展开。

为什么不调 LLM：
  - 解释器本身不能再绕回 LLM，否则它会变成一个"二次黑盒"
  - 工程合同要求：白盒的解释必须是确定性的、可复现的
  - 出现"解释和事实不符"时，bug 就在解释器，不在模型

设计：所有判断都从 TurnSnapshot 拿，不读任何运行时状态。
"""

from typing import Any, Dict, List, Optional

from linger_core.core.observability.turn_snapshot import TurnSnapshot


_GOAL_PHRASES = {
    "respond": "正常回应",
    "respond_user": "正常回应",
    "casual_statement": "随意聊一聊",
    "comfort": "情绪承接",
    "comfort_user": "情绪承接",
    "inquire": "请用户多说一点",
    "inform": "告诉用户一件事",
    "follow_up": "跟进上一轮",
    "gentle_check_in": "轻量问候",
    "world_observation": "分享世界变化",
    "reconnect": "重连陪伴",
    "supportive_presence": "在场陪伴",
    "unfinished_thread_ping": "回到没完的话题",
    "light_plan_reminder": "轻提醒一下",
}

_SPEAK_MODE_PHRASES = {
    "normal": "用自然语气说",
    "comfort_only": "只承接情绪、不推进",
    "comfort_first": "先承接、再轻轻给一点建议",
    "warm_respond": "用偏温和的语气说",
    "warm_acknowledge": "暖一点地确认",
    "gentle_presence": "轻一点、像在场就好",
    "welcome_back": "像她久违地见你",
}

_EXPRESSION_PHRASES = {
    "neutral": "中性",
    "warm": "偏温暖",
    "gentle": "轻、克制",
    "casual": "随意",
}

_EMOTION_TRIGGER_THRESHOLD = 0.5


def _module_judgment(snap: TurnSnapshot, layer_name: str) -> Dict[str, Any]:
    for j in snap.whitebox_trace.get("module_judgments", []):
        if isinstance(j, dict) and j.get("layer") == layer_name:
            return j.get("content", {}) or {}
    return {}


def _detected_emotion(snap: TurnSnapshot) -> Optional[str]:
    em = _module_judgment(snap, "emotion_insight_module")
    if not em:
        em = _module_judgment(snap, "emotion_insight")
    primary = em.get("primary_emotion")
    intensity = em.get("intensity", 0)
    try:
        intensity = float(intensity)
    except (TypeError, ValueError):
        intensity = 0.0
    if not primary or primary == "neutral":
        return None
    if intensity < _EMOTION_TRIGGER_THRESHOLD:
        return None
    return f"{primary}（强度 {intensity:.1f}）"


def _context_signals(snap: TurnSnapshot) -> List[str]:
    notes: List[str] = []
    cc = _module_judgment(snap, "context_check_module") or _module_judgment(snap, "context_check")
    if cc:
        if cc.get("needs_memory_recall"):
            notes.append("需要翻短期记忆")
        if cc.get("needs_event_recall"):
            notes.append("需要翻事件记忆")
        if cc.get("needs_world_context"):
            notes.append("需要看世界状态")
        if cc.get("needs_clarification"):
            notes.append("可能需要再问一句确认")
    return notes


def _summarize_llm(snap: TurnSnapshot) -> List[str]:
    notes: List[str] = []
    calls = snap.llm_calls()
    if not calls:
        return notes
    failed = [c for c in calls if not c.get("success")]
    fallback = [c for c in calls if c.get("fallback_used")]
    retry = [c for c in calls if int(c.get("retry_count", 0) or 0) > 0]
    if failed:
        tasks = ",".join(c.get("task_type", "?") for c in failed)
        notes.append(f"有 {len(failed)} 次 LLM 调用失败（{tasks}）")
    if fallback:
        notes.append(f"有 {len(fallback)} 次降级到 mock")
    if retry:
        notes.append(f"有 {len(retry)} 次重试后才成功")
    return notes


def explain(snap: TurnSnapshot) -> str:
    ap = snap.action_plan or {}
    primary_goal = ap.get("primary_goal", "respond")
    speak_mode = ap.get("speak_mode", "normal")
    expression_style = ap.get("expression_style", "neutral")
    response_strategy = ap.get("response_strategy", "")
    confidence = ap.get("confidence", 0.0)
    should_comfort = bool(ap.get("should_comfort"))
    should_ask_question = bool(ap.get("should_ask_question"))
    should_pause = bool(ap.get("should_pause"))
    can_speak = bool(ap.get("can_speak", True))
    reasoning = (ap.get("reasoning_summary") or "").strip()
    bad_tags = snap.bad_case_tags or []

    lines: List[str] = []

    if snap.envelope_source == "user_input":
        lines.append(f"她这一轮的目标是：{_GOAL_PHRASES.get(primary_goal, primary_goal)}。")
    else:
        lines.append(f"她这一轮是主动开口，目标是：{_GOAL_PHRASES.get(primary_goal, primary_goal)}。")

    causes: List[str] = []
    emotion = _detected_emotion(snap)
    if emotion:
        causes.append(f"她感受到用户情绪是 {emotion}")
    ctx_notes = _context_signals(snap)
    if ctx_notes:
        causes.append("；".join(ctx_notes))
    if reasoning:
        causes.append(f"推理摘要：{reasoning[:120]}")

    if causes:
        lines.append("理由是：" + "；".join(causes) + "。")

    expr = _EXPRESSION_PHRASES.get(expression_style, expression_style)
    speak = _SPEAK_MODE_PHRASES.get(speak_mode, speak_mode)
    lines.append(f"于是她选择 {speak}，表达风格 {expr}。")

    flags: List[str] = []
    if should_comfort:
        flags.append("会先承接情绪")
    if should_ask_question:
        flags.append("会带一个问题")
    if should_pause:
        flags.append("说完会停一下让用户喘口气")
    if not can_speak:
        flags.append("这一轮其实是不打算说出来的")
    if flags:
        lines.append("具体倾向：" + "、".join(flags) + "。")

    if response_strategy:
        lines.append(f"策略字段：{response_strategy}（置信度 {confidence:.2f}）。")

    llm_notes = _summarize_llm(snap)
    if llm_notes:
        lines.append("过程中：" + "；".join(llm_notes) + "。")

    if bad_tags:
        lines.append(f"⚠️ 这一轮被标记为坏样本：{','.join(bad_tags)}。")

    if snap.should_emit and snap.response_message:
        lines.append(f'最后她说出来的是："{snap.response_message}"')
    elif snap.should_emit and not snap.response_message:
        lines.append("最后 should_emit=True 但 response_message 为空——这是个 bug。")
    else:
        lines.append("最后她选择沉默，没有发出任何消息。")

    return "\n".join(lines)
