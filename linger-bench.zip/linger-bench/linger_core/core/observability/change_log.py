from datetime import datetime
from typing import List

from linger_core.core.observability.schemas import ChangeRecord
from linger_core.core.contracts.rule_contract import RuleOutput


class ChangeLog:
    def __init__(self, max_records: int = 1000):
        self._records: List[ChangeRecord] = []
        self._max_records = max_records

    def record_rule_output(self, output: RuleOutput) -> None:
        timestamp = datetime.now().isoformat()
        for change in output.changes:
            record = ChangeRecord(
                timestamp=timestamp,
                rule_name=output.rule_name,
                target=output.target,
                field=change.get("field", "unknown"),
                before=change.get("before"),
                after=change.get("after"),
                metadata={k: v for k, v in change.items() if k not in ("field", "before", "after")},
            )
            self._records.append(record)

        if len(self._records) > self._max_records:
            self._records = self._records[-self._max_records:]

    def get_recent(self, count: int = 20) -> List[ChangeRecord]:
        return self._records[-count:]

    def get_by_target(self, target: str) -> List[ChangeRecord]:
        return [r for r in self._records if r.target == target]

    def clear(self) -> None:
        self._records.clear()

    def count(self) -> int:
        return len(self._records)
