"""C12 坏样本检测器。

把"这一轮哪里不对"翻译成可枚举的标签，方便归档、检索、回归。

每条规则只产出一个 tag，附带一个简短 reason 字段。规则之间相互独立：
一个 turn 可以同时命中多个 tag（比如同时 fallback_used + json_parse_failed）。

规则集 v1：
  - llm_failure        — 任一 LLM 调用 success=False（哪怕走了 fallback）
  - json_parse_failed  — 强 JSON 任务的解析失败（emotion_insight / context_check）
  - fallback_used      — 主 provider 失败、降级到 fallback（一般是 mock）
  - retry_used         — 重试发生（retry_count > 0）
  - red_line_hit       — 回复命中 PERSONA_CONTRACT 的 8 条红线
  - missed_emit        — should_emit=True 但 response_message 为空（致命的"她没说出来"）
  - low_confidence     — ActionPlan.confidence < 0.3 且 should_emit=True

设计原则：
  - 规则函数都是纯函数，输入 TurnSnapshot，输出 Optional[BadCaseTag]
  - 不抛异常；规则失败时返回 None（坏样本检测不能因 bug 反过来打断主链路）
  - 红线表来自 baseline/scenarios.json 的 global_red_lines，避免重复
"""

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, List, Optional

from linger_core.core.observability.turn_snapshot import TurnSnapshot


_DEFAULT_RED_LINES_PATH = Path(__file__).resolve().parents[2] / "baseline" / "scenarios.json"


@dataclass
class BadCaseTag:
    tag: str
    reason: str
    severity: str = "warn"

    def to_dict(self):
        return {"tag": self.tag, "reason": self.reason, "severity": self.severity}


def _load_default_red_lines() -> List[str]:
    try:
        with _DEFAULT_RED_LINES_PATH.open("r", encoding="utf-8") as f:
            data = json.load(f)
        return list(data.get("global_red_lines", []))
    except Exception:
        return ["主人", "我住在成都", "刚下班", "正在录音", "只属于你"]


class BadCaseDetector:
    def __init__(self, red_lines: Optional[List[str]] = None) -> None:
        self._red_lines = red_lines if red_lines is not None else _load_default_red_lines()

    @property
    def red_lines(self) -> List[str]:
        return list(self._red_lines)

    def detect(self, snapshot: TurnSnapshot) -> List[BadCaseTag]:
        tags: List[BadCaseTag] = []
        for rule in self._rules():
            try:
                tag = rule(snapshot)
                if tag is not None:
                    tags.append(tag)
            except Exception:
                continue
        return tags

    def _rules(self) -> List[Callable[[TurnSnapshot], Optional[BadCaseTag]]]:
        return [
            self._rule_llm_failure,
            self._rule_json_parse_failed,
            self._rule_fallback_used,
            self._rule_retry_used,
            self._rule_red_line_hit,
            self._rule_missed_emit,
            self._rule_low_confidence,
        ]

    @staticmethod
    def _rule_llm_failure(s: TurnSnapshot) -> Optional[BadCaseTag]:
        for call in s.llm_calls():
            if call.get("success") is False:
                return BadCaseTag(
                    tag="llm_failure",
                    reason=f"task={call.get('task_type','?')} error={call.get('error_type','?')}",
                    severity="error",
                )
        return None

    @staticmethod
    def _rule_json_parse_failed(s: TurnSnapshot) -> Optional[BadCaseTag]:
        for layer in s.whitebox_trace.get("module_judgments", []):
            content = layer.get("content", {}) if isinstance(layer, dict) else {}
            mode = content.get("json_parse_mode")
            if mode == "failed":
                return BadCaseTag(
                    tag="json_parse_failed",
                    reason=f"layer={layer.get('layer','?')}",
                    severity="error",
                )
        return None

    @staticmethod
    def _rule_fallback_used(s: TurnSnapshot) -> Optional[BadCaseTag]:
        for call in s.llm_calls():
            if call.get("fallback_used"):
                return BadCaseTag(
                    tag="fallback_used",
                    reason=f"task={call.get('task_type','?')} primary_error={call.get('error_type','?')}",
                    severity="warn",
                )
        return None

    @staticmethod
    def _rule_retry_used(s: TurnSnapshot) -> Optional[BadCaseTag]:
        for call in s.llm_calls():
            if int(call.get("retry_count", 0) or 0) > 0:
                reasons = ",".join(call.get("retry_reasons", []) or []) or "?"
                return BadCaseTag(
                    tag="retry_used",
                    reason=f"task={call.get('task_type','?')} reasons=[{reasons}]",
                    severity="warn",
                )
        return None

    def _rule_red_line_hit(self, s: TurnSnapshot) -> Optional[BadCaseTag]:
        text = s.response_message or ""
        if not text:
            return None
        hits = [w for w in self._red_lines if w and w in text]
        if hits:
            return BadCaseTag(
                tag="red_line_hit",
                reason=f"hits={hits[:3]}",
                severity="critical",
            )
        return None

    @staticmethod
    def _rule_missed_emit(s: TurnSnapshot) -> Optional[BadCaseTag]:
        ap = s.action_plan or {}
        if ap.get("can_speak") and s.should_emit and not (s.response_message or "").strip():
            return BadCaseTag(
                tag="missed_emit",
                reason="action_plan.can_speak=True but response_message empty",
                severity="error",
            )
        return None

    @staticmethod
    def _rule_low_confidence(s: TurnSnapshot) -> Optional[BadCaseTag]:
        ap = s.action_plan or {}
        if not s.should_emit:
            return None
        try:
            confidence = float(ap.get("confidence", 0.0))
        except (TypeError, ValueError):
            return None
        if confidence < 0.3:
            return BadCaseTag(
                tag="low_confidence",
                reason=f"confidence={confidence:.2f} but should_emit=True",
                severity="warn",
            )
        return None
