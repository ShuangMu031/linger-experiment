import time
from datetime import datetime
from typing import Any, Dict, List, Optional

from linger_core.core.observability.schemas import TraceRecord, WhiteboxTrace, WhiteboxLayer
from linger_core.shared.ids import generate_id


class TraceStore:
    def __init__(self, max_traces: int = 200):
        self._traces: List[TraceRecord] = []
        self._whitebox_traces: List[WhiteboxTrace] = []
        self._max_traces = max_traces
        self._active_stack: List[TraceRecord] = []
        self._active_whitebox_by_trace_id: Dict[str, WhiteboxTrace] = {}
        self._whitebox_start_time_by_trace_id: Dict[str, float] = {}

    def start_trace(self, event_type: str) -> str:
        trace_id = generate_id()
        parent = self.current_trace()
        trace = TraceRecord(
            trace_id=trace_id,
            event_type=event_type,
            start_time=datetime.now().isoformat(),
            parent_trace_id=parent.trace_id if parent else None,
            depth=len(self._active_stack),
        )
        self._active_stack.append(trace)
        return trace_id

    def current_trace(self) -> Optional[TraceRecord]:
        if self._active_stack:
            return self._active_stack[-1]
        return None

    def start_whitebox_trace(self, trace_id: str, turn_id: int) -> WhiteboxTrace:
        wb = WhiteboxTrace(trace_id=trace_id, turn_id=turn_id)
        self._active_whitebox_by_trace_id[trace_id] = wb
        self._whitebox_start_time_by_trace_id[trace_id] = time.monotonic() * 1000
        return wb

    def add_step(self, step: Dict[str, Any]) -> None:
        current = self.current_trace()
        if current is not None:
            current.steps.append(step)

    def set_input_understanding(self, trace_id: str, content: Dict[str, Any]) -> None:
        wb = self._active_whitebox_by_trace_id.get(trace_id)
        if wb is not None:
            wb.input_understanding = WhiteboxLayer(
                layer_name="input_understanding",
                layer_type="perception",
                content=content,
                timestamp=datetime.now().isoformat(),
            )

    def add_module_judgment(self, trace_id: str, module_name: str, content: Dict[str, Any]) -> None:
        wb = self._active_whitebox_by_trace_id.get(trace_id)
        if wb is not None:
            wb.module_judgments.append(WhiteboxLayer(
                layer_name=module_name,
                layer_type="judgment",
                content=content,
                timestamp=datetime.now().isoformat(),
            ))

    def set_supervisor_decision(self, trace_id: str, content: Dict[str, Any]) -> None:
        wb = self._active_whitebox_by_trace_id.get(trace_id)
        if wb is not None:
            wb.supervisor_decision = WhiteboxLayer(
                layer_name="supervisor",
                layer_type="decision",
                content=content,
                timestamp=datetime.now().isoformat(),
            )

    def set_action_result(self, trace_id: str, content: Dict[str, Any]) -> None:
        wb = self._active_whitebox_by_trace_id.get(trace_id)
        if wb is not None:
            wb.action_result = WhiteboxLayer(
                layer_name="action",
                layer_type="result",
                content=content,
                timestamp=datetime.now().isoformat(),
            )

    def end_trace(self, result: str = "") -> Optional[TraceRecord]:
        if not self._active_stack:
            return None
        trace = self._active_stack.pop()
        trace.end_time = datetime.now().isoformat()
        trace.result = result
        self._traces.append(trace)
        if len(self._traces) > self._max_traces:
            self._traces = self._traces[-self._max_traces:]
        return trace

    def end_whitebox_trace(self, trace_id: str = "") -> Optional[WhiteboxTrace]:
        wb = None
        if trace_id and trace_id in self._active_whitebox_by_trace_id:
            wb = self._active_whitebox_by_trace_id.pop(trace_id)
            start_ms = self._whitebox_start_time_by_trace_id.pop(trace_id, 0.0)
        else:
            return None
        wb.duration_ms = time.monotonic() * 1000 - start_ms
        self._whitebox_traces.append(wb)
        if len(self._whitebox_traces) > self._max_traces:
            self._whitebox_traces = self._whitebox_traces[-self._max_traces:]
        return wb

    @property
    def trace_depth(self) -> int:
        return len(self._active_stack)

    def get_recent(self, count: int = 10) -> List[TraceRecord]:
        return self._traces[-count:]

    def get_by_event_type(self, event_type: str) -> List[TraceRecord]:
        return [t for t in self._traces if t.event_type == event_type]

    def get_whitebox_traces(self, count: int = 10) -> List[WhiteboxTrace]:
        return self._whitebox_traces[-count:]

    def get_latest_whitebox(self) -> Optional[WhiteboxTrace]:
        if self._whitebox_traces:
            return self._whitebox_traces[-1]
        return None

    def clear(self) -> None:
        self._traces.clear()
        self._whitebox_traces.clear()
        self._active_stack.clear()
        self._active_whitebox_by_trace_id.clear()
        self._whitebox_start_time_by_trace_id.clear()
