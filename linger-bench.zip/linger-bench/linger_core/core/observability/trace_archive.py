"""C12 TurnSnapshot 持久化层。

落盘策略：
  - 根目录: .data/traces/
  - 按日期分桶: .data/traces/2026-04-29/
  - 文件名: <turn_id_padded>_<short_trace_id>.json
    例: 000142_a1b2c3d4.json
  - 一轮一文件，append-only，永不修改
  - turn_id 零填充 6 位，方便文件名排序 == 时间顺序

加载策略：
  - load_recent: 从最近的日期桶向回扫，按 mtime 取 N 条
  - load_by_turn_id: 全局 glob，命中第一个匹配
  - load_by_path: 直读

设计为零依赖、纯文件 IO，便于离线工具直接消费。
"""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from linger_core.core.observability.turn_snapshot import TurnSnapshot
from linger_core.persistence import data_paths as _dp


def _pad_turn_id(turn_id: int) -> str:
    return f"{turn_id:06d}"


def _short_trace(trace_id: str) -> str:
    return (trace_id or "noid")[:8]


def _date_bucket(ts_iso: str) -> str:
    try:
        return ts_iso.split("T", 1)[0]
    except Exception:
        return datetime.now().strftime("%Y-%m-%d")


class TraceArchive:
    def __init__(self, root: Optional[str] = None) -> None:
        self._root = Path(root or _dp.TRACES_DIR)

    @property
    def root(self) -> Path:
        return self._root

    def persist(self, snapshot: TurnSnapshot) -> Path:
        bucket = self._root / _date_bucket(snapshot.timestamp)
        bucket.mkdir(parents=True, exist_ok=True)
        filename = f"{_pad_turn_id(snapshot.turn_id)}_{_short_trace(snapshot.trace_id)}.json"
        path = bucket / filename
        with path.open("w", encoding="utf-8") as f:
            json.dump(snapshot.to_dict(), f, ensure_ascii=False, indent=2)
        return path

    def load_by_path(self, path) -> TurnSnapshot:
        p = Path(path)
        with p.open("r", encoding="utf-8") as f:
            d = json.load(f)
        return TurnSnapshot.from_dict(d)

    def list_dates(self) -> List[str]:
        if not self._root.exists():
            return []
        dates = [p.name for p in self._root.iterdir() if p.is_dir()]
        return sorted(dates)

    def list_files(self, date: Optional[str] = None) -> List[Path]:
        if not self._root.exists():
            return []
        if date is not None:
            bucket = self._root / date
            if not bucket.exists():
                return []
            return sorted(bucket.glob("*.json"))
        all_files: List[Path] = []
        for d in self.list_dates():
            all_files.extend((self._root / d).glob("*.json"))
        return sorted(all_files)

    def load_recent(self, count: int = 10) -> List[TurnSnapshot]:
        files = self.list_files()
        files = files[-count:]
        return [self.load_by_path(p) for p in files]

    def load_by_turn_id(self, turn_id: int) -> Optional[TurnSnapshot]:
        target_prefix = _pad_turn_id(turn_id) + "_"
        for d in reversed(self.list_dates()):
            for p in (self._root / d).glob("*.json"):
                if p.name.startswith(target_prefix):
                    return self.load_by_path(p)
        return None

    def load_by_trace_id(self, trace_id: str) -> Optional[TurnSnapshot]:
        target_suffix = "_" + _short_trace(trace_id) + ".json"
        for d in reversed(self.list_dates()):
            for p in (self._root / d).glob("*.json"):
                if p.name.endswith(target_suffix):
                    return self.load_by_path(p)
        return None

    def count(self) -> int:
        return len(self.list_files())
