from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class LogEntry:
    timestamp: str
    event_type: str
    data: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ChangeRecord:
    timestamp: str
    rule_name: str
    target: str
    field: str
    before: Any
    after: Any
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TraceRecord:
    trace_id: str
    event_type: str
    start_time: str
    end_time: Optional[str] = None
    steps: List[Dict[str, Any]] = field(default_factory=list)
    result: Optional[str] = None
    parent_trace_id: Optional[str] = None
    depth: int = 0


@dataclass
class WhiteboxLayer:
    layer_name: str
    layer_type: str
    content: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = ""


@dataclass
class WhiteboxTrace:
    trace_id: str
    turn_id: int
    input_understanding: Optional[WhiteboxLayer] = None
    module_judgments: List[WhiteboxLayer] = field(default_factory=list)
    supervisor_decision: Optional[WhiteboxLayer] = None
    action_result: Optional[WhiteboxLayer] = None
    duration_ms: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        result = {
            "trace_id": self.trace_id,
            "turn_id": self.turn_id,
            "duration_ms": self.duration_ms,
        }
        if self.input_understanding:
            result["input_understanding"] = {
                "content": self.input_understanding.content,
                "timestamp": self.input_understanding.timestamp,
            }
        if self.module_judgments:
            result["module_judgments"] = [
                {"layer": m.layer_name, "content": m.content, "timestamp": m.timestamp}
                for m in self.module_judgments
            ]
        if self.supervisor_decision:
            result["supervisor_decision"] = {
                "content": self.supervisor_decision.content,
                "timestamp": self.supervisor_decision.timestamp,
            }
        if self.action_result:
            result["action_result"] = {
                "content": self.action_result.content,
                "timestamp": self.action_result.timestamp,
            }
        return result
