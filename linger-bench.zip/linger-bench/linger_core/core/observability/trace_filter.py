"""C12.J TurnSnapshot 过滤器。

把"我只想看带 fallback_used 的最近 20 轮、来自用户输入"这种条件
表达为一个 TurnFilter 对象，统一应用到 List[TurnSnapshot]。

所有字段都是可选的，None 表示该维度不过滤。
"""

from dataclasses import dataclass
from typing import List, Optional

from linger_core.core.observability.turn_snapshot import TurnSnapshot


@dataclass
class TurnFilter:
    since_ts: Optional[str] = None
    until_ts: Optional[str] = None
    tag: Optional[str] = None
    source: Optional[str] = None
    has_bad_case: Optional[bool] = None
    only_emit: Optional[bool] = None
    min_turn: Optional[int] = None
    max_turn: Optional[int] = None

    def matches(self, s: TurnSnapshot) -> bool:
        if self.since_ts is not None and s.timestamp < self.since_ts:
            return False
        if self.until_ts is not None and s.timestamp > self.until_ts:
            return False
        if self.tag is not None and self.tag not in (s.bad_case_tags or []):
            return False
        if self.source is not None and s.envelope_source != self.source:
            return False
        if self.has_bad_case is not None:
            if bool(s.bad_case_tags) != self.has_bad_case:
                return False
        if self.only_emit is True and not s.should_emit:
            return False
        if self.only_emit is False and s.should_emit:
            return False
        if self.min_turn is not None and s.turn_id < self.min_turn:
            return False
        if self.max_turn is not None and s.turn_id > self.max_turn:
            return False
        return True


def apply_filter(snapshots: List[TurnSnapshot], f: TurnFilter) -> List[TurnSnapshot]:
    return [s for s in snapshots if f.matches(s)]
