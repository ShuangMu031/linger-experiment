"""C12 白盒观测台的核心数据载体。

`TurnSnapshot` 把一轮对话的所有可观测信息收口到一个对象里：
  - 输入信封（用户消息或主动触发）
  - WhiteboxTrace（input_understanding / module_judgments / supervisor_decision / action_result）
  - TraceRecord.steps（自由步骤事件 — 包括 llm_call 的 prompt_id/hash/retry）
  - 完整 ActionPlan
  - 最终回复 + writeback 摘要
  - 运行时元数据（耗时、是否发出、模型档位等）

这一对象既能在内存中传递，也能直接 to_dict()→json.dump 写盘。
落盘后由 TraceArchive 负责，渲染由 TraceViewer 负责。
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional


@dataclass
class TurnSnapshot:
    turn_id: int
    trace_id: str
    timestamp: str
    envelope_source: str
    user_message: str
    response_message: str
    should_emit: bool

    action_plan: Dict[str, Any] = field(default_factory=dict)
    whitebox_trace: Dict[str, Any] = field(default_factory=dict)
    trace_steps: List[Dict[str, Any]] = field(default_factory=list)
    writeback_summary: Dict[str, Any] = field(default_factory=dict)

    duration_ms: float = 0.0
    bad_case_tags: List[str] = field(default_factory=list)

    schema_version: str = "v1"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "turn_id": self.turn_id,
            "trace_id": self.trace_id,
            "timestamp": self.timestamp,
            "envelope_source": self.envelope_source,
            "user_message": self.user_message,
            "response_message": self.response_message,
            "should_emit": self.should_emit,
            "action_plan": self.action_plan,
            "whitebox_trace": self.whitebox_trace,
            "trace_steps": self.trace_steps,
            "writeback_summary": self.writeback_summary,
            "duration_ms": self.duration_ms,
            "bad_case_tags": list(self.bad_case_tags),
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "TurnSnapshot":
        return cls(
            turn_id=int(d.get("turn_id", 0)),
            trace_id=str(d.get("trace_id", "")),
            timestamp=str(d.get("timestamp", "")),
            envelope_source=str(d.get("envelope_source", "")),
            user_message=str(d.get("user_message", "")),
            response_message=str(d.get("response_message", "")),
            should_emit=bool(d.get("should_emit", False)),
            action_plan=dict(d.get("action_plan", {})),
            whitebox_trace=dict(d.get("whitebox_trace", {})),
            trace_steps=list(d.get("trace_steps", [])),
            writeback_summary=dict(d.get("writeback_summary", {})),
            duration_ms=float(d.get("duration_ms", 0.0)),
            bad_case_tags=list(d.get("bad_case_tags", [])),
            schema_version=str(d.get("schema_version", "v1")),
        )

    def llm_calls(self) -> List[Dict[str, Any]]:
        """从 trace_steps 中筛出 llm_call 子集，供 viewer / detector 直接使用。"""
        return [s for s in self.trace_steps if s.get("step") == "llm_call"]


def build_turn_snapshot(
    *,
    turn_id: int,
    trace_id: str,
    envelope_source: str,
    user_message: str,
    response_message: str,
    should_emit: bool,
    action_plan_dict: Dict[str, Any],
    whitebox_dict: Dict[str, Any],
    trace_steps: List[Dict[str, Any]],
    writeback_summary_dict: Dict[str, Any],
    duration_ms: float,
    timestamp: Optional[str] = None,
) -> TurnSnapshot:
    return TurnSnapshot(
        turn_id=turn_id,
        trace_id=trace_id,
        timestamp=timestamp or datetime.now().isoformat(),
        envelope_source=envelope_source,
        user_message=user_message,
        response_message=response_message,
        should_emit=should_emit,
        action_plan=action_plan_dict,
        whitebox_trace=whitebox_dict,
        trace_steps=list(trace_steps),
        writeback_summary=writeback_summary_dict,
        duration_ms=duration_ms,
    )
