"""C13 人格/行为漂移检测器。

回答的核心问题：**"她最近是不是变成了另一个人？"**

设计原则：
  - 纯函数，不调 LLM，不依赖外部模型
  - 输入：两组 TurnSnapshot（current vs reference / window vs window）
  - 输出：每个维度的漂移分数 + 是否超阈值
  - 阈值是建议值，使用方可调

漂移维度（v1，6 维）：
  1. speak_mode_drift          — speak_mode 分布的 KL 散度
  2. primary_goal_drift        — primary_goal 分布的 KL 散度
  3. emotion_priority_drift    — emotion_priority 分布的 KL 散度
  4. response_length_drift     — 响应长度分布的均值/方差变化
  5. bad_case_rate_delta       — 坏样本率绝对变化
  6. fallback_rate_delta       — LLM fallback 率绝对变化

漂移分数都在 [0, 1] 区间（0=完全一致，1=完全不一致）。
"""

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from linger_core.core.observability.turn_snapshot import TurnSnapshot


@dataclass
class DriftSignal:
    name: str
    score: float
    threshold: float
    reference_summary: str = ""
    current_summary: str = ""

    @property
    def triggered(self) -> bool:
        return self.score >= self.threshold

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "score": round(self.score, 4),
            "threshold": self.threshold,
            "triggered": self.triggered,
            "reference": self.reference_summary,
            "current": self.current_summary,
        }


@dataclass
class DriftReport:
    reference_count: int
    current_count: int
    signals: List[DriftSignal] = field(default_factory=list)

    @property
    def triggered_signals(self) -> List[DriftSignal]:
        return [s for s in self.signals if s.triggered]

    @property
    def has_drift(self) -> bool:
        return bool(self.triggered_signals)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "reference_count": self.reference_count,
            "current_count": self.current_count,
            "has_drift": self.has_drift,
            "signals": [s.to_dict() for s in self.signals],
        }


def _categorical_dist(values: List[str]) -> Dict[str, float]:
    if not values:
        return {}
    n = len(values)
    counts: Dict[str, int] = {}
    for v in values:
        counts[v] = counts.get(v, 0) + 1
    return {k: c / n for k, c in counts.items()}


def _js_divergence(p: Dict[str, float], q: Dict[str, float]) -> float:
    """Jensen-Shannon 散度，对称、有界 [0, 1]（用 log2）。"""
    if not p and not q:
        return 0.0
    keys = set(p.keys()) | set(q.keys())
    eps = 1e-12

    def _ent(d: Dict[str, float]) -> float:
        s = 0.0
        for k in keys:
            v = d.get(k, 0.0)
            if v > 0:
                s -= v * math.log2(v)
        return s

    m = {k: 0.5 * (p.get(k, 0.0) + q.get(k, 0.0)) for k in keys}
    h_p = _ent(p)
    h_q = _ent(q)
    h_m = _ent(m)
    js = h_m - 0.5 * (h_p + h_q)
    if js < 0:
        return 0.0
    return min(js, 1.0)


def _length_distribution(snapshots: List[TurnSnapshot]) -> Tuple[float, float]:
    """返回 (mean, stdev) 的回复长度。"""
    lengths = [len(s.response_message or "") for s in snapshots if s.should_emit]
    if not lengths:
        return 0.0, 0.0
    n = len(lengths)
    mean = sum(lengths) / n
    if n < 2:
        return mean, 0.0
    var = sum((x - mean) ** 2 for x in lengths) / (n - 1)
    return mean, math.sqrt(var)


def _bad_case_rate(snapshots: List[TurnSnapshot]) -> float:
    if not snapshots:
        return 0.0
    return sum(1 for s in snapshots if s.bad_case_tags) / len(snapshots)


def _fallback_rate(snapshots: List[TurnSnapshot]) -> float:
    total = 0
    fb = 0
    for s in snapshots:
        for c in s.llm_calls():
            total += 1
            if c.get("fallback_used"):
                fb += 1
    if total == 0:
        return 0.0
    return fb / total


# === 默认阈值（经验值，使用方可调） ===
DEFAULT_THRESHOLDS = {
    "speak_mode_drift": 0.30,
    "primary_goal_drift": 0.30,
    "emotion_priority_drift": 0.25,
    "response_length_drift": 0.40,
    "bad_case_rate_delta": 0.05,
    "fallback_rate_delta": 0.10,
}


def _length_drift_score(ref_mean: float, ref_std: float,
                        cur_mean: float, cur_std: float) -> float:
    """响应长度漂移：归一化均值差 + 方差变化率。"""
    if ref_mean <= 0 and cur_mean <= 0:
        return 0.0
    base = max(ref_mean, 1.0)
    mean_shift = abs(cur_mean - ref_mean) / base
    if ref_std <= 0 and cur_std <= 0:
        std_shift = 0.0
    else:
        std_base = max(ref_std, 1.0)
        std_shift = abs(cur_std - ref_std) / std_base
    score = (mean_shift + 0.5 * std_shift) / 1.5
    return min(score, 1.0)


def detect_drift(
    reference: List[TurnSnapshot],
    current: List[TurnSnapshot],
    thresholds: Optional[Dict[str, float]] = None,
) -> DriftReport:
    th = dict(DEFAULT_THRESHOLDS)
    if thresholds:
        th.update(thresholds)

    report = DriftReport(reference_count=len(reference), current_count=len(current))
    if not reference or not current:
        return report

    ref_speak = _categorical_dist([(s.action_plan or {}).get("speak_mode", "") for s in reference])
    cur_speak = _categorical_dist([(s.action_plan or {}).get("speak_mode", "") for s in current])
    report.signals.append(DriftSignal(
        name="speak_mode_drift",
        score=_js_divergence(ref_speak, cur_speak),
        threshold=th["speak_mode_drift"],
        reference_summary=_format_top_dist(ref_speak),
        current_summary=_format_top_dist(cur_speak),
    ))

    ref_goal = _categorical_dist([(s.action_plan or {}).get("primary_goal", "") for s in reference])
    cur_goal = _categorical_dist([(s.action_plan or {}).get("primary_goal", "") for s in current])
    report.signals.append(DriftSignal(
        name="primary_goal_drift",
        score=_js_divergence(ref_goal, cur_goal),
        threshold=th["primary_goal_drift"],
        reference_summary=_format_top_dist(ref_goal),
        current_summary=_format_top_dist(cur_goal),
    ))

    ref_emo = _categorical_dist([(s.action_plan or {}).get("emotion_priority", "") for s in reference])
    cur_emo = _categorical_dist([(s.action_plan or {}).get("emotion_priority", "") for s in current])
    report.signals.append(DriftSignal(
        name="emotion_priority_drift",
        score=_js_divergence(ref_emo, cur_emo),
        threshold=th["emotion_priority_drift"],
        reference_summary=_format_top_dist(ref_emo),
        current_summary=_format_top_dist(cur_emo),
    ))

    ref_mean, ref_std = _length_distribution(reference)
    cur_mean, cur_std = _length_distribution(current)
    report.signals.append(DriftSignal(
        name="response_length_drift",
        score=_length_drift_score(ref_mean, ref_std, cur_mean, cur_std),
        threshold=th["response_length_drift"],
        reference_summary=f"mean={ref_mean:.0f} std={ref_std:.0f}",
        current_summary=f"mean={cur_mean:.0f} std={cur_std:.0f}",
    ))

    ref_bad = _bad_case_rate(reference)
    cur_bad = _bad_case_rate(current)
    report.signals.append(DriftSignal(
        name="bad_case_rate_delta",
        score=abs(cur_bad - ref_bad),
        threshold=th["bad_case_rate_delta"],
        reference_summary=f"{ref_bad:.2%}",
        current_summary=f"{cur_bad:.2%}",
    ))

    ref_fb = _fallback_rate(reference)
    cur_fb = _fallback_rate(current)
    report.signals.append(DriftSignal(
        name="fallback_rate_delta",
        score=abs(cur_fb - ref_fb),
        threshold=th["fallback_rate_delta"],
        reference_summary=f"{ref_fb:.2%}",
        current_summary=f"{cur_fb:.2%}",
    ))

    return report


def _format_top_dist(dist: Dict[str, float], top: int = 3) -> str:
    if not dist:
        return "(empty)"
    items = sorted(dist.items(), key=lambda kv: -kv[1])[:top]
    return ", ".join(f"{k}={v:.0%}" for k, v in items if k)


def render_drift(report: DriftReport) -> str:
    lines: List[str] = []
    lines.append("=== Drift Report ===")
    lines.append(f"  reference: {report.reference_count} turns  |  current: {report.current_count} turns")
    if report.has_drift:
        lines.append(f"  ⚠️ {len(report.triggered_signals)} 个信号超过阈值")
    else:
        lines.append("  ✓ 所有信号在阈值内")
    lines.append("")
    for s in report.signals:
        marker = "⚠️" if s.triggered else "  "
        lines.append(f"  {marker} {s.name:<24} score={s.score:.3f}  (th={s.threshold:.2f})")
        lines.append(f"      ref: {s.reference_summary}")
        lines.append(f"      now: {s.current_summary}")
    return "\n".join(lines)
