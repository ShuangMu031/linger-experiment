"""C12 白盒观测台公共 API。

外部使用者（脚本、CLI、测试、未来周期）都应该只 import 这里。
不要直接 import 子模块；子模块的拆分是实现细节，可能调整。

公共类与数据：
  - TurnSnapshot       一轮对话的所有可观测信息（数据载体）
  - TraceArchive       TurnSnapshot 持久化（.data/traces/）
  - BadCaseDetector    7 条坏样本规则
  - BadCaseTag         单条坏样本标记
  - BadCaseArchiver    命中即归档（.data/bad_cases/<tag>/）
  - HealthMetrics      跨 N 个 turn 的聚合指标

公共函数（渲染层 — 纯函数，无副作用）：
  - render_brief       一行摘要
  - render_detailed    完整决策链
  - render_llm_only    仅 LLM 调用
  - render_diff        两轮 diff
  - render_health      健康报告
  - explain            中文决策解释（规则化、不调 LLM）
  - compute_health     跨 turn 聚合

使用规约：
  >>> from linger_core.core.observability import TurnSnapshot, TraceArchive, render_detailed
  >>> arch = TraceArchive()
  >>> snap = arch.load_by_turn_id(42)
  >>> print(render_detailed(snap))
"""

from linger_core.core.observability.turn_snapshot import TurnSnapshot, build_turn_snapshot
from linger_core.core.observability.trace_archive import TraceArchive
from linger_core.core.observability.bad_case_detector import BadCaseDetector, BadCaseTag
from linger_core.core.observability.bad_case_archive import BadCaseArchiver
from linger_core.core.observability.trace_viewer import (
    render_brief,
    render_detailed,
    render_llm_only,
    render_diff,
)
from linger_core.core.observability.decision_explainer import explain
from linger_core.core.observability.health_metrics import (
    HealthMetrics,
    compute as compute_health,
    render_health,
)
from linger_core.core.observability.trace_filter import (
    TurnFilter,
    apply_filter,
)
from linger_core.core.observability.drift_detector import (
    DriftReport,
    DriftSignal,
    detect_drift,
    render_drift,
)
from linger_core.core.observability.health_snapshotter import HealthSnapshotter
from linger_core.core.observability.weekly_digest import (
    WeeklyDigest,
    build_weekly_digest,
    render_digest_markdown,
    write_digest,
)


__all__ = [
    "TurnSnapshot",
    "build_turn_snapshot",
    "TraceArchive",
    "BadCaseDetector",
    "BadCaseTag",
    "BadCaseArchiver",
    "HealthMetrics",
    "HealthSnapshotter",
    "TurnFilter",
    "DriftReport",
    "DriftSignal",
    "WeeklyDigest",
    "render_brief",
    "render_detailed",
    "render_llm_only",
    "render_diff",
    "render_health",
    "render_drift",
    "render_digest_markdown",
    "explain",
    "compute_health",
    "apply_filter",
    "detect_drift",
    "build_weekly_digest",
    "write_digest",
]
