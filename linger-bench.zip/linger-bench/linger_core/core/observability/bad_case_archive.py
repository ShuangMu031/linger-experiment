"""C12 坏样本归档。

把命中规则的 TurnSnapshot 拷贝到独立目录，按 tag 分桶，便于后续做"我都见过哪些坏样本"的回顾。

布局：
  .data/bad_cases/<YYYY-MM-DD>/<tag>/<turn_id>_<short_trace>.json

为什么不复用 traces 目录？
  - traces 是全量历史；bad_cases 是"需要被注意"的子集
  - 分目录方便用 ls/find 直接 grep 某类问题
  - tag 即文件夹，新增规则不影响旧规则

归档动作不影响主链路：所有 IO 错误都吞掉。
"""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from linger_core.core.observability.turn_snapshot import TurnSnapshot
from linger_core.core.observability.bad_case_detector import BadCaseDetector, BadCaseTag
from linger_core.persistence import data_paths as _dp


def _date_bucket(ts_iso: str) -> str:
    try:
        return ts_iso.split("T", 1)[0]
    except Exception:
        return datetime.now().strftime("%Y-%m-%d")


def _pad_turn_id(turn_id: int) -> str:
    return f"{turn_id:06d}"


def _short_trace(trace_id: str) -> str:
    return (trace_id or "noid")[:8]


class BadCaseArchiver:
    def __init__(
        self,
        detector: Optional[BadCaseDetector] = None,
        root: Optional[str] = None,
    ) -> None:
        self._detector = detector or BadCaseDetector()
        self._root = Path(root or _dp.BAD_CASES_DIR)

    @property
    def root(self) -> Path:
        return self._root

    @property
    def detector(self) -> BadCaseDetector:
        return self._detector

    def maybe_archive(self, snapshot: TurnSnapshot, source_path=None) -> List[BadCaseTag]:
        try:
            tags = self._detector.detect(snapshot)
        except Exception:
            return []
        if not tags:
            return []

        snapshot.bad_case_tags = [t.tag for t in tags]
        try:
            self._write_to_buckets(snapshot, tags)
            if source_path is not None:
                self._refresh_source_with_tags(snapshot, source_path)
        except Exception:
            return tags
        return tags

    def _write_to_buckets(self, snapshot: TurnSnapshot, tags: List[BadCaseTag]) -> None:
        date = _date_bucket(snapshot.timestamp)
        body = snapshot.to_dict()
        body["bad_case_tags_full"] = [t.to_dict() for t in tags]
        filename = f"{_pad_turn_id(snapshot.turn_id)}_{_short_trace(snapshot.trace_id)}.json"
        for t in tags:
            bucket = self._root / date / t.tag
            bucket.mkdir(parents=True, exist_ok=True)
            path = bucket / filename
            with path.open("w", encoding="utf-8") as f:
                json.dump(body, f, ensure_ascii=False, indent=2)

    @staticmethod
    def _refresh_source_with_tags(snapshot: TurnSnapshot, source_path) -> None:
        p = Path(source_path)
        if not p.exists():
            return
        try:
            with p.open("r", encoding="utf-8") as f:
                d = json.load(f)
            d["bad_case_tags"] = list(snapshot.bad_case_tags)
            with p.open("w", encoding="utf-8") as f:
                json.dump(d, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def list_tags(self, date: Optional[str] = None) -> List[str]:
        if not self._root.exists():
            return []
        if date is None:
            tags: set = set()
            for d in self._root.iterdir():
                if d.is_dir():
                    for sub in d.iterdir():
                        if sub.is_dir():
                            tags.add(sub.name)
            return sorted(tags)
        bucket = self._root / date
        if not bucket.exists():
            return []
        return sorted([sub.name for sub in bucket.iterdir() if sub.is_dir()])

    def list_recent(self, count: int = 20, tag: Optional[str] = None) -> List[Path]:
        if not self._root.exists():
            return []
        files: List[Path] = []
        for d in sorted(self._root.iterdir()):
            if not d.is_dir():
                continue
            if tag is not None:
                bucket = d / tag
                if bucket.exists():
                    files.extend(bucket.glob("*.json"))
            else:
                for sub in d.iterdir():
                    if sub.is_dir():
                        files.extend(sub.glob("*.json"))
        files = sorted(files)
        return files[-count:]
