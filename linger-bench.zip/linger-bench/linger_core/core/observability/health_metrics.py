"""C12.H 跨 turn 聚合健康指标。

把"她最近表现如何"从一组 TurnSnapshot 总结成几个数字：
  - turn_count
  - bad_case_rate / each_tag_rate
  - llm_call_total / fallback_rate / retry_rate / failure_rate
  - latency_p50 / latency_p95 / latency_max
  - response_emit_rate（should_emit 占比）

设计：纯函数 + dataclass。不依赖 archive，输入直接是 List[TurnSnapshot]。
"""

import statistics
from collections import Counter
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from linger_core.core.observability.turn_snapshot import TurnSnapshot


@dataclass
class HealthMetrics:
    turn_count: int = 0
    response_emit_rate: float = 0.0

    bad_case_total: int = 0
    bad_case_rate: float = 0.0
    bad_case_by_tag: Dict[str, int] = field(default_factory=dict)

    llm_call_total: int = 0
    llm_failure_total: int = 0
    llm_failure_rate: float = 0.0
    fallback_used_total: int = 0
    fallback_rate: float = 0.0
    retry_total: int = 0
    retry_rate: float = 0.0

    latency_p50_ms: float = 0.0
    latency_p95_ms: float = 0.0
    latency_max_ms: float = 0.0

    span_first_ts: str = ""
    span_last_ts: str = ""

    def to_dict(self) -> Dict:
        return {
            "turn_count": self.turn_count,
            "response_emit_rate": round(self.response_emit_rate, 4),
            "bad_case": {
                "total": self.bad_case_total,
                "rate": round(self.bad_case_rate, 4),
                "by_tag": dict(self.bad_case_by_tag),
            },
            "llm": {
                "call_total": self.llm_call_total,
                "failure_total": self.llm_failure_total,
                "failure_rate": round(self.llm_failure_rate, 4),
                "fallback_total": self.fallback_used_total,
                "fallback_rate": round(self.fallback_rate, 4),
                "retry_total": self.retry_total,
                "retry_rate": round(self.retry_rate, 4),
            },
            "latency_ms": {
                "p50": round(self.latency_p50_ms, 1),
                "p95": round(self.latency_p95_ms, 1),
                "max": round(self.latency_max_ms, 1),
            },
            "span": {"first": self.span_first_ts, "last": self.span_last_ts},
        }


def _percentile(values: List[float], pct: float) -> float:
    if not values:
        return 0.0
    s = sorted(values)
    n = len(s)
    if n == 1:
        return s[0]
    rank = (pct / 100.0) * (n - 1)
    low = int(rank)
    high = min(low + 1, n - 1)
    weight = rank - low
    return s[low] * (1 - weight) + s[high] * weight


def compute(snapshots: List[TurnSnapshot]) -> HealthMetrics:
    m = HealthMetrics()
    if not snapshots:
        return m

    m.turn_count = len(snapshots)
    m.span_first_ts = snapshots[0].timestamp
    m.span_last_ts = snapshots[-1].timestamp

    emit_count = sum(1 for s in snapshots if s.should_emit)
    m.response_emit_rate = emit_count / m.turn_count

    tag_counter: Counter = Counter()
    for s in snapshots:
        for tag in s.bad_case_tags or []:
            tag_counter[tag] += 1
    m.bad_case_total = sum(1 for s in snapshots if s.bad_case_tags)
    m.bad_case_rate = m.bad_case_total / m.turn_count
    m.bad_case_by_tag = dict(tag_counter)

    all_calls = []
    for s in snapshots:
        all_calls.extend(s.llm_calls())
    m.llm_call_total = len(all_calls)
    if m.llm_call_total > 0:
        m.llm_failure_total = sum(1 for c in all_calls if not c.get("success"))
        m.llm_failure_rate = m.llm_failure_total / m.llm_call_total
        m.fallback_used_total = sum(1 for c in all_calls if c.get("fallback_used"))
        m.fallback_rate = m.fallback_used_total / m.llm_call_total
        m.retry_total = sum(int(c.get("retry_count", 0) or 0) for c in all_calls)
        m.retry_rate = m.retry_total / m.llm_call_total

        latencies = [float(c.get("latency_ms", 0) or 0) for c in all_calls]
        m.latency_p50_ms = _percentile(latencies, 50)
        m.latency_p95_ms = _percentile(latencies, 95)
        m.latency_max_ms = max(latencies) if latencies else 0.0

    return m


def render_health(m: HealthMetrics) -> str:
    """把 HealthMetrics 渲染成命令行可读的简洁报告。"""
    lines = []
    lines.append(f"=== Health Report ({m.turn_count} turns) ===")
    if m.span_first_ts:
        lines.append(f"  span: {m.span_first_ts[:19]}  →  {m.span_last_ts[:19]}")
    lines.append("")

    lines.append(f"  发声率 emit_rate:        {m.response_emit_rate:.1%}")
    lines.append(f"  坏样本率 bad_case_rate:  {m.bad_case_rate:.1%}  ({m.bad_case_total}/{m.turn_count})")
    if m.bad_case_by_tag:
        for tag, n in sorted(m.bad_case_by_tag.items(), key=lambda kv: -kv[1]):
            lines.append(f"    └─ {tag:<22} {n} 次")
    lines.append("")

    lines.append(f"  LLM 调用总数:           {m.llm_call_total}")
    if m.llm_call_total > 0:
        lines.append(f"  失败率 failure_rate:    {m.llm_failure_rate:.1%}  ({m.llm_failure_total}/{m.llm_call_total})")
        lines.append(f"  降级率 fallback_rate:   {m.fallback_rate:.1%}  ({m.fallback_used_total}/{m.llm_call_total})")
        lines.append(f"  重试次数 retry_total:   {m.retry_total}  ({m.retry_rate:.1%}/call)")
        lines.append("")
        lines.append(f"  延迟 p50:  {m.latency_p50_ms:>8.0f} ms")
        lines.append(f"  延迟 p95:  {m.latency_p95_ms:>8.0f} ms")
        lines.append(f"  延迟 max:  {m.latency_max_ms:>8.0f} ms")
    return "\n".join(lines)
