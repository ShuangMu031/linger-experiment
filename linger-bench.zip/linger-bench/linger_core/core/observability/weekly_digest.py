"""C13.D 周报生成器。

回答两个问题：
  1. **本周这套系统跑得怎么样？**（聚合 health + 漂移）
  2. **比上周变好了还是变差了？**（趋势）

输入：TraceArchive（拿过去 14 天的 turn）+ HealthSnapshotter（拿每日快照）。
输出：中文 markdown 周报，落到 .data/digests/weekly/YYYY-Www.md。

设计原则：
  - 周报是"她最近怎么样"的快速预读，不是技术日志
  - 漂移信号用人话写：而不是"speak_mode_drift score=0.42"，是"她最近说话方式变了"
  - 触发警告用 ⚠️ 标注，让人扫一眼就知道有没有事
"""

import json
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from linger_core.core.observability.drift_detector import (
    detect_drift, DriftReport, render_drift,
)
from linger_core.core.observability.health_metrics import (
    compute as compute_health, render_health,
)
from linger_core.core.observability.trace_archive import TraceArchive
from linger_core.core.observability.turn_snapshot import TurnSnapshot
from linger_core.persistence import data_paths as _dp


_DRIFT_PHRASES = {
    "speak_mode_drift": "她说话的方式（speak_mode 分布）有显著变化",
    "primary_goal_drift": "她的主要意图分布有显著变化",
    "emotion_priority_drift": "她对情绪优先级的判断分布漂移",
    "response_length_drift": "她回复的长短比之前不一样了",
    "bad_case_rate_delta": "坏样本率与上周相比有明显跳变",
    "fallback_rate_delta": "LLM 降级率与上周明显不同（模型或网络问题？）",
}


@dataclass
class WeeklyDigest:
    week_label: str
    period_start: str
    period_end: str
    current_metrics: Dict[str, Any]
    previous_metrics: Optional[Dict[str, Any]]
    drift_report: Optional[Dict[str, Any]]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "schema_version": "v1",
            "week_label": self.week_label,
            "period_start": self.period_start,
            "period_end": self.period_end,
            "current_metrics": self.current_metrics,
            "previous_metrics": self.previous_metrics,
            "drift_report": self.drift_report,
        }


def _iso_week_label(d: datetime) -> str:
    iso = d.isocalendar()
    return f"{iso[0]}-W{iso[1]:02d}"


def _filter_in_range(snaps: List[TurnSnapshot], since_iso: str, until_iso: str) -> List[TurnSnapshot]:
    return [s for s in snaps if since_iso <= s.timestamp < until_iso]


def build_weekly_digest(
    archive: TraceArchive,
    week_end: Optional[datetime] = None,
) -> WeeklyDigest:
    end = week_end or datetime.now()
    end_date = datetime(end.year, end.month, end.day) + timedelta(days=1)
    cur_start = end_date - timedelta(days=7)
    prev_start = end_date - timedelta(days=14)

    all_snaps = archive.load_recent(count=10**6)
    cur = _filter_in_range(all_snaps, cur_start.isoformat(), end_date.isoformat())
    prev = _filter_in_range(all_snaps, prev_start.isoformat(), cur_start.isoformat())

    cur_metrics = compute_health(cur).to_dict()
    prev_metrics = compute_health(prev).to_dict() if prev else None
    drift = None
    if prev:
        drift = detect_drift(reference=prev, current=cur).to_dict()

    return WeeklyDigest(
        week_label=_iso_week_label(end),
        period_start=cur_start.isoformat()[:10],
        period_end=(end_date - timedelta(seconds=1)).isoformat()[:10],
        current_metrics=cur_metrics,
        previous_metrics=prev_metrics,
        drift_report=drift,
    )


def render_digest_markdown(d: WeeklyDigest) -> str:
    lines: List[str] = []
    lines.append(f"# 周报 {d.week_label}")
    lines.append("")
    lines.append(f"_{d.period_start} → {d.period_end}_")
    lines.append("")

    cur = d.current_metrics
    turn_count = cur.get("turn_count", 0)
    lines.append(f"## 一句话摘要")
    if turn_count == 0:
        lines.append("本周没有任何对话。")
        return "\n".join(lines)

    bad_rate = cur.get("bad_case", {}).get("rate", 0)
    fb_rate = cur.get("llm", {}).get("fallback_rate", 0)
    p95 = cur.get("latency_ms", {}).get("p95", 0)
    lines.append(
        f"本周共 **{turn_count} 轮**对话，坏样本率 {bad_rate:.1%}，"
        f"LLM 降级率 {fb_rate:.1%}，p95 延迟 {p95:.0f} ms。"
    )
    lines.append("")

    lines.append("## 健康指标（本周）")
    lines.append("```")
    lines.append(render_health(_metrics_obj(cur)))
    lines.append("```")
    lines.append("")

    if d.drift_report:
        triggered = [s for s in d.drift_report.get("signals", []) if s.get("triggered")]
        if triggered:
            lines.append("## ⚠️ 漂移信号")
            for s in triggered:
                phrase = _DRIFT_PHRASES.get(s["name"], s["name"])
                lines.append(f"- **{phrase}**")
                lines.append(f"  - score={s['score']}（阈值 {s['threshold']}）")
                lines.append(f"  - 上周：`{s['reference']}`")
                lines.append(f"  - 本周：`{s['current']}`")
            lines.append("")
        else:
            lines.append("## 漂移检测")
            lines.append("✓ 与上周相比，所有维度都在阈值内。")
            lines.append("")
    else:
        lines.append("## 漂移检测")
        lines.append("（上周数据不足，无法对比。这通常发生在试运行第一周。）")
        lines.append("")

    lines.append("## 与上周对比")
    if d.previous_metrics is None:
        lines.append("（无上周数据）")
    else:
        prev = d.previous_metrics
        lines.append("| 指标 | 上周 | 本周 | 变化 |")
        lines.append("|------|------|------|------|")
        rows = [
            ("对话轮数", prev["turn_count"], cur["turn_count"], "int"),
            ("发声率", prev["response_emit_rate"], cur["response_emit_rate"], "pct"),
            ("坏样本率", prev["bad_case"]["rate"], cur["bad_case"]["rate"], "pct"),
            ("LLM 降级率", prev["llm"]["fallback_rate"], cur["llm"]["fallback_rate"], "pct"),
            ("LLM 失败率", prev["llm"]["failure_rate"], cur["llm"]["failure_rate"], "pct"),
            ("p50 延迟 (ms)", prev["latency_ms"]["p50"], cur["latency_ms"]["p50"], "ms"),
            ("p95 延迟 (ms)", prev["latency_ms"]["p95"], cur["latency_ms"]["p95"], "ms"),
        ]
        for name, p, c, fmt in rows:
            if fmt == "pct":
                p_s, c_s = f"{p:.1%}", f"{c:.1%}"
            elif fmt == "ms":
                p_s, c_s = f"{p:.0f}", f"{c:.0f}"
            else:
                p_s, c_s = f"{p}", f"{c}"
            try:
                delta = c - p
                arrow = "→" if abs(delta) < 1e-9 else ("↑" if delta > 0 else "↓")
            except Exception:
                arrow = "?"
            lines.append(f"| {name} | {p_s} | {c_s} | {arrow} |")

    return "\n".join(lines)


def _metrics_obj(d: Dict[str, Any]):
    """重新打包成 HealthMetrics-like 结构供 render_health 使用。"""
    from linger_core.core.observability.health_metrics import HealthMetrics
    m = HealthMetrics(
        turn_count=d.get("turn_count", 0),
        response_emit_rate=d.get("response_emit_rate", 0),
        bad_case_total=d.get("bad_case", {}).get("total", 0),
        bad_case_rate=d.get("bad_case", {}).get("rate", 0),
        bad_case_by_tag=d.get("bad_case", {}).get("by_tag", {}) or {},
        llm_call_total=d.get("llm", {}).get("call_total", 0),
        llm_failure_total=d.get("llm", {}).get("failure_total", 0),
        llm_failure_rate=d.get("llm", {}).get("failure_rate", 0),
        fallback_used_total=d.get("llm", {}).get("fallback_total", 0),
        fallback_rate=d.get("llm", {}).get("fallback_rate", 0),
        retry_total=d.get("llm", {}).get("retry_total", 0),
        retry_rate=d.get("llm", {}).get("retry_rate", 0),
        latency_p50_ms=d.get("latency_ms", {}).get("p50", 0),
        latency_p95_ms=d.get("latency_ms", {}).get("p95", 0),
        latency_max_ms=d.get("latency_ms", {}).get("max", 0),
        span_first_ts=d.get("span", {}).get("first", "") or "",
        span_last_ts=d.get("span", {}).get("last", "") or "",
    )
    return m


def write_digest(
    archive: TraceArchive,
    week_end: Optional[datetime] = None,
    root: Optional[str] = None,
) -> Path:
    digest = build_weekly_digest(archive, week_end=week_end)
    md = render_digest_markdown(digest)

    out_root = Path(root or _dp.DIGESTS_WEEKLY_DIR)
    out_root.mkdir(parents=True, exist_ok=True)
    md_path = out_root / f"{digest.week_label}.md"
    json_path = out_root / f"{digest.week_label}.json"

    md_path.write_text(md, encoding="utf-8")
    json_path.write_text(
        json.dumps(digest.to_dict(), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return md_path
