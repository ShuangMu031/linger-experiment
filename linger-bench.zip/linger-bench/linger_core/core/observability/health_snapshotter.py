"""C13.B 健康快照定期持久化。

每天首轮对话结束后，把当天的 health_metrics dump 到 .data/health/YYYY-MM-DD.json。
30 天试运行结束后，这个目录里会有 30 个文件——这就是 C13.D 周报和漂移检测的输入。

设计：
  - 触发点：orchestrator 每次完成一轮后调用 maybe_snapshot
  - 节流：同一天只写一次（按文件存在性判断）
  - 内容：当天所有 turn 的 compute_health 输出，外加日期、turn 区间
  - 副作用：永远不应该让快照失败影响主链路（IO 错误吞掉）
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Optional

from linger_core.core.observability.health_metrics import compute as compute_health
from linger_core.core.observability.trace_archive import TraceArchive
from linger_core.persistence import data_paths as _dp


def _today_str(now: Optional[datetime] = None) -> str:
    return (now or datetime.now()).strftime("%Y-%m-%d")


class HealthSnapshotter:
    def __init__(
        self,
        archive: Optional[TraceArchive] = None,
        root: Optional[str] = None,
    ) -> None:
        self._archive = archive
        self._root = Path(root or _dp.HEALTH_DIR)

    @property
    def root(self) -> Path:
        return self._root

    def maybe_snapshot(self, now: Optional[datetime] = None) -> Optional[Path]:
        try:
            return self._do_snapshot(now=now)
        except Exception:
            return None

    def force_snapshot(self, now: Optional[datetime] = None) -> Optional[Path]:
        return self._do_snapshot(now=now, force=True)

    def _do_snapshot(self, now: Optional[datetime] = None, force: bool = False) -> Optional[Path]:
        if self._archive is None:
            return None

        date_str = _today_str(now)
        self._root.mkdir(parents=True, exist_ok=True)
        path = self._root / f"{date_str}.json"
        if path.exists() and not force:
            return path

        all_today = [s for s in self._archive.load_recent(count=10**6)
                     if s.timestamp.startswith(date_str)]
        if not all_today:
            return None

        metrics = compute_health(all_today)
        body = {
            "schema_version": "v1",
            "date": date_str,
            "turn_first": all_today[0].turn_id,
            "turn_last": all_today[-1].turn_id,
            "metrics": metrics.to_dict(),
        }
        with path.open("w", encoding="utf-8") as f:
            json.dump(body, f, ensure_ascii=False, indent=2)
        return path

    def list_snapshots(self):
        if not self._root.exists():
            return []
        return sorted(self._root.glob("*.json"))

    def load_range(self, since_date: str, until_date: str):
        out = []
        for p in self.list_snapshots():
            name = p.stem
            if since_date <= name <= until_date:
                with p.open("r", encoding="utf-8") as f:
                    out.append(json.load(f))
        return out
