"""C12 Trace Viewer — 把 TurnSnapshot 渲染为人能读的文本。

三种渲染模式：
  - brief:    一行摘要（适合列表）
  - detailed: 完整决策链（适合一个 turn 的深度复盘）
  - llm_only: 仅渲染 LLM 调用，每条带 prompt_id/version/hash/tier/retry/fallback

设计要求：
  - 纯函数（输入 TurnSnapshot，输出 str），不引入 IO
  - 不依赖任何运行时（脱离 RuntimeState 也能跑）
  - 使用普通文本 + 缩进，不用 ANSI（让 viewer 在管道、文件、CI 都能读）
"""

from typing import List

from linger_core.core.observability.turn_snapshot import TurnSnapshot


def _truncate(s: str, n: int) -> str:
    s = s or ""
    s = s.replace("\n", " ")
    if len(s) <= n:
        return s
    return s[: n - 1] + "…"


def render_brief(snap: TurnSnapshot) -> str:
    tag_str = f" [{','.join(snap.bad_case_tags)}]" if snap.bad_case_tags else ""
    src = snap.envelope_source.lower()
    user_or_proactive = snap.user_message or "(proactive)"
    emit = "→" if snap.should_emit else "×"
    return (
        f"#{snap.turn_id:>4} {snap.timestamp[:19]} "
        f"src={src:<13} {emit} {_truncate(user_or_proactive, 30):<30} "
        f"=> {_truncate(snap.response_message, 30)}"
        f"{tag_str}"
    )


def render_llm_only(snap: TurnSnapshot) -> str:
    lines: List[str] = []
    lines.append(f"=== LLM calls for turn {snap.turn_id} (trace {snap.trace_id[:8]}) ===")
    calls = snap.llm_calls()
    if not calls:
        lines.append("  (no LLM calls)")
        return "\n".join(lines)
    for i, c in enumerate(calls, 1):
        ok = "OK" if c.get("success") else "FAIL"
        prompt_id = c.get("prompt_id", "?")
        prompt_v = c.get("prompt_version", "?")
        prompt_hash = c.get("prompt_hash", "?")[:10]
        tier = c.get("tier") or c.get("requested_tier") or "?"
        retry = int(c.get("retry_count", 0) or 0)
        fb = "fallback" if c.get("fallback_used") else "primary"
        latency = c.get("latency_ms", 0)
        lines.append(
            f"  [{i}] {ok:<4} task={c.get('task_type','?'):<22} "
            f"prompt={prompt_id}@{prompt_v}#{prompt_hash} "
            f"tier={tier:<8} retry={retry} {fb} {latency:>6}ms"
        )
        if not c.get("success"):
            lines.append(f"        error: {c.get('error_type','?')} | {c.get('error','?')}")
        if retry > 0:
            lines.append(f"        retry_reasons: {c.get('retry_reasons', [])}")
        preview = c.get("content_preview") or ""
        if preview:
            lines.append(f"        content: {_truncate(preview, 100)}")
    return "\n".join(lines)


def render_detailed(snap: TurnSnapshot) -> str:
    lines: List[str] = []
    lines.append("=" * 72)
    lines.append(
        f"Turn #{snap.turn_id}  trace={snap.trace_id[:12]}…  "
        f"src={snap.envelope_source}  duration={snap.duration_ms:.0f}ms  "
        f"emit={snap.should_emit}"
    )
    lines.append(f"timestamp: {snap.timestamp}")
    if snap.bad_case_tags:
        lines.append(f"BAD CASE: {snap.bad_case_tags}")
    lines.append("")

    lines.append("--- 输入 ---")
    if snap.user_message:
        lines.append(f"  user: {snap.user_message}")
    else:
        lines.append("  (proactive turn — no user message)")
    lines.append("")

    wb = snap.whitebox_trace or {}
    iu = wb.get("input_understanding", {})
    if iu:
        lines.append("--- 输入理解 ---")
        for k, v in iu.get("content", {}).items():
            lines.append(f"  {k}: {_truncate(str(v), 100)}")
        lines.append("")

    judgments = wb.get("module_judgments", [])
    if judgments:
        lines.append("--- 模块判断 ---")
        for j in judgments:
            layer_name = j.get("layer", "?")
            content = j.get("content", {})
            lines.append(f"  [{layer_name}]")
            for k, v in content.items():
                lines.append(f"    {k}: {_truncate(str(v), 100)}")
        lines.append("")

    sd = wb.get("supervisor_decision", {})
    if sd:
        lines.append("--- Supervisor 决策 ---")
        for k, v in sd.get("content", {}).items():
            lines.append(f"  {k}: {_truncate(str(v), 100)}")
        lines.append("")

    ap = snap.action_plan or {}
    if ap:
        lines.append("--- ActionPlan（19 字段）---")
        for k in (
            "primary_goal", "secondary_goals", "response_strategy",
            "should_ask_question", "should_comfort", "should_avoid",
            "expression_style", "confidence", "can_speak", "should_pause",
            "speak_mode", "allow_followup", "max_sentences",
            "followup_hook", "emotion_priority", "reasoning_summary",
        ):
            if k in ap:
                lines.append(f"  {k}: {_truncate(str(ap[k]), 100)}")
        lines.append("")

    lines.append(render_llm_only(snap))
    lines.append("")

    ar = wb.get("action_result", {})
    if ar:
        lines.append("--- 行动结果 ---")
        for k, v in ar.get("content", {}).items():
            lines.append(f"  {k}: {_truncate(str(v), 100)}")
        lines.append("")

    wbs = snap.writeback_summary or {}
    if wbs:
        lines.append("--- Writeback 摘要 ---")
        for k, v in wbs.items():
            lines.append(f"  {k}: {_truncate(str(v), 100)}")
        lines.append("")

    lines.append("--- 最终回复 ---")
    if snap.response_message:
        lines.append(f"  鹿溪：{snap.response_message}")
    else:
        lines.append("  (空 — 没说出来)")
    lines.append("=" * 72)
    return "\n".join(lines)


def render(snap: TurnSnapshot, mode: str = "detailed") -> str:
    if mode == "brief":
        return render_brief(snap)
    if mode == "llm_only":
        return render_llm_only(snap)
    return render_detailed(snap)


_DIFF_FIELDS = (
    "primary_goal", "secondary_goals", "response_strategy",
    "speak_mode", "expression_style", "should_comfort",
    "should_ask_question", "should_pause", "can_speak",
    "confidence", "emotion_priority", "max_sentences",
    "allow_followup", "followup_hook",
)


def render_diff(snap_a: TurnSnapshot, snap_b: TurnSnapshot) -> str:
    """两轮 diff：对比 ActionPlan 关键字段、LLM 调用规模、坏样本标签。

    用于"她为什么这一轮和上一轮不一样了"的肉眼回归。
    """
    lines: List[str] = []
    lines.append(
        f"=== diff: turn #{snap_a.turn_id} vs turn #{snap_b.turn_id} ==="
    )
    lines.append(f"  A: {snap_a.timestamp[:19]}  src={snap_a.envelope_source}  "
                 f"emit={snap_a.should_emit}")
    lines.append(f"  B: {snap_b.timestamp[:19]}  src={snap_b.envelope_source}  "
                 f"emit={snap_b.should_emit}")
    lines.append("")

    ap_a = snap_a.action_plan or {}
    ap_b = snap_b.action_plan or {}
    diffs: List[str] = []
    for k in _DIFF_FIELDS:
        if k not in ap_a and k not in ap_b:
            continue
        va = ap_a.get(k)
        vb = ap_b.get(k)
        if va != vb:
            diffs.append(f"  - {k:<22} {_truncate(str(va), 40):<40}  →  {_truncate(str(vb), 40)}")
    if diffs:
        lines.append("ActionPlan 字段差异：")
        lines.extend(diffs)
    else:
        lines.append("ActionPlan 字段：无差异")
    lines.append("")

    calls_a = snap_a.llm_calls()
    calls_b = snap_b.llm_calls()
    lines.append(f"LLM 调用：A={len(calls_a)} 次  B={len(calls_b)} 次")
    if len(calls_a) != len(calls_b):
        lines.append("  ⚠️ 调用次数不同，链路可能走了不同分支")
    a_by_task = {c.get("task_type"): c for c in calls_a}
    b_by_task = {c.get("task_type"): c for c in calls_b}
    for task in sorted(set(a_by_task.keys()) | set(b_by_task.keys())):
        ca = a_by_task.get(task)
        cb = b_by_task.get(task)
        if ca is None:
            lines.append(f"  + B 多了 {task}")
            continue
        if cb is None:
            lines.append(f"  - A 多了 {task}")
            continue
        a_hash = (ca.get("prompt_hash") or "")[:10]
        b_hash = (cb.get("prompt_hash") or "")[:10]
        if a_hash != b_hash:
            lines.append(f"  ! {task}: prompt 漂移 {a_hash} → {b_hash}")
    lines.append("")

    if snap_a.bad_case_tags or snap_b.bad_case_tags:
        lines.append(f"坏样本：A={snap_a.bad_case_tags or []}  B={snap_b.bad_case_tags or []}")
    return "\n".join(lines)
