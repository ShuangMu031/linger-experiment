from datetime import datetime
from typing import List, Optional

from linger_core.core.observability.schemas import LogEntry
from linger_core.core.events.system_event import SystemEvent


class EventLogger:
    def __init__(self, max_entries: int = 500):
        self._entries: List[LogEntry] = []
        self._max_entries = max_entries

    def log_event(self, event: SystemEvent) -> None:
        entry = LogEntry(
            timestamp=event.created_at.isoformat(),
            event_type=event.event_type.name,
            data=event.payload,
        )
        self._entries.append(entry)
        if len(self._entries) > self._max_entries:
            self._entries = self._entries[-self._max_entries:]

    def log_lifecycle(self, event_type: str, data: dict = None) -> None:
        entry = LogEntry(
            timestamp=datetime.now().isoformat(),
            event_type=event_type,
            data=data or {},
        )
        self._entries.append(entry)
        if len(self._entries) > self._max_entries:
            self._entries = self._entries[-self._max_entries:]

    def get_recent(self, count: int = 20) -> List[LogEntry]:
        return self._entries[-count:]

    def get_by_type(self, event_type: str) -> List[LogEntry]:
        return [e for e in self._entries if e.event_type == event_type]

    def clear(self) -> None:
        self._entries.clear()

    def count(self) -> int:
        return len(self._entries)
